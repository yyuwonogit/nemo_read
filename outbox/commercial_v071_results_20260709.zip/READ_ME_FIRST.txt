AEO-9 v0.71 - Commercial package (2026-07-09)
========================================================

Hi team,

This is the v0.71 delivery for your Commercial sector. Per our handover rule it's
self-contained: your results, the input we hold/inject for you, the LEAP
structure that input lives in, the drivers/branches you connect to, and the
complete model result set for context.

WHAT'S IN HERE
  READ_ME_FIRST.txt   - this note
  COMMERCIAL_RESULTS_v0.71.csv - your sector's final-energy demand by fuel/region/year/scenario (electricity in GWh, other fuels in PJ).
  input/              - your authored input (canonical rows + any authoring
                        guide) and the same branches as they currently sit in
                        the model (4 scenarios).
  leap_structure/     - the LEAP structure (canon) for your part of the tree:
                        branch tree, every variable + its unit, the canon
                        structure write-up, and the flagged anomaly audit.
  connected_drivers/ - the Key drivers your demand keys off (population, GDP, floor area) + the Resources fuels you consume, with tree + units.
  full_results/       - the COMPLETE model results: final energy demand for
                        every sector, power generation/capacity, and resources
                        supply/exports. So you see your part in context.

NOTES
  - Non-power inputs are unchanged since v0.67 (this cycle's edits were
    power-side), so structure + drivers here are current.
  - Values are the model's outputs/inputs, not observed statistics.
  - Units are stamped on every result row; don't assume.

Shout if you want a different slice or any branch/driver broken out further.
