AEO-9 v0.71 - Keys package (2026-07-09)
========================================================

Hi team,

This is the v0.71 delivery for the Key drivers that feed every demand sector. Per our handover rule it's
self-contained: your results, the input we hold/inject for you, the LEAP
structure that input lives in, the drivers/branches you connect to, and the
complete model result set for context.

WHAT'S IN HERE
  READ_ME_FIRST.txt   - this note
  KEYS_driver_values_v0.71.csv - your Key branch expressions (the driver values). Keys has no direct energy result; it feeds the demand sectors, in full_results/.
  input/              - your authored input (canonical rows + any authoring
                        guide) and the same branches as they currently sit in
                        the model (4 scenarios).
  leap_structure/     - the LEAP structure (canon) for your part of the tree:
                        branch tree, every variable + its unit, the canon
                        structure write-up, and the flagged anomaly audit.
  (this package IS the drivers - see input/ and leap_structure/.)
  full_results/       - the COMPLETE model results: final energy demand for
                        every sector, power generation/capacity, and resources
                        supply/exports. So you see your part in context.

NOTES
  - Non-power inputs are unchanged since v0.67 (this cycle's edits were
    power-side), so structure + drivers here are current.
  - Values are the model's outputs/inputs, not observed statistics.
  - Units are stamped on every result row; don't assume.

Shout if you want a different slice or any branch/driver broken out further.
