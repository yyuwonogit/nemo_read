# Power batch-1b — review-and-confirm before inject (2026-07-14)

**From:** AEO-9 LEAP injection team · **To:** AEO-9 Power team
**Re:** `power_batch1b_delta_20260713.csv` (262 rows) + the stranded-cost probe

We structure-validated your batch-1b send-back against canon (the
`aeo9_v0.67_w_results` exports) and against our own 2026-07-13 engine-edit
capture. **The 262-row delta is clean and injectable as-is** — every branch
path exists, every variable/scenario/unit matches canon, region/node locks
pass (0 violations), Interp forms pass, and it does not collide with the 4
protected MaxCap wrappers or revert our Existing-Capacity zero-point fix.

This bundle is for your **review and sign-off**, not re-authoring. Below is
exactly what to do with each file and each open item. Two of these are the
only things that actually need you to act before we push; the rest are
confirm-or-acknowledge.

---

## The files in this bundle

| File | What it is | What to do with it |
|---|---|---|
| `power_batch1b_delta_20260713.csv` | Your 262-row delta, validated, **unchanged** | Nothing to re-author. Confirm item 4 (VOLL) and we inject it as a delta (blind mode, exclude-Timor-Leste). |
| `stranded_cost_test_row_REALIGNED_20260714.csv` | Your 1-row stranded probe, **column-realigned by us** | Review the realignment (item 2). It replaces your `...CORRECTED_20260709.csv`. |
| `REVIEW_AND_ACTIONS_20260714.md` | This note | — |

---

## Action items

### 1. Stand down on BOTH "structural-create" steps in your work order — the branches already exist
Your work order asks us to (a) scaffold a Thailand **Nuclear SMR** process
("no Thai nuclear process exists, not even a stub") and (b) create a base
**Unmet Load** process for the 8 copper-plate AMS. **Neither create is
needed or permitted.** LEAP structure is region-invariant (a branch exists
in every region or in none): base `Nuclear SMR` and base `Unmet Load` are in
the canon transformation tree and therefore exist in every region's view.
Your "does not exist" reading is the region-scoped-export artifact — a single
export only materialises the region it was walked from.

- Your 2 Thailand nuclear rows inject onto the existing base `Nuclear SMR`.
- Your 24 copper-plate VOLL rows inject onto the existing base `Unmet Load`.

The only residual is a **live-area state check** we perform at inject
(confirm the branch is un-hidden and Node-wired in each region's view). **No
resend needed** — just acknowledge so your next-cycle authoring stops
treating these as absent.

### 2. Stranded-cost probe — we realigned it; confirm or re-emit
Your `stranded_cost_test_row_CORRECTED_20260709.csv` had a **column
misalignment**: 10 fields against the 11-column header, so the `scenario`
cell parsed empty. Un-caught, the injector treats an empty scenario as
"applies to every scenario" — the 614,245,472 USD test value would have
landed in Current Accounts and every other scenario, not just RAS.

We inserted the missing empty `source` field; the long provenance text now
sits in `note`, and `scenario` resolves to `Regional Aspiration Scenario`
(your intent). **Value and unit unchanged; still optimization-inert.** The
realigned file passes all preflight gates. Confirm our realignment, or send
an 11-column version. We inject it as its own RAS-only run.

### 3. Fix the audit trail on 11 rows (bookkeeping)
22 of your rows deliberately overwrite values that batch-1 already landed
(nuclear ceilings raised to ~100 GW; biomass `Endogenous = 0`) — that's fine,
it's your content call. But **11 of them still carry a `structural-create`
label though batch-1 already authored those slots**: the 9 Nuclear
LWR/SFR/SMR `Maximum Capacity` (RAS) rows for Indonesia / Vietnam /
Philippines, noted `structural-create; RAS nuclear ceiling raised to ~100 GW
regional split ...`, and the 2 Biomass Other `Endogenous Capacity` (ATS) rows
for Vietnam / Philippines, noted `CONVERTED at ship 2026-07-13 ...
structural-create (new Maximum Capacity slot on existing branch)`. Those slots
are not live-LEAP defaults — batch-1 authored them — so post-inject readback
will show batch-1 values, not defaults. Please correct the note text so the
audit trail and readback expectation match.

### 4. VOLL 20,000 USD/MWh — CONFIRMED, proceeding
Your doctrine change (Unmet Load `Variable OM Cost` 500 → 20,000, all AMS +
ID/MY nodes, RAS/ATS/BAS; `Fixed OM Cost` stays 500) is **approved on our
side** and will be pushed with this inject. We will update our standing
"Unmet Load = 500" pricing text **after** the solve validates, so the change
is codified only once proven.

### 5. Emission-defect B.4 — confirmed real; one thing back to you
We independently confirmed your defect report: the plain (non-CCS) USC
`Carbon Dioxide` feedstock EFs carry the capture curve
(`94.6 × Interp(2020, 0.9, 2030, 0.9, 2040, 0.95)`, annotated "with CCS
reduction") on the branch **without** capture, while USC-CCS carries the
gross EF un-multiplied. Your fix (strip the multiplier from the non-CCS USC
feedstock EFs) is correct — proceed on the LEAP-side env-loading edit.
**One item back to you:** your claim that USC-CCS capture is "verified real
via Sequestered children" is **not visible in our env-loading export** (no
`Sequestered` pollutant rows on the USC family there). Send the USC-CCS
branch export (or the Sequestered-children extract) so we can confirm net
CCS emissions before relying on them.

### 6. Gas-supply work order → fossil team
`gas_workorder_fossil_team.md` is a Resources-tree ask (Natural Gas envelope
+ non-producer gas repricing + Hydrogen commodity price). We forward it to
the fossil team via the coordinator; no power-side action.

---

## What we need back to push
Only two: **(2)** confirm the stranded realignment (or re-emit), and
acknowledge **(1)** (no branch creation). VOLL **(4)** is already settled.
On those, we inject the 262-row delta + the RAS-only stranded probe against
`aeo9 v0.71`, exclude-Timor-Leste, and send readback confirmation.
