# aeo9 v0.75 RAS power package (2026-07-17) — COMPLETE

Exhaustive `nemo_read` extraction of `NEMO_25 45.sqlite` (v0.75 RAS, 5-yearly, +8x10GW
interconnectors, ~25% higher demand) + the run's Excel export. **START WITH `DIGEST_v0.75.md`.**

Units: energy = PJ (workbook label 'Million Gigajoules'); capacity = GW ('Thousand MW'); emissions = tonnes.
RAS only (one scenario in the DB); the workbook also carries the run's ATS/BAS Gen+Cap.

## Files

**Digest & comparison**
- `COMPARE_generation_and_trade_by_region.csv`
- `COMPARE_system_totals_42_vs_45.csv`
- `DIGEST_v0.75.md`

**Workbook**
- `v_0.75 Power Result.xlsx`

**Generation & dispatch**
- `RAS_dispatch_by_timeslice.csv`
- `RAS_generation_annual.csv`

**Capacity & build**
- `RAS_capacity_annual.csv`
- `RAS_capacity_stack.csv`
- `RAS_new_capacity_annual.csv`

**Load**
- `RAS_electricity_load_annual.csv`
- `RAS_load_by_timeslice.csv`

**Interconnection**
- `RAS_interconnection_by_line_annual.csv`
- `RAS_interconnection_by_line_timeslice.csv`
- `RAS_interconnection_line_available_by_year.csv`
- `RAS_interconnection_line_built_by_year.csv`
- `RAS_interconnection_lines_definition.csv`
- `RAS_interconnection_net_by_node_annual.csv`
- `RAS_trade_annual.csv`

**Fuel use**
- `RAS_fuel_use_by_power_tech_annual.csv`
- `RAS_fuel_use_rate_by_timeslice.csv`
- `RAS_production_rate_by_fuel_timeslice.csv`

**Emissions**
- `RAS_emissions_by_region_all_species_annual.csv`
- `RAS_emissions_by_tech_all_species_annual.csv`
- `RAS_power_co2_emissions_annual.csv`

**Cost**
- `RAS_power_costs_annual.csv`
- `RAS_power_costs_discounted.csv`

**Reference**
- `RAS_power_technology_reference.csv`
- `RAS_timeslice_definition.csv`

**Other**
- `README.md`
