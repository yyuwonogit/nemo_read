# AEO9 v0.75 Power Result — full digest (RAS)

**Run:** `NEMO_25 45.sqlite` · Regional Aspiration Scenario · 5-yearly (2025-2060) ·
solved 2026-07-17. Full `nemo_read` extraction of every populated result table +
the interconnection infrastructure. Energy = **PJ**, capacity = **GW**, emissions = **tonnes**.

## What's new in v0.75 vs v0.74
1. **8 new 10 GW interconnectors** (T39-T46) — see below.
2. **Demand raised ~25%** (base-year delivered load 4,852 -> 6,058 PJ; **intended input change**).
Both are baked into these numbers.

## Generation
- **Total generation: 6,578 PJ (2025) -> 27,621 PJ (2050)** (4.2x).
- Mix 2025: Coal 37% · Gas 35% · Hydro 15% · Wind 3% · Solar 3% · Bioenergy 2% · Geothermal 2% · Oil/Diesel 1%
- Mix 2050: Gas 37% · Unmet Load (slack) 10% · Solar 10% · Hydro 10% · Coal 8% · Wind 8% · Nuclear 6% · Bioenergy 4% · Other 3% · Geothermal 2% · Marine 1%
- Per-region generation and the delta vs v0.74: `COMPARE_generation_and_trade_by_region.csv`;
  full detail in `RAS_generation_annual.csv`, dispatch shape in `RAS_dispatch_by_timeslice.csv`.

## Interconnection — capacity AND flows
- **Capacity/infrastructure:** all 28 lines with ratings, efficiency, costs and build years in
  `RAS_interconnection_lines_definition.csv`; availability + endogenous builds per year in
  `RAS_interconnection_line_available_by_year.csv` / `..._built_by_year.csv`.
  The 8 additions (T39-T46, 10,000 MW each) sit on corridors that had only 30-955 MW before,
  effectively lifting the limits on Thailand-Laos/Cambodia/Malaysia, Malaysia-Singapore,
  Malaysia-Indonesia(Borneo), Laos-Cambodia/Myanmar, Vietnam-Cambodia.
- **Flows:** cross-border trade jumps **+372% at 2030** and stays 50-200% up. By 2050 the new
  corridors carry Laos->Myanmar 80, Laos->Thailand 71, Thailand->Cambodia 75, Vietnam->Cambodia 59,
  Malaysia->Singapore 47 PJ. **Laos & Vietnam become larger net exporters; Thailand, Cambodia,
  Myanmar larger net importers.** Node-net, per-line annual, and per-line-per-timeslice utilisation
  in the `RAS_interconnection_*` files (per-line reconciles exactly to node-net).

## Capacity & build
`RAS_capacity_annual.csv` (installed), `RAS_new_capacity_annual.csv` (additions),
`RAS_capacity_stack.csv` (residual vs new).

## Fuel use, emissions, cost
- **Fuel input** to generation (coal/gas/etc): `RAS_fuel_use_by_power_tech_annual.csv` +
  timesliced rates (`RAS_fuel_use_rate_by_timeslice.csv`, `RAS_production_rate_by_fuel_timeslice.csv`).
- **Emissions:** CO2 in `RAS_power_co2_emissions_annual.csv`; **all 14 pollutant species**
  (CO2, CH4, N2O, SO2, NOx, PM10/2.5, BC, NH3, ...) by tech and by region in the
  `RAS_emissions_*_all_species_annual.csv` files.
- **Cost:** undiscounted (`RAS_power_costs_annual.csv`) + discounted capital/operating/salvage
  (`RAS_power_costs_discounted.csv`).

## !! Feasibility flag — Unmet Load
Even with the new interconnection, RAS leans on the Unmet-Load slack late-horizon:
**~2,880 PJ unserved at 2050 (~10% of generation), ~6,580 PJ at 2060 (~18%)**.
Supply/build — not transmission — is the binding constraint by 2050+. Slack techs are flagged in
`RAS_power_technology_reference.csv`.

## Timeslices
48 representative slices (Wet/Dry x Hr 1-24) — durations/weights in
`RAS_timeslice_definition.csv`; used by every `*_by_timeslice` / `*_rate_*` file.

## v0.74 -> v0.75 comparison
`COMPARE_system_totals_42_vs_45.csv` (generation, capacity, trade, unmet, cost, CO2) and
`COMPARE_generation_and_trade_by_region.csv`. The demand rise drives the absolute increases in
generation/cost/CO2; the interconnection edit shows up cleanly in the trade jump.
