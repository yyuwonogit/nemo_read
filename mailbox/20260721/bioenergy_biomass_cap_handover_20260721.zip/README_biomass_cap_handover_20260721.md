# Bioenergy → LEAP modelling team — biomass supply-cap handover (v2)

**Date:** 2026-07-21 · **Supersedes** `..._20260716.zip` (kept as audit trail) ·
**Re:** biomass + refinery supply caps, `aeo9_v0.67` / live `v0.71`

We are building a two-tier realism cap — **raw production capped → refinery
capped → imports the open valve (for now)**. Evaluating the RAS run we hold
surfaced defects that only you can settle. This bundle is **one ask + several
things we're delivering/flagging** on your branches.

## Contents

| File | Role |
|---|---|
| `leap_team_request_biomass_demand_20260716.md` | **THE ASKS** — now 5 numbered additional asks appended (2026-07-21) on top of the demand request: crop FFB/CPO energy basis, lite-panel cost variables, a fresh RAS re-run, the true input expression set, and a phantom-import design check. Plus the scenario-mapping question. |
| `biomass_supply_cap_rows.csv` | **FYI / review** — the rows we're adding to `bioenergy_leap_input.csv`: the Biomass/Wood import valve + the 5 finite lite-panel production caps. |
| `README_biomass_cap_handover_20260721.md` | this note. |

## The asks, in priority order (detail in the request doc)

1. **Demand export (per-AMS, per-branch, BAS+ATS+RAS)** — `Requirements` +
   `Imports` + `Indigenous Production`, Biomass/Wood included, to 2060. This is
   what lets us size caps that provably cover demand.
2. **Crop FFB/CPO energy basis** — blocks *every* tonnage and land number. The
   identity `production_PJ = crop_equivalent_t × 36.54` shows a CPO energy content
   on an FFB-tonne cap (×4.762 palm, ×15.873 coconut). Confirm the basis; note the
   model already applies OER 0.21 on the land-binding side (don't double-correct).
3. **Add `Capital Cost` + `Variable OM Cost` variables to 5 lite-panel processes**
   (Charcoal, Domestic Biogas, Methanol ×2, Ammonia) — they carry no cost variable
   and were `Unlimited`; the LP built 2,490 PJ of Myanmar methanol on the free
   route. We've capped it provisionally at 100 PJ (see CSV) but can't price it.
4. **Fresh RAS re-run** — the export we hold is superseded and defective
   (no Biomass/Wood; stitched transformation view; degenerate 2050+; 2060 breaks).
5. **True input expression set** for the area that produced the export
   (`resources.xlsx` is not it — production exceeds its caps up to 5.7×).
6. **Phantom-import design check** — no `Maximum Imports` in CA/BAS/ATS; RAS's
   track the production cap; `MeetWithImports` + `Cost of Unmet Requirements = 0`
   means shortfalls become silent unbounded imports.

**Free check first:** v0.25 RAS Bagasse + Biomass carry `Maximum Imports = 0`
alongside `MeetWithImports` — do those cells report any deficit in the solved run?
That alone may answer adequacy for two branches without a re-run.

## Delivering: fixes on your biomass branches

- **Brunei Biomass "8773" = GJ/yr, not TWh** (Tun et al. 2019, Table 2) — a 3.6M×
  slip; true ≈ 0.01 TWh (answers your audit R-A7).
- **Wood `Maximum Imports` carries the same `[Tonne]/1000` bug** your v0.71 Biomass
  fix corrected — we canonise both with the `[GJ]` cast (see CSV).
- **Lite-panel `Maximum Production` bounded** 2,490 → 100 PJ (provisional; needs
  your cost variables to be priced, ask 3).
