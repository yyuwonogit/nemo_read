# Request to the LEAP modelling team — per-AMS, per-type biomass DEMAND from the solved results

**From:** Bioenergy sector · **Date:** 2026-07-16 · **Re:** `aeo9_v0.67_w_results` (and any later area, e.g. v0.71)

## ⚠ ACTION REQUIRED FIRST — 3 branches MUST be created before this cycle injects

**61 of our authored rows will be silently dropped until you create three
branches.** They do not yet exist in canon (v0.67), so the inject pipeline
filters them out and they never reach LEAP:

| Branch to create | Our rows blocked | What it is |
|---|---|---|
| `Resources\Primary\Rice Straw` | 20 (Max Production + Production Cost ×10 AMS) | 2G residue feedstock |
| `Resources\Primary\Used Cooking Oil` | 20 (Max Production + Production Cost ×10 AMS) | waste-oil feedstock |
| `Transformation\Bioethanol Production\Processes\Cellulosic Rice Straw` | 21 (Max Capacity + VOM + Capital) | 2G cellulosic-ethanol process |

These are our long-standing **S1/S2 structural-create request** (see
`LEAP Input/LEAP_action_items.md`). **Please create the three branches (and
confirm the exact paths), then our 61 rows inject.** Nothing else in this
handover unblocks them — this is a create-first dependency, not a value fix.

(For contrast: our 19 emission-factor rows were **re-shaped to the canon leaves**
this cycle — `...\Feedstock Fuels\<fuel>\<Pollutant>` with `Avg Environmental
Loading` — so they now resolve; see the reconcile note in ask #9 below.)

## Why we're asking

We are setting **finite `Maximum Production` caps** on the biomass supply
resources (`Resources\Primary\Biomass`, `Bagasse`, `Wood`, and the crop/residue
feedstocks), per the agreed principle: **production finite, land finite,
production-growth finite; imports left as the open valve for now.**

The single hard guardrail is the one your 2026-07-08 Myanmar fix taught us:
**at every year — above all the start year — each country's exogenous biomass
demand must be ≤ its supply limit** (`Maximum Production + Maximum Imports`). If
a finite production cap lands below the demand and imports can't cover the gap,
the RAS optimisation goes infeasible (the Myanmar case).

To size the caps so this **cannot** happen, we need the model's **actual
per-branch biomass demand** — not an external proxy. We checked the canon
handover (`canon_20260704/`) and the `Results/` sector: both carry only **input**
expressions (caps, costs, prices) or **ASEAN-aggregate** TPES / power-generation
outputs (`Results/ASEAN/data/TPES_*.xlsx` is one aggregate row per fuel, Baseline
scenario). Neither gives the **per-AMS, per-type, RAS** demand we need.

## What we need (a small results export)

From the **solved** area, for the **three scenarios that matter to us — Baseline
Simulation (BAS), AMS Target Scenario (ATS), and Regional Aspiration Scenario
(RAS)** — a CSV of the resource-level **demand / throughput** on each of these
`Resources\Primary\` branches. (We do **not** need Carbon Neutrality/Net-Zero.)

Note on why all three: **RAS** is the optimisation scenario, so that's where a
cap below demand actually goes infeasible — the RAS numbers are what close the
guardrail. **BAS** and **ATS** are accounting runs, but they're reported
scenarios, so we need their demand too to make sure a finite cap doesn't create
unmet requirements there either.

- **Priority (solid-biomass family — where traditional demand lands):**
  `Biomass`, `Bagasse`, `Wood`
- **Also useful (feedstocks we cap):** `Cassava`, `Coconut Oil`, `Corn`,
  `Molasses`, `Palm Oil`, `Palm Oil Mill Effluent`, `Sugarcane`
- **Context (produced secondary fuels):** `Charcoal`

For each branch × **country** (the 10 AMS; Timor Leste separately if easy) ×
**year** (milestones 2025, 2030, 2035, 2040, 2045, 2050, 2055, 2060 are enough),
please give whichever of these LEAP result variables you can export most easily:

| Field | LEAP result | Why we need it |
|---|---|---|
| **Requirement / total output** | the branch's `Output`/`Outputs by fuel` (total draw from demand + transformation feedstock) | the demand our `Maximum Production + Maximum Imports` must cover — **this is the key number** |
| **Production** | solved domestic `Production` | confirms realistic domestic supply (the cap must sit at/above this) |
| **Imports** | solved `Imports` | shows how much the open valve is actually carrying |
| **Exports** | solved `Exports` | if a country exports biomass, the cap must cover demand **+ exports − imports** — the net balance, not just domestic demand |

Suggested columns: `scenario, country, branch, variable, year, value, unit`.

Two things that will save a round-trip:

- **Units — please state them, ideally in the branch's own cap unit.** For
  `Biomass` / `Bagasse` / `Wood` the `Maximum Production` field is **Terawatt-hour**;
  if you can report the demand in TWh (or GJ) rather than tonnes/ktoe we avoid a
  conversion, and — candidly — this whole exercise started from a `TWh`-vs-`GJ`
  unit slip on this very branch, so an explicit unit column matters.
- **We want the exogenous DEMAND, not the supply allocation.** Under the current
  mostly-`Unlimited` production caps the solved *Production* can route to whichever
  region is cheapest (the biodiesel-to-Timor-Leste failure mode), so the
  **Requirement** is the reliable number to anchor caps to; Production/Imports are
  context. If demand is price-responsive on these branches rather than fixed, flag
  it.

**One confirmation we need regardless — the start year.** The guardrail binds
hardest at the **first optimisation / scenario year**. We've been assuming that is
**2025**; please confirm the first scenario year (and first *optimised* year if
different), so we anchor `cap ≥ demand` to the right year.

**If a full per-branch demand export is awkward,** the single most valuable number
is the **first-scenario-year requirement per branch per country** in RAS — that
alone lets us set each cap so `cap(start) ≥ requirement(start)` and close the
guardrail. A base-year energy-balance breakdown of solid biomass (fuelwood /
charcoal / bagasse / residues) by AMS would also serve. If easy, splitting the
requirement into **final demand vs transformation-feedstock draw** helps us see
which part is bounded by process caps we already set — but the total is enough.

## What we do with it

We set `Maximum Production(y) = max(sustainable-potential(y), demand(y))` per
country so the cap never falls below demand, and we keep the canonised import
valve (`Max(floor, Maximum Production[GJ])`) as the safety margin. Until we have
your numbers we are using an **IRENA-2022 solid-biomass consumption proxy**
(aggregate, per-AMS) as a conservative over-provision — safe, but we'd like to
replace it with the model's actual per-branch demand so the caps are neither
infeasible nor needlessly loose (the aggregate proxy risks triple-counting
`Biomass` + `Bagasse` + `Wood`, which your per-branch split resolves).

## One structural note (no action needed unless you disagree)

We are bringing the biomass **import valve** into our authored CSV this cycle
(`Resources\Primary\{Biomass,Wood}:Maximum Imports = Max(<floor>, Maximum
Production[GJ])`, unit-corrected `[GJ]`), canonising your v0.71 Biomass fix and
applying the same `[Tonne]/1000 → [GJ]` correction to **Wood** (its twin still
carries the unit bug in the v0.67 export). The **Base Template** half of that fix
stays yours to hold. Flag if you'd rather own these rows.

## One question on scenario mapping (please confirm)

Our scenarios of record are **BAS, ATS and RAS** — CNZ is out of scope for us.
But your canon README §5 states that our authored data lands in **RAS and CNZ**.
If the inject still maps our rows to RAS + CNZ, then any cap we author for **BAS**
and **ATS** would never reach the model, and we'd be shipping into a scenario
(CNZ) we don't report.

Please confirm the intended mapping for bioenergy rows. Our expectation:

| Variable | Should land in | Why |
|---|---|---|
| `Maximum Production` (the caps) | **BAS, ATS, RAS** | the variable exists in all three; the cap should bind in every reported scenario |
| `Maximum Imports` (the valve) | **RAS only** | it's an optimisation-scenario variable — BAS/ATS are accounting runs carrying `Imports` + `Cost of Unmet Requirements` instead |
| `Import Cost` / `Production Cost` | **BAS, ATS, RAS** | companion costs to the above |

If that's wrong — e.g. bioenergy caps are deliberately RAS-only and BAS/ATS are
meant to stay at the untouched baseline — tell us and we'll scope the caps
accordingly. This affects how many rows we send next cycle, so it's worth
settling before we author.

---

## Additional asks (added 2026-07-21, from our run-results evaluation)

Evaluating the RAS export we hold (`biodiesel_results_v025.csv`) surfaced defects
that only you can settle. Folding them in here so this is one handoff, not five.

**1. Crop energy basis — FFB/CPO (blocks every tonnage + land number).** The exact
identity `production_PJ = crop_equivalent_t × 36.54` shows a **crude-palm-oil**
energy content (36.54 MJ/kg) applied to a `Maximum Production` cap authored in
**fresh-fruit-bunch** tonnes (canon README §2 says these caps are raw crop). The
inflation is exactly `1/OER = 4.762` for palm, `15.873` for coconut; sugarcane
(cane) and cassava (fresh root) are the same class. Indonesia 2050 then reads
526 Mt "palm oil" vs actual CPO ~47 Mt, and ASEAN palm+coconut supply reaches
~27% of total ASEAN TPES. **Please confirm the intended basis:** (a) we author the
caps in oil-/product-equivalent tonnes to match the fuel LHV, or (b, our
preference) the fuel `EnergyContent` is moved to a raw-crop basis as Sugarcane
(7.4), Bagasse (8.2), Wood (15.5 GJ/t) already are, keeping caps in raw FFB.
Note the model already applies OER 0.21 on the land-binding side, so the fix must
not double-correct.

**2. Add `Capital Cost` + `Variable OM Cost` variables to 5 lite-panel processes.**
Charcoal `All Biomass`, Domestic Biogas `Anaerobic Digestion`, Methanol
`CO2 Utilization for Iron and Steel`, Methanol `Production from Hydrogen`, Ammonia
`Hydrogen` carry **no cost variables at all** on their panel and `Maximum
Production = Unlimited` — a free, uncapped route the LP exploited (RAS solution:
Myanmar Methanol CO2-Utilization `Data(2040, 2 490 424 000)` GJ/yr ≈ 2 490 PJ,
~5× Myanmar's biomass, all other regions 0). We've authored a provisional finite
`Maximum Production` (100 PJ/AMS) to bound it, but a cap without a cost still
distorts merit order. Please add the cost variables so we can price these routes.

**3. Commission a fresh RAS re-run.** The export we hold is superseded (area
`aeo9_v0.25`/v0.48; canon is v0.67, live v0.71) and has defects that make it
unusable for adequacy or land conclusions: no Biomass/Wood items; the
transformation view is two selections stitched (Indonesia Total 22,780→0 PJ post-
2045 while the aggregate moves the opposite way); 2050+ is degenerate (~500 Mt
Indonesian palm with zero downstream draw, the `0.001` anti-arbitrary guard
failed); four series break at 2060 (MY palm, PH/TH/BN coconut). Please re-run RAS
with **`Indigenous Production` + `Requirements` + `Imports`**, **Biomass and Wood
included**, a clean extension to **2060**, and per-country + aggregate from a
**single consistent selection**.

**4. Send the actual input expression set for the area that produced the export.**
`Bioenergy/Raw/resources.xlsx` demonstrably is *not* it — evaluated against the
run's own output, production exceeds those `Area × Yield` caps by up to 5.7×, so
the two are different model states. Without the true input set no before/after
cap delta is like-for-like.

**5. Phantom-import design check.** No `Maximum Imports` rows exist in CA/BAS/ATS
at all; the RAS ones track the production cap (`Max(historical, MaxProd/1000)`)
rather than bounding independently, and every bio branch runs `Unmet Requirements
= MeetWithImports` with `Cost of Unmet Requirements = 0` — any shortfall becomes
silent, unbounded, unpriced imports. Confirm this is intended.

**Free check that may narrow the whole ask:** in the v0.25 RAS export, Bagasse and
Biomass carry `Maximum Imports = 0` alongside `MeetWithImports` — the one place a
genuine deficit could already show. Could you tell us whether those cells report
any unmet requirement / deficit in the solved run? That alone might answer the
adequacy question for two branches without a full re-run.

**7. Refinery-capacity UNIT MISMATCH — biodiesel cap is ~39× too tight (please
confirm the authoring unit).** We author `Maximum Capacity` on the biofuel
processes from a physical panel in **Million Tonnes/yr**. In canon v0.67 the value
lands **unconverted** in a field whose unit is **Million GJ/Year** (biodiesel) /
**Million TCE/Year** (ethanol): e.g. Indonesia FAME reads `Add(2025, 16, …)` — our
`16` (we meant **16 Mt/yr**), so the model holds **16 Million GJ/Year ≈ 0.41 Mt/yr**
of biodiesel capacity, ~**39×** too tight (16 Mt × 38.997 GJ/t = **624** Million
GJ/Year intended). Ethanol's TCE mismatch is minor (~10%: ×26.744/29.31). This
plausibly contributes to the biodiesel behaviour we see in the results. **Please
confirm where the conversion should live:** do we author native **Million GJ/Year
/ Million TCE/Year** (we'll multiply by the fuel LHV), or is the inject adapter
meant to convert our Mt and simply didn't? We've prepared the converted values and
will apply on your confirmation — we're holding to avoid a double-conversion.
(Our `load_refining_capacity` note already flagged this unit as unverified; canon
now answers the unit but not where the conversion belongs.)

**8. Corn energy content — needed for two unit conversions.** Canon prices Corn
`Import Cost` and feedstock `Fuel Cost` **per Tonne of Coal Equivalent**, but
`Corn` has no `EnergyContent` row in the LEAP fuel properties we hold, so we can't
convert our per-tonne-grain values to per-TCE. Please send the model's Corn
`EnergyContent` (GJ/t) or confirm the TCE basis so we can author these correctly.

**9. Emission-factor rows re-shaped to canon leaves — please reconcile values,
don't blind-apply.** Our 20 old "(process)" shorthand EF rows (e.g. `CH4 (process)`
on the parent `...\Feedstock Fuels\Coconut Oil` branch) never resolved. We've
re-shaped 19 of them to the real canon leaves — `...\Feedstock Fuels\<fuel>\
<Pollutant>` with `Avg Environmental Loading` (Kilogramme/Terajoule) — so they now
match canon. **But canon already carries authored factors on these leaves**
(including the intentional `Methane = 0` on crop feedstocks, audit A-T6), and ours
are low-confidence IPCC/EMEP Tier-1 placeholders. So please **keep your authored
values and treat ours as fallback only where a leaf is genuinely empty** — do not
overwrite. Two were retired outright (no valid canon target): Sugarcane `Carbon
Dioxide` (no such leaf) and the `CO2 biogenic` row that sat on
`Resources\Secondary\Biodiesel` (canon carries Carbon Dioxide Biogenic on the
Transformation Aux-fuel leaves instead).
