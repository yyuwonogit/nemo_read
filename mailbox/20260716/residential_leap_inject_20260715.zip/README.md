# Residential LEAP inject handoff — 2026-07-15

**To:** LEAP inject team · **From:** Residential (AEO-9 Phase-2) · **Branch:** `20260708_Appliances_P2_YY` @ 7530c6dd

Complete Residential Phase-2 inject set for all 10 AMS. Paste targets are the CSVs in
`LEAP Input/`; the authoring/format guide and paste order are in
`LEAP Input/LEAP_action_items.md`. Cooking's method + evidence is
`cooking_base_year_correction_20260715.md`.

## Contents (paste targets)

| End use | File(s) | Notes |
|---|---|---|
| Cooking | `cooking_canonical_input.csv` (within-Clean Activity Level, 180 rows), `cooking_stove_characteristics.csv` (391 rows: uniform stove Efficiency per technology across all AMS + Lao Clean Cooking Access fix). `cooking_leap_inject.csv/.xlsx` = author-side long format. | Rule 1 (BAS≥ATS≥RAS energy) holds in all 360 country-year cells. |
| AC | `ac_leap_inject.csv` (or `_drift`), `ac_exo_device.csv` | ×100 ownership scale fix applied; old AC tree stays ON as calibration baseline. |
| Fridge | `fridge_leap_inject.csv` (or `_drift`), `fridge_exo_device.csv` | Refrigeration_ ATS>BAS inversion fixed; exo fleet re-matched to real base. |
| Nine appliances | `appliance_efficiency_paste.csv` | Existing/Efficient efficiency lever (7 two-tier + Water Heating). |
| Lighting | `lighting_tech_shares.csv`, `lighting_bulb_wattage.csv`, `lighting_leap_paste.csv` | LEAP-native paste regenerated from the FDF curve. |

## Two paste-time actions for the LEAP team (documented, not blockers)

1. **Cooking base-year calibration** — stove Efficiency is now pure physics (one value per
   technology, no per-country Cal). Re-establish base-year calibration via an activity/demand-level
   Cal, NOT the stove-efficiency term.
2. **AC** — resolve the activity-vs-stock calc-path question; pick the inject variant (frozen vs drift).

## Verification status

Cooking independently validated (shares sum to 100, seam exact at 2025, Rule 1 all cells).
AC/Fridge/Lighting/appliances: blockers documented resolved in commit `ec5f52df`; final
confirmation is the post-paste LEAP run + Phase-2 audit (`Residential/NEXT_STAGE.md §C`).
