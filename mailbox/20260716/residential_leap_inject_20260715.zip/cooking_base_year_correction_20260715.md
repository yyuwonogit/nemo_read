# Cooking base-year (2024/2025) mix — sanity check and corrected starting state

**Last updated: 2026-07-15.** Author-side handoff artifact. This is the evidence
package behind a proposed correction to the §0 "Confirmed base state" table in
[`COOKING_DESIGN_20260710.md`](COOKING_DESIGN_20260710.md), which
[`build_cooking_leap_inject.py`](../build_cooking_leap_inject.py) `BASE` implements
verbatim. **Nothing in the inject has been changed yet** — this is the review gate
before a rebuild.

## Why this exists

Every scenario trajectory (BAS/ATS/RAS) starts from the 2025 within-Clean fuel mix in
the builder's `BASE` dict. If that starting mix is wrong, every downstream share and
every derived energy number inherits the error. Two independent diagnostics said it is
wrong:

1. **The calibration factors.** LEAP computes `final energy = activity_share × UEI /
   efficiency`, and `efficiency = nominal × Key\Cal\Residential\<fuel>`. The `Cal`
   factor is fitted so the base year reproduces the national energy balance, so a `Cal`
   far from 1.0 is not a physical statement about stoves — it is the residual left when
   the **authored share disagrees with the balance**. `Cal ≫ 1` ⇒ share too high;
   `Cal ≪ 1` ⇒ share too low. Cambodia's biogas `Cal = 15.545` implies an 886%-efficient
   stove — impossible, and a direct signal its 48.2% biogas share is fabricated. See
   [`audit_cooking_base_year.py`](../audit_cooking_base_year.py) →
   [`cooking_base_year_2024.csv`](cooking_base_year_2024.csv).

2. **The design doc contradicts itself.** §0's table copies the Energy Balance Table
   (EBT) values and calls them "confirmed", but the per-country **research** sections
   often refute §0 — for Thailand the doc itself calls the 84.5% electric figure "an EBT
   energy-balance artifact (all-appliance residential electricity mis-attributed to
   cooking)". The builder implemented §0, artifacts and all. The Thailand reset that
   [`COOKING_INSTANCE_KICKOFF.md`](../../../COOKING_INSTANCE_KICKOFF.md) line 27 lists as
   a **mandatory** fix was never applied.

**Systemic root cause (holds across 8 of 10 AMS):** the EBT-2020 *energy* split was
pasted into *household-share* fields, and all-appliance residential electricity
(rice cookers, fridges, AC, lighting) was mis-attributed to the cooking branch. Both
errors inflate the electric share. The single most common correction below is
"electric down, LPG up".

## Method

Ten independent per-country researchers checked the authored within-Clean mix against
real-world evidence (WHO Household Energy Database, DHS/MICS/census primary-stove
surveys, national energy balances, ESMAP MTF, utility/ministry data), each guarded
against the **rice-cooker stacking trap** (survey "cooks with electricity" usually means
a stacked electric rice cooker beside an LPG/biomass primary hob — and rice cookers are
modelled in their own separate LEAP branch, so they must not count as primary-electric).
Every verdict was then put to a three-lens adversarial refutation pass (skeptic,
source-quality auditor, arithmetic/calibration auditor).

**Verification status is uneven and is marked per country.** The session usage cap
interrupted the refutation pass: it *completed* for Thailand, Cambodia, Brunei and
Indonesia (all upheld, none refuted), and did **not** run for the other five qualifying
countries — those rest on the single-pass audit only. This is flagged as `VERIFIED` vs
`AUDIT-ONLY` in the table.

## Scope of this correction

Per your instruction, this package carries **every finding at medium-high confidence and
above**. That is 9 of 10 AMS. **Malaysia (medium)** falls below the bar and is held
back — it is listed at the end for completeness but is **not** proposed for adoption yet.

## Decision ledger (agreed with user, 2026-07-15)

Running record of which base mixes are LOCKED for the eventual `build_cooking_leap_inject.py`
`BASE` rebuild. Numbers here supersede the corrected-base table below where they differ.

| Country | Status | Locked mix (ConvElec / Induction / LPG / NatGas / Biogas / Solar) | Notes |
|---|---|---|---|
| Thailand | **AGREED** (verified) | 6.5 / 0 / 93.5 / 0 / 0 / 0 | via "take this all, med-high and up" |
| Cambodia | **AGREED** (verified) | 4.0 / 0 / 94.0 / 0 / 2.0 / 0 | resolves the Rule-1 energy inversion |
| Indonesia | **AGREED** (verified) | 0.53 / 0 / 98.24 / 1.21 / 0.02 / 0 | LPG stays Remainder |
| Brunei Darussalam | **AGREED** (verified) | 2.5 / 0 / 92.0 / 5.5 / 0 / 0 | **remainder holder flips NatGas → LPG** |
| Malaysia | **AGREED** (fresh re-audit, med-high) | 0.3 / 0.2 / 99.0 / 0.5 / 0 / 0 | round-2 re-audit went further than the draft (electric ~0.5% total, not 4%); verifier pass was still running when adopted |
| Viet Nam | **AGREED** | 6.0 / 0 / 93.0 / 0 / 1.0 / 0 | electric total 6.0 folded into ConvElec to keep the "Induction = 0 at 2025" convention |
| Philippines | pending verify | 4.0 / 0 / 96.0 / 0 / 0 / 0 | minor change; verification in flight |
| Lao PDR | pending verify | 30.0 / 0 / 69.0 / 0 / 1.0 / 0 | + companion: Clean Cooking Access 11.1% → 8% |
| Singapore | pending verify | 19.0 / 0 / 25.0 / 56.0 / 0 / 0 | NatGas stays Remainder |
| Myanmar | **AGREED** (fresh re-audit + 3/3 verified, high) | 95.0 / 0 / 4.2 / 0 / 0.8 / 0 | authored mix was BACKWARDS; LPG remainder stays |

**APPLIED to the builder on this branch, 2026-07-15.** All 10 corrected bases and the full
re-authored BAS/ATS/RAS trajectories are now in `build_cooking_leap_inject.py`
(`BASE`, `ELECTRIC_TOTAL`, `INDUCTION_SHARE`, `RAS_FULL_ELECTRIC_YEAR`, all re-tiered on the
corrected gaps), and `cooking_leap_inject.csv` + `cooking_canonical_input.csv` are regenerated.
Validation: 2025 seam exact for all 10 (every scenario starts at the corrected base); shares
sum to 100; BAS ≤ ATS ≤ RAS in electric share; RAS reaches ~100% electric **13–20 years before
ATS** per country. Also fixed the minor-fuel decay asymmetry (ATS minors now decay on their own
electrification progress, like RAS), which cleared the small RAS>ATS energy inversions in
Malaysia and Indonesia. Energy-ordering illustration now shows **9/10 AMS clean**; the sole
residual is **Lao PDR**, whose inversion is entirely the canon `Key\Cal\Residential\LPG` = 1.705
(effective LPG efficiency 95.5% > electric 75%) — a LEAP-team Cal re-fit, not an inject fix.

**Stove characteristics harmonised (2026-07-15) — the root-cause fix.** LEAP evaluated cooking
Efficiency as `nominal × Key\Cal\Residential\<fuel>`, so the *same* stove technology had
different efficiencies per country (LPG 30–95%, biogas 11–886%) — a base-year balance residual
smuggled into stove physics, and the true cause of every Rule-1 inversion. Fixed by
`build_cooking_stove_characteristics.py` → `cooking_stove_characteristics.csv`: **one physical
efficiency per technology, identical across all 10 AMS**, no Cal — Induction 85 / Electric 75 /
NatGas 57 / Biogas 57 / LPG 56 / Solar 40.5 (Clean); Kerosene 45 / Coal 42.6 / Efficient Wood 31
/ Wood 16 / Charcoal 16 / Bagasse 10 / Other Biomass 10 (Traditional). The ladder is physically
ordered (electric beats every combustion fuel), so electrifying always lowers final energy.
**Result: the energy-ordering illustration now holds Rule 1 in all 360 country-year cells, 0
inversions — Cambodia and Lao PDR both resolved.** Same pass authored the **Lao PDR Clean
Cooking Access** correction (11.1% → 8.0% at 2023, LSIS III, whole series rescaled ×0.7207).

Only remaining handoff (a proper model step, not a defect): because Efficiency no longer absorbs
the base-year balance residual, the **LEAP team re-establishes base-year calibration through an
activity/demand-level Cal**, not by distorting stove physics. All the outlier Cals (Cambodia
biogas 15.5, Lao LPG 1.705, Malaysia NatGas 0.058, …) were fit to the *old fabricated* bases and
are void anyway.

**RESOLVED — Malaysia Clean Cooking Access: KEEP the canon 83.8%, no change.** A research pass
(2026-07-15) confirmed the canon level is correct: World Bank `EG.CFT.ACCS.ZS` reports Malaysia
at **84.1% (2022)**, and the ~16 pp gap is genuine biomass cooking concentrated in rural East
Malaysia — Sabah has off-grid interior communities cooking with firewood, and Sarawak rural
electrification was only 56% in 2009, reaching ~95% by 2020. The earlier "declining artifact →
~99% flat" proposal was wrong (it generalised Peninsular Malaysia to the whole country). The
declining *trend* (97.9%→83.8%) may be a WHO re-estimation, but the current level is defensible,
so the canon series stands. Sources: World Bank WDI EG.CFT.ACCS.ZS
(https://data.worldbank.org/indicator/EG.CFT.ACCS.ZS?locations=MY); Sarawak Energy rural
electrification releases (https://www.sarawakenergy.com/); Borneo Post, 'Sabah's off-grid
communities paying the most for power' (2022, https://www.theborneopost.com/2022/03/23/sabahs-off-grid-communities-paying-the-most-for-power/).

**Myanmar — the decisive call (resolved 2026-07-15).** The authored 4.96% electric / 94.3%
LPG is a near-total inversion; the true within-Clean arm is ~95% electric / ~4% LPG. A fresh
independent re-audit (told to distrust both the authored ~5% and the prior 95%) landed on 95%
again, and all three adversarial verifiers upheld it at high confidence (0 refuted). It is
over-determined by three independent lines:
- **LPG supply ceiling (decisive).** The authored 94.3% LPG implies LEAP burns 28.35 PJ ≈
  616,000 t/yr of residential LPG — ~6× Myanmar's entire national LPG supply (~100,000 t/yr,
  all sectors). Physically impossible. — Frontier Myanmar, 'LPG: bright prospects but growth
  constraints' (MoEE, ~3% of households use LPG) https://www.frontiermyanmar.net/en/lpg-bright-prospects-but-growth-constraints/
- **World Bank/ESMAP MTF 'Beyond Connections' Myanmar** (fieldwork 2017): main cookstove
  electric 12% / LPG 0.8% → within-Clean electric ~93.8%; the source explicitly separates
  *exclusive* electric-stove use (33.8% urban / 4.5% rural) from electric+biomass stacking, so
  the rice-cooker trap is defused by the primary source itself. https://documents1.worldbank.org/curated/en/312751568213372366/txt/Myanmar-Beyond-Connections-Energy-Access-Diagnostic-Report-Based-on-the-Multi-Tier-Framework.txt
- **WHO GHO Household Energy Database** (`PHE_HHAIR_PROP_POP_CATEGORY_FUELS`, raw JSON): 2023
  electricity 50.3% / gaseous 1.9% → within-Clean electric 96.4%, stable 96.2–96.7% across
  2016–2023. https://ghoapi.azureedge.net/api/PHE_HHAIR_PROP_POP_CATEGORY_FUELS?$filter=SpatialDim%20eq%20%27MMR%27

Cal fingerprint corroborates: Myanmar is the **only** AMS whose LPG `Cal` was left at the
fitting default 1.000 — i.e. the 94.3% LPG share was pasted without ever being reconciled to
the energy balance, and the no-Cal electric leaves let the understatement pass invisibly.
Why it is coherent that clean-cooking Myanmar is ~95% electric: LPG barely exists there (~3%
of households) and there is no piped household gas, so among the ~53% of households that cook
clean, electric hotplates are the only clean option at scale; the biomass-cooking majority
sits in the Traditional arm. Residual uncertainty is in the exact split (93–96%), not the
direction — MTF fieldwork is pre-coup (2017) and WHO is a modelled series, neither fully
capturing post-2021 grid deterioration.

## The corrected base table

Within-Clean household shares at 2025 (each row sums to 100 across the six fuels).
`authored → corrected` where they differ.

| Country | Verdict | Conf. | Verify | ConvElec | Induction | LPG | NatGas | Biogas | Solar |
|---|---|---|---|---|---|---|---|---|---|
| **Thailand** | fabricated | high | VERIFIED | 84.5 → **6.5** | 0 | 15.5 → **93.5** | 0 | 0 | 0 |
| **Cambodia** | fabricated | med-high | VERIFIED | 1.2 → **4.0** | 0 | 50.7 → **94.0** | 0 | 48.2 → **2.0** | 0 |
| **Myanmar** | fabricated | high | VERIFIED 3/3 | 4.96 → **95.0** | 0 | 94.3 → **4.2** | 0 | 0.78 → 0.8 | 0 |
| **Brunei Darussalam** | materially wrong | med-high | VERIFIED | 2.0 → **2.5** | 0 | 48.0 → **92.0** | 50.0 → **5.5** | 0 | 0 |
| **Lao PDR** | materially wrong | med-high | AUDIT-ONLY | 56.1 → **30.0** | 0 | 43.9 → **69.0** | 0 | 0 → **1.0** | 0 |
| **Singapore** | materially wrong | med-high | AUDIT-ONLY | 29.16 → **19.0** | 0 | 20.99 → **25.0** | 49.85 → **56.0** | 0 | 0 |
| **Viet Nam** | materially wrong | med-high | AUDIT-ONLY | 17.0 → **3.5** | 0 → **2.5** | 83.0 → **93.0** | 0 | 0 → **1.0** | 0 |
| **Philippines** | minor issues | high | AUDIT-ONLY | 5.6 → **4.0** | 0 | 94.4 → **96.0** | 0 | 0 | 0 |
| **Indonesia** | minor issues | high | VERIFIED | 1.45 → **0.53** | 0 | ~97.75 → **98.24** | 0.51 → **1.21** | 0.29 → **0.02** | 0 |
| Malaysia *(below bar — held)* | materially wrong | medium | AUDIT-ONLY | 12.7 → 3.5 | 0 → 0.5 | 87.2 → 95.0 | 0.1 → 1.0 | 0 | 0 |

## Per-country evidence

### Thailand — fabricated (high, VERIFIED)
Authored 84.5% ConvElec is an inverted energy-balance artifact. WHO/Thai-NSO
primary-cooking-fuel data put electricity at ~5.3% of population (~6.1% of Clean) vs gas
~80.9% (~93.9% of Clean). The model's own 2030 BAS output burns **191.6 PJ (53.2 TWh) of
electricity on cooking alone** — comparable to Thailand's *entire* residential
electricity consumption, i.e. physically implausible. `Cal\LPG = 0.556` corroborates
(balance wants more LPG). Correction (−78 pp electric) is ~2.4× larger than the kickoff's
"→15%" because 15% was itself inferred from a cooking-energy share that still included
stacked rice cookers.
- WHO Household Energy Database, `PHE_HHAIR_PROP_POP_CATEGORY_FUELS` (Thai NSO surveys), GHO OData API — https://ghoapi.azureedge.net/api/PHE_HHAIR_PROP_POP_CATEGORY_FUELS?$filter=SpatialDim%20eq%20%27THA%27 ; db page https://www.who.int/data/gho/data/themes/air-pollution/who-household-energy-db
- Model output: `Raw/cooking_results_v071.csv` (Thailand ConvElec 2030 BAS = 191.58 PJ). Residential electricity context: 'Economic Growth and Energy Consumption in Thailand', Energies 18(15):3980, 2025 (household = 25.1% of total electricity) — https://doi.org/10.3390/en18153980 ; EPPO https://www.eppo.go.th/index.php/en/en-energystatistics/electricity-statistic
- Chaichana et al., 'Electricity consumption characteristics in Thailand residential sector', Energy Reports 2019 — https://www.sciencedirect.com/science/article/pii/S2352484719309886
- EPPO/DOEB LPG demand by usage 2023 (Statista) — https://www.statista.com/statistics/1305379/thailand-demand-for-liquefied-petroleum-gas-propane-and-butane-by-usage/ ; cooking-gas subsidy, Bangkok Post 2024 — https://www.bangkokpost.com/business/general/2818945/cooking-gas-subsidies-extended-to-sept-30
- Underlying study behind the design doc's own caveat: Frontiers in Energy Research, 2024, 'Stakeholder-driven carbon neutral pathways for Thailand and Bangkok' — https://www.frontiersin.org/journals/energy-research/articles/10.3389/fenrg.2024.1335290/full

### Cambodia — fabricated (med-high, VERIFIED)
48.2% biogas assigns ~1.0 million households to biogas; Cambodia's entire national
biodigester fleet ever built is ~30,500 units (~1.4% of clean households). DHS 2021-22
(via the DHS API) gives electricity 2.6% / LPG+NG+biogas 47.8% / wood 42.5% as *primary*
fuel — an exact match to the audit. `Cal\Biogas = 15.545` corroborates the direction and
magnitude. Correcting it dissolves the Rule-1 energy inversion (see below).
- Cambodia DHS 2021-22 (NIS + MoH), indicators `HC_CKFL_H_*`, DHS API — https://api.dhsprogram.com/rest/dhs/data?countryIds=KH&indicatorIds=HC_CKFL_H_ELC,HC_CKFL_H_LPG,HC_CKFL_H_WOD ; report https://www.dhsprogram.com/pubs/pdf/FR377/FR377.pdf
- SNV / Cambodia National Biodigester Programme — http://nbp.org.kh/ ; https://www.snv.org/project/national-biodigester-programme-nbp-cambodia ; assessment, Energy for Sustainable Development 2018 — https://www.sciencedirect.com/science/article/pii/S0973082618302588
- World Bank/ESMAP MTF Cambodia (2018) — https://www.esmap.org/node/157691 ; MECS/Loughborough 2020 — https://mecs.org.uk/wp-content/uploads/2020/12/MTF-Cambodia-04112020.pdf
- Cambodia LPG consumption (EIA via TheGlobalEconomy) — https://www.theglobaleconomy.com/Cambodia/lpg_consumption/ ; ERIA Cambodia Petroleum Master Plan 2022-2040 — https://www.eria.org/uploads/Cambodia-Petroleum-Master-Plan-2022-2024-final-March.pdf

### Myanmar — fabricated (high) — ⚠ AUDIT-ONLY, treat as provisional
The audit claims a near-total inversion: ~95% electric / ~4% LPG, not 4.96% / 94.3%. Its
strongest leg is a supply ceiling — the authored 94.3% LPG would require ~623,000 t/yr of
residential LPG, ~6× Myanmar's national LPG supply — and Myanmar is the one AMS whose LPG
`Cal` was left at the default 1.000 (never calibrated). **However, this is the only
finding that inverts the systemic direction** (electric *understated*, not overstated),
its adversarial pass never ran, and a 95% primary-electric share strains against the
post-coup grid situation. **Do not adopt without re-verification.** I flag it as the
single most important item to re-run when the session resets.
- MECS, 'Fuel Stacking Practices in Myanmar', Feb 2022 (World Bank MTF 2019) — https://mecs.org.uk/wp-content/uploads/2022/02/Fuel-Stacking-Practices-in-Myanmar.pdf
- WHO GHO `PHE_HHAIR_PROP_POP_CATEGORY_FUELS`, MMR — https://ghoapi.azureedge.net/api/PHE_HHAIR_PROP_POP_CATEGORY_FUELS?$filter=SpatialDim%20eq%20%27MMR%27 ; World Bank EG.CFT.ACCS.ZS (53.5%, 2023) https://data.worldbank.org/indicator/EG.CFT.ACCS.ZS?locations=MM
- Myanmar LPG supply: MECS 2022 citing Ministry of Commerce/Customs (103,776 t imported 2019); Myanmar LPG Group overview (~0.6% name LPG as main fuel) — https://www.mlpggroup.com/myanmar-lpg-market-overview/
- ADB Myanmar Energy Consumption Survey 2015 (firewood 73% / electricity 13% of cooking, 2014) — https://www.adb.org/publications/myanmar-energy-consumption-survey ; MECS 'Cooking with Electricity in Myanmar' 2021 — https://mecs.org.uk/wp-content/uploads/2021/09/Cooking-with-Electricity-in-Myanmar-barriers-and-opportunities.pdf
- Grid context: World Bank 'In the Dark: Power Sector Challenges in Myanmar', Aug 2023 — https://thedocs.worldbank.org/en/doc/6bd0c527c8469333b119d88cc0b8b410-0070062023/original/In-The-Dark-Power-Sector-Challenges-in-Myanmar-August2023.pdf

### Brunei Darussalam — materially wrong (med-high, VERIFIED)
NatGas 50% of Clean households is an energy-to-household misattribution: Brunei's piped
gas exists only in Belait district (~5% of national households), where the EBT records
gas used for cooking, water heating **and electricity generation**. The BDHECS household
count (Table 1.4) is a direct headcount; the survey's own 90%-electric cooking figure
(Fig 1.10) is the rice-cooker stacking trap, explicitly flagged in the source. Corrected
mix is LPG-dominant (~92%) with a ~5.5% NG tail. **Structural note:** this flips Brunei's
remainder holder from Natural Gas to LPG in the builder.
- ERIA / Ministry of Energy Brunei, Brunei Household Energy Consumption Survey (BDHECS, fieldwork 2015, pub. June 2020), Ch.1 Tables 1.3/1.4, Figs 1.10/1.15/1.17, §2/§4 — https://www.eria.org/uploads/media/Research-Project-Report/RPR-2020-03-Brunei-Darussalam-Energy-Consumption-Survey/07_Chapter-1-Brunei-Darussalam-Household-Energy-Consumption-Survey.pdf
- DEPS/MoFE, Brunei Population & Housing Census 2021 — https://deps.mofe.gov.bn/statistical-publications/ ; summary https://borneobulletin.com.bn/brunei-population-over-440000-in-2021/
- Fuel-subsidy context, Xinhua Mar 2026 — https://english.news.cn/asiapacific/20260317/548d513d9b6349b0951164326956389f/c.html ; Brunei National Climate Change Policy 2020 (no cooking-fuel measure) — https://faolex.fao.org/docs/pdf/bru216749E.pdf

### Lao PDR — materially wrong (med-high, AUDIT-ONLY)
LSIS III 2023 (MICS) measures the *primary* cookstove directly: LPG outnumbers electric
2.3:1 among clean-cooking households (5.6% vs 2.4% of members), contradicting the authored
56.1% electric. Proposed ConvElec 30 / LPG 69 / Biogas 1. **Caveat, stated honestly:** the
LPG `Cal = 1.705` points the *opposite* way (it says LPG share is too high), yet a direct
primary-stove survey outranks a calibration residual. The `Cal = 1.705` is itself the
other half of the Lao Rule-1 inversion and needs a separate LEAP-team re-fit — correcting
the base share does not by itself clear it.
- Lao Statistics Bureau / UNICEF / UNFPA, Lao Social Indicator Survey III (LSIS III / MICS) 2023, Tables TC.4.1–TC.4.2, pub. Feb 2025 — https://nipn.lsb.gov.la/wp-content/uploads/2025/02/LSIS-III-2023-SFR-Eng-13-02-2025-V_6_7-for-web-Bookmark.pdf.pdf
- World Bank/WHO clean-cooking access, Lao PDR (EG.CFT.ACCS.ZS) — https://data.worldbank.org/indicator/EG.CFT.ACCS.ZS?locations=LA
- ERIA / Lao MEM, 'Lao PDR Energy Statistics 2018', EBT 2015 Table 2.13 — https://www.eria.org/uploads/media/0_Lao_PDR_Energy_Statistics_2018_complete_book.pdf
- World Bank Lao Clean Cook Stove Initiative (P169538) 2019 — https://documents1.worldbank.org/curated/en/832231557366120799/pdf/Project-Information-Document-Lao-PDR-Clean-Cook-Stove-Initiative-P169538.pdf ; UN ESCAP NEXSTEP SDG7 Roadmap Lao PDR 2021 — https://nexstepenergy.org/web/sites/default/files/2021-08/SDG7_roadmap_for_Lao_PDR.pdf

### Singapore — materially wrong (med-high, AUDIT-ONLY)
Directionally sane (gas-dominant, town gas largest) but ConvElec 29.16% is ~10 pp too
high; electric-primary households are ~19%. Both gas shares are correspondingly too low —
exactly what the sub-1.0 gas `Cal` factors (LPG 0.745, NatGas 0.781) indicate. Proposed
ConvElec 19 / NatGas 56 / LPG 25.
- EMA via data.gov.sg, town gas consumption by dwelling type — https://data.gov.sg/datasets/d_e8fb7c462d24dac06375c552a776988c/view ; SingStat resident households (1,463,400 in 2024) — https://data.gov.sg/datasets/d_2bc812dbfd1e485638435fcdf7aac196/view
- EMA, Singapore Energy Statistics 2025, Ch.3 — https://www.ema.gov.sg/resources/singapore-energy-statistics/chapter3
- MTI parliamentary reply on natural gas — https://www.mti.gov.sg/newsroom/second-minister-s-iswaran-s-written-reply-to-parliament-question-on-natural-gas/ ; SingStat 'Our Data Explained – Energy and Utilities' (town gas ~900,000 customers) — https://www.singstat.gov.sg/find-data/explore-data-themes/industry/energy-and-utilities/our-data-explained
- NEA $300 Climate Vouchers (Apr 2024) — https://www.nea.gov.sg/media/news/news/index/300-climate-vouchers-for-all-hdb-households-from-15-april-2024

### Viet Nam — materially wrong (med-high, AUDIT-ONLY)
The LPG-dominant story is right but the split is an EBT-2020 *energy* split pasted into
*household-share* fields: 17% ConvElec overstates primary-electric by ~3–4×. WHO/CSIS/IEA
put primary electric at 4–6% of clean-cooking households. Proposed electric total 6.0
(ConvElec 3.5 + Induction 2.5) / LPG 93 / Biogas 1. **Structural note:** seeds Induction
at 2.5 in the base, a deviation from the design's "Induction = 0 at 2025" convention.
`Cal\LPG = 1.112` mildly disagrees (researcher flagged this openly).
- WHO GHO / Household Energy Database, `PHE_HHAIR_PROP_POP_CATEGORY_FUELS`, VNM (2024) — https://ghoapi.azureedge.net/api/PHE_HHAIR_PROP_POP_CATEGORY_FUELS?$filter=SpatialDim%20eq%20%27VNM%27
- CSIS (A. Scott) 2020, 'Access to … Modern Energy for All in Vietnam' (IEA/IRENA/WHO/World Bank + VHLSS) — https://csis-website-prod.s3.amazonaws.com/s3fs-public/200321_Scott_Energy_Vietnam_Background_V1.pdf
- UN ESCAP NEXSTEP Viet Nam 2023 — https://nexstepenergy.org/web/node/132343 ; SNV Vietnam Biogas Programme — https://www.snv.org/project/vietnam-biogas-programme
- Market context: 6Wresearch Vietnam Household Cooking Appliance Outlook 2025 — https://www.6wresearch.com/industry-report/vietnam-household-cooking-appliance-market-outlook ; Euromonitor — https://www.euromonitor.com/large-cooking-appliances-in-vietnam/report

### Philippines — minor issues (high, AUDIT-ONLY)
Essentially legitimate and NOT an EBT artifact — the 2022 NDHS independently reproduces
both the 59.5% clean-access key (59.3% of households) and the 94.4% LPG share. Only defect:
ConvElec 5.6 is ~1.6 pp high vs measured primary-electric 3.5% of Clean. Proposed ConvElec
4.0 / LPG 96.0.
- PSA & ICF, 2022 Philippine NDHS Final Report FR381, Tables 2.2 (p.19) & 2.4 (p.21), 2023 — https://www.dhsprogram.com/pubs/pdf/FR381/FR381.pdf
- DOE Philippines, '2023 Household Energy Consumption Survey (HECS)', IEA SE-Asia workshop 11 Jun 2025 — https://iea.blob.core.windows.net/assets/f0dca78d-a348-49e2-af4a-8213a41eef13/20250610_Philippines_IEAPresentationHECS_IEAWorkshop_final.pdf ; PSA press release — https://psa.gov.ph/content/percentage-households-using-electricity-increased
- World Bank WDI EG.CFT.ACCS.ZS, PH 59.1% (2022) — https://data.worldbank.org/indicator/EG.CFT.ACCS.ZS?locations=PH ; DOE Philippine Energy Plan 2023-2050 — https://doe.gov.ph/pep/philippine-energy-plan-2023-2050

### Indonesia — minor issues (high, VERIFIED) — the healthiest of the ten
Structurally correct: Susenas 2024 confirms an overwhelmingly LPG-primary clean arm
(~98%), reflecting the LPG conversion programme. Only sub-percentage-point tweaks
(ConvElec 1.45→0.53, NatGas 0.51→1.21, Biogas 0.29→0.02); LPG stays the Remainder holder.
A separate note: LPG `Cal = 0.537` reflects an under-scaled cooking UEI, not a share error
— that is a UEI matter for the LEAP team, not a base-mix fix.
- IISD, 'Indonesia's Next Cooking Transition', Dec 2025, Fig.1 'Main fuel for cooking 2024' + Table 1 (Susenas 2024) — https://www.iisd.org/system/files/2025-12/indonesia-next-cooking-transition.pdf ; BPS main-cooking-fuel table — https://www.bps.go.id/en/statistics-table/2/MTUwIzI=/persentase-rumah-tangga-menurut-provinsi-dan-bahan-bakar-utama-untuk-memasak.html
- PGN jargas (815k homes on piped gas by 2024), ANTARA Jan 2025 — https://megapolitan.antaranews.com/berita/417957/pgn-815-ribu-rumah-tersambung-jaringan-gas-per-2024
- SNV Indonesian Domestic Biogas Programme (BIRU) — https://www.snv.org/project/indonesian-domestic-biogas-programme-biru
- IEA SDG7 access to clean cooking 2023 — https://www.iea.org/reports/sdg7-data-and-projections/access-to-clean-cooking ; World Bank WDI EG.CFT.ACCS.ZS — https://data.worldbank.org/indicator/EG.CFT.ACCS.ZS

### Malaysia — materially wrong (medium) — BELOW the adoption bar, listed for completeness
ConvElec 12.7 is ~3× too high (WHO Household Energy Database puts primary-electric at
~0.2% of population, flat 2018-2023); NatGas 0.1 is ~10× too low; `Cal\LPG = 0.603`
confirms the direction. Proposed ConvElec 3.5 / Induction 0.5 / LPG 95 / NatGas 1. Held
back only because its confidence is `medium`, under your medium-high bar.
- WHO Household Energy Database, Malaysia (primary-electric ~0.2% of population) — https://www.who.int/data/gho/data/themes/air-pollution/who-household-energy-db
- (Verifier pass did not complete for Malaysia; single-pass audit only.)

## Knock-on: does this resolve the Rule-1 energy inversion?

The earlier illustration ([`illustrate_cooking_energy_ordering.py`](../illustrate_cooking_energy_ordering.py))
found the only two real BAS≥ATS≥RAS energy inversions were Cambodia and Lao PDR.

- **Cambodia — resolved.** The inversion was caused by phasing out the 48.2% biogas
  share whose effective efficiency is 886% (`Cal = 15.545`). Correcting biogas to 2.0
  removes the phantom fuel from the phase-out, so electrifying no longer raises energy.
- **Lao PDR — partially; needs a LEAP-team re-fit.** The driver is `Cal\LPG = 1.705`
  (LPG effective efficiency 95.5%, beating induction). Raising the LPG base share does
  not by itself lower that `Cal`; the LEAP team must re-fit the Lao LPG `Cal` against the
  corrected base. The residual inversion is small (<1.3%).

Independently, the **minor-fuel decay asymmetry** in the builder (ATS minors decay
linearly, RAS minors on the logistic `progress`, giving 22 small RAS>ATS cells) is a
separate code bug, unaffected by the base correction, and still worth a cheap fix.

## Structural notes for the rebuild (not yet applied)

1. **Brunei remainder holder** flips Natural Gas → LPG (LPG is now the majority fuel).
2. **Viet Nam / Malaysia** introduce a small nonzero Induction share at 2025, deviating
   from the design's "Induction = 0 everywhere at 2025" convention — decide whether to
   keep the seed or fold it into Conventional Electric.
3. **Supporting Key re-fits move with the shares.** Where a share moves a lot, the paired
   `Key\Cal\Residential\<fuel>` must be re-fitted by the LEAP team or the balance breaks
   the other way — most acutely Thailand (`Cal\Cook and Light Non Elec` 5 → ~1.7,
   `Cal\LPG` 0.556 → ~1.0). These are LEAP-team calibration actions, not author-side share
   edits.
4. **Confidence flags in `COOKING_DESIGN_20260710.md` §(f)** need revising: Thailand's
   "high" rested entirely on "already ~85% electric" and must drop.

## Base-year vs model-output gap (handoff to LEAP team)

The 2024 mix has **never been checked against LEAP's own output**: the v0.71 extract
(`Raw/cooking_results_v071.csv`) contains no Current Accounts scenario and reports 0 PJ
for cooking at 2010/2020 — the earliest year carrying energy is 2030. A base-year
Current-Accounts extract is needed to close this loop.

## Files

| File | What |
|---|---|
| [`audit_cooking_base_year.py`](../audit_cooking_base_year.py) | Extracts authored 2024 mix + Cal distortion + energy-implied mix |
| [`cooking_base_year_2024.csv`](cooking_base_year_2024.csv) | One row per Country × Fuel: authored share, Cal factor, distortion flag |
| [`cooking_base_year_2024.png`](cooking_base_year_2024.png) | Authored within-Clean mix per AMS, red where the balance disagrees |
| [`illustrate_cooking_energy_ordering.py`](../illustrate_cooking_energy_ordering.py) | Rule-1-in-energy illustration (non-blocking) |
| [`cooking_energy_ordering.csv`](cooking_energy_ordering.csv) / [`.png`](cooking_energy_ordering.png) | Clean-arm energy index per AMS/scenario + inversion flags |
| [`cooking_effective_efficiency.csv`](cooking_effective_efficiency.csv) | `nominal × Cal` effective efficiency ladder per AMS |
