# Residential — LEAP Action Items

> **Update 2026-06-24 — Fridge per-leaf inject built.** The refrigeration
> team's mapping workbook (`.mailbox/Refrigerator LEAP Input Mapping.xlsx`,
> filed to `Fridge/Raw/`) is now implemented as
> `LEAP Input/fridge_leap_inject.csv` (12,690 rows) via
> `Fridge/build_fridge_leap_inject.py`. It emits, per (Size × Efficiency) leaf:
> Activity Level decomposition (parent ownership / size share / per-scenario
> efficiency mix), **Efficiency** (kwh_high/kwh_cell → High_eff = 100%),
> **Useful Energy Intensity** (TOE, keyed to the size's High_eff reference), and
> **Demand Cost** (BAS/ATS = annualised capital at 9% over 12 yr; RAS = capital +
> electricity O&M = per-AMS tariff × kwh_unit). RAS is now a LEAP **optimisation**
> scenario (RASv2 in docs, "RAS" string in CSV) with the device/constraint
> variables left blank/unconstrained. Useful-energy method + the corrected
> Efficiency polarity + tariff/discount sources are documented in
> `LEAP Input/fridge_leap_input_mapping.md`, `data_sources.md §3.6`, and
> `Fridge/build_fridge_leap_inject.txt`. Wide 9-cell `fridge_sales_projection.csv`
> retained as the upstream source; the inject is the paste target for Fridge.
> **AC built 2026-06-24** (mirrors Fridge): `ac_leap_inject.csv` (12,690 rows) via
> `AC/build_ac_leap_inject.py`, same 14-variable useful-energy mapping. AC specifics:
> 15-yr life (CRF 0.124), units-per-household via `stock_per_hh` (Option A — AC
> owning-HH hold 1.2–3.4 units), Demand Cost/FEI per unit; shared tariffs + 9% rate.
> Drift variant `ac_leap_inject_drift.csv` (BAS 0.5% / ATS 1.5% / RAS 2.5% per yr).
> Docs: `ac_leap_input_mapping.md`, `ac_leap_rowwise_method.md`, `ac_leap_drift_method.md`.
> Both AC + Fridge now have frozen + drift injects. Load Shape left at LEAP default.
>
> **Update 2026-06-25 — Fridge Unit Capacity filled.** `unit_capacity_kw` (workbook
> row 14) added to both fridge injects = kwh_high(size)÷8760 (per-device service
> power; Small 0.035 / Medium 0.052 / Large 0.057 kW), same across efficiency tiers,
> fixed over years, **RAS leaves only** (blank BAS/ATS, per LEAP "optimised branches
> only"). Other RAS optimisation vars (rows 7–13) stay blank. **AC Unit Capacity
> still pending** its load-shape-hours basis (flat 8760 vs ~1600-h cooling shape).
>
> **Update 2026-06-30 — AC mirrors Fridge: Unit Capacity + `Exogenous Devices` (Weibull).**
> `unit_capacity_kw` now filled on both AC injects = kwh_high(size) ÷ FLEH from each
> country's CDD cooling load shape (per Country×Size, RAS leaves only) — resolves the
> "AC Unit Capacity pending" item above. The named per-country Energy Load Shape is a
> SEPARATE manual LEAP upload, **NOT injected**. New `ac_exo_device.csv` (2005–2060) is the
> AC `Exogenous Devices` input: existing fleet retiring (Weibull k=3, mean **15 yr**), no
> additions (LEAP optimises them); 2025 fleet 97,820 k (= our AC projection) → ~0 by ~2055.
> Built by `build_ac_exo_device.py` (+ `build_ac_device_numbers.py`). AC injects carry no
> device column (exo device is its own file), mirroring Fridge.
>
> **Update 2026-06-30 — Fridge `Exogenous Devices` carries Weibull retirement.**
> New file `fridge_exo_device.csv` (2005–2060) is the LEAP `Exogenous Devices` input.
> Since the leaf optimises device ADDITIONS endogenously, the slot receives only the
> EXISTING fleet decaying by retirement (no additions): the 2025 fleet (146,579 k) is
> frozen and retired forward with a Weibull curve (shape k=3, mean 12 yr), declining to
> ~0 by ~2050; LEAP supplies all post-2025 additions. The 2025 age structure is
> reconstructed from the historical stock build-up. Built by `build_fridge_exo_device.py`
> from `fridge_device_numbers.csv`. **The injects no longer carry `device_thousand`**
> (dropped 2026-06-30 from both `build_fridge_leap_inject.py` and `_drift.py` and
> regenerated): exogenous devices live only in `fridge_exo_device.csv`. `unit_capacity_kw`
> stays in the injects.
>
> **Update 2026-06-29 — Fridge device numbers re-based to the LEAP export + back-cast.**
> The base-year `device_thousand` in both fridge injects is now sourced DIRECTLY from
> the LEAP RAS Demand Devices export (`Raw/demand_devices_ras_2025.xlsx` →
> `convert_demand_devices.py` → `Raw/demand_devices_ras_2025.csv`), so the injected 2025
> count matches what LEAP holds: **ASEAN total 146,579 k** (was a provisional 134,036 k).
> Still 2025-only in the injects; identical across BAS/ATS/RAS (scenario-invariant physical
> fleet — the within-size split is the RAS-optimised one from the export). Ownership is
> now BACKED OUT from the fleet (devices ÷ households), superseding the provisional value.
> The standalone table is renamed `fridge_device_numbers.csv` and **extended to 2005–2025**:
> 2025 = export, earlier years via a per-country Gompertz ownership-penetration back-cast
> (asymptote 150 fridges/100 HH, anchored at the 2025 value) × households. Reporting/seed
> only — NOT a projection driver, does not touch the energy. AC device numbers still TBD.
>
> **Superseded 2026-06-25 entry** (kept for history): device_thousand was
> Households × ownership_pct/100 (provisional ownership, ASEAN 134,036 k, standalone
> `fridge_device_numbers_2025.csv`).
>
> **Variant added 2026-06-24:** `fridge_leap_inject_drift.csv` (via
> `build_fridge_leap_inject_drift.py`) adds an optional within-tier
> efficiency-drift lever (each tier's kWh improves over time: BAS 0.5% / ATS 1.0%
> / RAS 2.0% per yr) on top of the composition shift, double-count avoided by
> construction. Frozen `fridge_leap_inject.csv` is unchanged — pick one at paste
> time. Method: `fridge_leap_drift_method.md`.

## Master action table — all LEAP-side work pending

> **2026-07-15 — Phase-2 inject set complete on `20260708_Appliances_P2_YY`; ready for the
> LEAP-side paste + run.** All four Phase-2 end uses now have their deliverables on the branch,
> with the known authoring blockers resolved:
> - **Cooking** (merged via PR #10, `49ce6d57`): `cooking_canonical_input.csv` (180 within-Clean
>   Activity Level rows) + `cooking_stove_characteristics.csv` (391 rows — uniform stove Efficiency
>   per technology across all AMS, no per-country Cal, + the Lao Clean Cooking Access fix). Base mix
>   and BAS/ATS/RAS trajectories corrected on adversarially-verified primary-stove surveys; Rule 1
>   (BAS ≥ ATS ≥ RAS energy) holds in all 360 country-year cells. **Paste handoff:** re-establish
>   cooking base-year calibration via an activity/demand-level Cal, NOT the stove-efficiency term.
> - **New Fridge** (`ec5f52df`): Refrigeration_ ATS>BAS inversion fixed (`ATS_HIGHEFF_FRACTION=0.3`,
>   BAS ≤ ATS ≤ RAS by construction); exo fleet re-matched to the real 2025 base composition.
> - **New AC** (`ec5f52df`): ×100 ownership scale fix (parent Activity Level now per-100-HH), so the
>   new AC_ tree scales correctly. Old AC/Fridge legacy trees stay ON as the calibration baseline.
> - **Nine appliances** (`ec5f52df`): `appliance_efficiency_paste.csv` (651 rows) — Existing/Efficient
>   share lever for the 7 two-tier appliances + Water Heating (BAS 0 / ATS 30 / RAS 70 by 2050).
> - **Lighting** (`ec5f52df`): LEAP-native paste `Lighting/Outputs/lighting_leap_paste.csv` regenerated
>   from the FDF curve, superseding the single-column kWh/HH.
>
> Remaining before results are trustworthy is the LEAP-side paste + BAS/ATS/RAS run + the Phase-2
> audit (NEXT_STAGE §C) — not further authoring. Still open as LEAP-team questions (not blockers):
> the AC activity-vs-stock calc-path, and the cooking activity-level Cal above.

**Original Wave C status (2026-05-19, superseded above for scope):** Wave C handoff package landed
2026-05-19 on branch `20260421_Appliances_YY` (Phase 5 of the Appliances workflow).
Three subsectors (AC, Fridge, Lighting) ship a three-scenario
(BAS + ATS + RAS) LEAP-Input CSV each; per Residential/DESIGN.md §2.2
RASv1 methodology lock (2026-05-19).

Source-of-truth artefacts: LEAP-ready CSVs co-located under
`Residential/LEAP Input/` alongside this doc (relocated 2026-05-19
from per-subsector `Residential/{AC, Fridge, Lighting}/LEAP Input/`
to centralise the inject batch). No apply script landed yet — inject
team paste-target via the existing interactive `input_to_LEAP_v2.py`
driver pattern used by prior Wave A/B handoffs.

> **Lighting re-scope (2026-05-20).** The inject team's
> `.mailbox/LIGHTING_TEAM_HANDOVER_20260520.md` (LEAP area
> `aeo9_v0.46`) revealed the Lighting branch is a **five-technology
> stack** (Incandescent / CFL / Fluorescent / Halogen / LED) that
> computes Final Energy Intensity in-LEAP from drivers — so the
> single-column kWh/HH paste does **not** apply. `lighting_kwh_hh.csv`
> is **superseded for LEAP ingestion**; Lighting now ships two
> deliverables — `lighting_tech_shares.csv` (per-tech `Activity Level`)
> and `lighting_bulb_wattage.csv` (per-tech `Bulb Wattage`). AC + Fridge
> are unchanged. `BulbsPerHH` / `LightingHours` stay at LEAP defaults
> this pass; `Other`-arm (Kerosene+Candles, Solar) deferred. See §A3.

### Structural creates

**NONE.** All three subsectors write to existing LEAP branches under
`Demand\Residential\{AC, Fridge, Lighting}\...`. No new branches,
no new fuels, no new transformation processes. Phase 3 pipeline
extensions reused the existing schemas; only the row counts grew
(scenario dimension expanded from 2 → 3).

### Bulk value pastes (3 CSVs, one per subsector)

| # | Source CSV | Schema (load-bearing cols) | LEAP variable(s) updated | Rows | Detail in |
|---|---|---|---|---|---|
| W1 | `LEAP Input/ac_leap_inject.csv` (per-leaf; built 2026-06-24 from `ac_sales_projection.csv`) | Country, Year, Scenario, Size_group, Efficiency_level, units_per_hh_parent, size_share_pct, eff_share_pct, efficiency_pct, useful_energy_intensity_toe, demand_cost_usd_per_unit (+ components) | Activity Level (parent units/HH via stock_per_hh + size/leaf) + Efficiency + Useful Energy Intensity + Demand Cost per (Size × Efficiency) leaf | 12,690 | §A1 + `ac_leap_input_mapping.md` |
| W2 | `LEAP Input/fridge_leap_inject.csv` (per-leaf; built 2026-06-24 from `fridge_sales_projection.csv`) | Country, Year, Scenario, Size_group, Efficiency_level, ownership_parent_pct, size_share_pct, eff_share_pct, efficiency_pct, useful_energy_intensity_toe, demand_cost_usd_per_hh (+ components) | Activity Level (parent/size/leaf) + Efficiency + Useful Energy Intensity + Demand Cost per (Size × Efficiency) leaf | 12,690 | §A2 + `fridge_leap_input_mapping.md` |
| W3a | `LEAP Input/lighting_tech_shares.csv` | Country, Year, Scenario, Tech (Incandescent/CFL/Fluorescent/Halogen/LED), share_percent (load-bearing), source | Per-tech `Activity Level` (% of grid-lit households) on the five `…\Lighting\Electricity\<Tech>` leaves | 5,400 | §A3 |
| W3b | `LEAP Input/lighting_bulb_wattage.csv` | Country, Tech, watts (load-bearing), source | Per-tech `Bulb Wattage` (W) on the five Electricity leaves | 50 | §A3 |
| ~~W3~~ | ~~`LEAP Input/lighting_kwh_hh.csv`~~ | — | **SUPERSEDED 2026-05-20** — kWh/HH is a LEAP formula, not a paste target; retained as internal diagnostic only | ~~1,080~~ | §A3 |
| | **TOTAL writes** | | | **30,830 data rows** (AC 12,690 + Fridge 12,690 + Lighting tech-shares 5,400 + Lighting wattage 50) | |

### Post-paste verification

| # | What | Detail in |
|---|---|---|
| V1 | Three-scenario compilation (BAS, ATS, RAS all run cleanly) + AEO-9 baseline scenarios spot-check (Indonesia 2040 sales × kWh; AC Singapore 2060 RAS High_eff = 100 %; Lighting Singapore 2040 RAS LED = 100 %) | §B |
| V2 | Per-subsector `_sanity.py` re-run after paste; reports persisted | §B |

---

**Date: 2026-05-19** *(Phase 5 of the Appliances workflow on branch
`20260421_Appliances_YY`)*
**Prepared by:** YY
**Apply script:** none landed yet — paste via `input_to_LEAP_v2.py`
interactive driver.

This note lists everything that needs to be entered or updated in LEAP
to land the Residential-side three-scenario baseline. Reference data
(per-AMS values, trajectories, citations) lives in the three CSVs
alongside this file's referenced subsector folders. Methodology
justification + design decisions live in
[`../DESIGN.md`](../DESIGN.md); per-source citations live in
[`../data_sources.md`](../data_sources.md).

---

## Naming convention enforced (DESIGN.md §2.2)

| Layer | String written |
|-------|----------------|
| Documentation (DESIGN.md, NOTES.md, commit messages) | `RASv1` |
| CSV `Scenario` column (all three subsectors) | **`RAS`** (plain) |
| LEAP branch names (where scenario string is needed) | **`RAS`** (plain) |
| Future iteration | `RASv2` in docs once methodology evolves; CSV string still `RAS` for LEAP scenario compatibility |

**Hard rule:** No row in any of the three LEAP-Input CSVs may carry
the `RASv1` string in its `Scenario` column. Phase 4 sanity check
`projection:scenarios` enforces this. Verify at handoff with:

```bash
grep -c '^[^,]*,[^,]*,RASv1' Residential/*/LEAP\ Input/*.csv  # must return 0 per file
```

---

## Alias maps

### Countries (Country column → LEAP branch / scenario label)

All three CSVs use AEO-9 canonical full names; map identically across
subsectors. No alias translation needed at paste time if the LEAP tree
uses the same names.

| AEO-9 canonical (CSV value) | Common variants seen elsewhere |
|----------------------------|-------------------------------|
| Brunei Darussalam | Brunei, BRN |
| Cambodia | KHM |
| Indonesia | IDN |
| Lao PDR | Laos, LAO |
| Malaysia | MYS |
| Myanmar | Burma, MMR |
| Philippines | Phillipines (sic — appears only in source data), PHL |
| Singapore | SGP |
| Thailand | THA |
| Viet Nam | Vietnam, VNM |

### Size_group / form-factor (Size_group column → LEAP branch level)

| Subsector | Values | Notes |
|-----------|--------|-------|
| AC | `Small`, `Medium`, `Large` | Cooling-capacity terciles (small <1.5 ton; medium 1.5-2 ton; large >2 ton, approx) |
| Fridge | `Small`, `Medium`, `Large` | Capacity-litre terciles per Euromonitor |
| Lighting | `Lamp`, `Tube` | Form-factor split — **applies only to the superseded kWh/HH diagnostic**. The live LEAP Lighting inject (`lighting_tech_shares.csv`) is keyed by `Tech` ∈ {Incandescent, CFL, Fluorescent, Halogen, LED}, NOT Size_group (see §A3). |

### Efficiency_level (Efficiency_level column → LEAP branch level)

| Value | Definition (subsector-specific) | Notes |
|-------|-------------------------------|-------|
| `High_eff` | AC: CSPF ≥ 5.0 (absolute band, Option 1 classifier). Fridge: top tercile by EPL. Lighting: efficacy ≥ 120 lm/W. | Best-in-class tier |
| `Mid_eff` | AC: 3.5 ≤ CSPF < 5.0. Fridge: middle tercile. Lighting: 90 ≤ efficacy < 120 lm/W. | Middle tier |
| `Low_eff` | AC: CSPF < 3.5. Fridge: bottom tercile. Lighting: efficacy < 90 lm/W. | Standard / baseline tier |

### Scenario (Scenario column → LEAP scenario name)

| Value | Meaning | RASv1 alias? |
|-------|---------|--------------|
| `BAS` | Baseline | — |
| `ATS` | Accelerated Transition Scenario (national policy) | — |
| `RAS` | Regionally Aspirational Scenario (RASv1 in docs) | **YES** — plain `RAS` in CSV / LEAP per §2.2 convention |

---

## LEAP branch target convention

Branches assumed under `Demand\Residential\{AC, Fridge, Lighting}\`
mirroring the per-subsector subtree structure used in Wave A
(Transport) and Wave B (Bioenergy + Fossils). Exact branch names
**to be confirmed at inject-team handoff** against the active `.leap`
file (likely `aeo9_v0.25_ras_results` or its successor).

Typical paste targets per subsector:

- **AC / Fridge** (2-layer Size × Efficiency, 9 leaves) — **structure
  being rebuilt LEAP-side (Option A, 2026-05-21).** The 2026-05-20
  refrigeration handover showed a flat 3-tier placeholder; the
  modelling team is nesting `…\Projections\{Refrigeration|AC}\{Size}\
  {Low/Mid/High eff}` so the existing 9-cell inject lands 1:1. Parent
  `Activity Level` = ownership (scenario-invariant); size-node
  `Activity Level` = size share (scenario-invariant); efficiency-leaf
  `Activity Level` = within-size mix (per-scenario); leaf
  `Final Energy Intensity`/`Uncalibrated` = `kwh_unit`. Full mapping:
  [`structure_request_AC_fridge_2layer_20260521.md`](structure_request_AC_fridge_2layer_20260521.md).
  New AC + Fridge handovers will follow the rebuild; per-leaf CSV emit
  waits for those.
- **Lighting** (five-technology stack, confirmed against `aeo9_v0.46`
  via the 2026-05-20 inject-team handover — exact paths known, not
  assumed):
  - `Demand\Residential\Projections\Lighting\Electricity\<Tech>` —
    `Activity Level` (share_percent from `lighting_tech_shares.csv`) and
    `Bulb Wattage` (watts from `lighting_bulb_wattage.csv`), for each
    Tech ∈ {Incandescent, CFL, Fluorescent, Halogen, LED}.
  - `Final Energy Intensity` is a **LEAP formula** (BulbsPerHH × Bulb
    Wattage × LightingHours × 365 × calibration / 1000) — do NOT paste.
  - `BulbsPerHH` / `LightingHours` at the parent `…\Lighting\Electricity`
    node — leave at LEAP defaults (7 / 6 h) this pass.
  - `Other` arm (`…\Lighting\Other\{Kerosene and Candles, Solar
    Lighting}`) — deferred (handover §2.3).

A LEAP-tree snapshot for AC / Fridge exact branch paths is still
deferred to the inject-team handoff session (Lighting paths are already
confirmed above); can be added by running a `leap_com.py`
`flatten_nodes` walk over `Demand\Residential\` when COM access is
available — analogous to the snapshot Transport captured in Wave A.

---

## A. Bulk paste walkthrough (per CSV)

### A1. AC sales projection — `LEAP Input/ac_sales_projection.csv`

**Schema** (16 columns, 12,690 rows = 10 AMS × 47 years (2014–2060)
× 9 (Size × Efficiency) cells × 3 scenarios):

| Column | Type | Notes |
|--------|------|-------|
| Country, Year, Scenario, Size_group, Efficiency_level | keys | Composite primary key; Scenario ∈ {BAS, ATS, RAS} |
| sales_thousand | float | Annual unit sales (thousands) per cell. **Load-bearing**. |
| stock_thousand | float | Vintage-stock total (15-yr lifespan) per cell. Read-only diagnostic. |
| kwh_unit | float | Per-unit annual energy use (kWh/yr). Inherited from V6 `size_efficiency_summary.csv:kwh_unit` — frozen across all years and scenarios. |
| price_usd | float | Per-unit price (USD). Evolves with the BAS / ATS / RAS premium-decay rate (-2 % / -3 % / -3 % per yr respectively; ATS and RAS share decay). |
| stock_pct, sales_pct, ownership_pct | float | Stock / sales / ownership share per cell. Diagnostics. |
| total_stock_thousand, penetration_pct, intensity, stock_per_hh | float | AMS-year aggregates (same value across all 9 cells within (Country, Year, Scenario)). |
| source | string | `historical` (Year ≤ 2023) or `projected` (Year ≥ 2024). |

**Scenarios** (DESIGN.md §3 + §2.2):

- **BAS**: efficiency shares frozen at 2023 mix; ownership grows
  with GDP_pc + climate factor; intensity (units/HH) saturates at 3.5
  for tropical multi-room housing.
- **ATS**: blend toward each AMS's cluster-typical efficiency mix at
  the cluster-transition year (±10 yr window, steepness 0.25) plus
  30 % weight on inverter-driven evolution. Renormalised per Size.
- **RAS** (RASv1): blend toward 100 % High_eff per Size globally
  via `logistic_transition(2025, 2035, 0.35)`; no inverter overlay
  (the 100 % target subsumes it). Pre-2035 progress smoothly ramps;
  post-2035 frozen at 100 % High_eff per Size.

**Known caveats** (also flagged by `Residential/AC/_sanity.py`):

- **V6 price sample-bias** (DESIGN.md §3.5) — Medium / Large
  Mid_eff price means non-monotonic relative to Low_eff for some
  AMS. `PRICE_FLOOR_RATIO = 1.05` binds at `evolve_price` time so
  the artefact is bounded. Visible as `[Sanity:summary:price_floor_rule]`
  + `[Sanity:summary:price_mid_monotonic]` WARNs.
- **ATS < BAS High_eff for PH / TH / VN** — these three AMS were
  already above their cluster-typical Small High_eff at 2023 (V6
  sample bias toward LED-heavy markets), so ATS's cluster-target
  blend pulls them slightly DOWN before recovering. Pre-existing
  model behaviour, not introduced by RASv1 work. WARN at
  `[Sanity:projection:bas_le_ats_high_share]`.
- **2024–2025 warm-up: ATS > RAS** — ATS leverages past cluster
  transitions + inverter overlay; RAS's 2025-2035 logistic is only
  ~5 % engaged at 2024. RAS overtakes by 2026 and converges to
  100 % High_eff by 2035. Steady-state (Year ≥ 2026) check passes
  cleanly. WARN at `[Sanity:projection:ats_le_ras_high_share_warmup]`.

**Paste guidance:** load via `input_to_LEAP_v2.py`. Filter rows by
Scenario when injecting per-LEAP-scenario; cell key = (Size_group,
Efficiency_level) maps to the corresponding LEAP branch leaf.

### A2. Fridge sales projection — `LEAP Input/fridge_sales_projection.csv`

**Schema** (15 columns, 12,690 rows = same dimensions as AC):

| Column | Type | Notes |
|--------|------|-------|
| Country, Year, Scenario, Size_group, Efficiency_level | keys | Same scheme as AC |
| sales_thousand | float | Annual unit sales (thousands) per cell. **Load-bearing**. |
| stock_thousand | float | Vintage-stock total (12-yr lifespan) per cell |
| kwh_unit | float | Per-unit annual kWh; from Euromonitor `size_efficiency_summary.csv` |
| price_usd | float | Per-unit price (USD); same premium-decay rule as AC |
| stock_pct, sales_pct, ownership_pct | float | Cell-level shares |
| total_stock_thousand, total_ownership_pct | float | AMS-year aggregates |
| source | string | `historical` / `projected` |

**Scenarios** (DESIGN.md §4 + §2.2):

- **BAS**: efficiency shares frozen at last-observed AMS mix
  (or 2-NN imputation for the four data-missing AMS: BRN / KHM / LAO / MMR).
- **ATS**: blend toward each AMS's cluster-typical mix at the
  cluster-transition year (±10 yr window, steepness 0.25).
- **RAS** (RASv1): blend toward 100 % High_eff per Size via
  `logistic_transition(2025, 2035, 0.35)`. Same pattern as AC RAS.

**Known caveats:**

- **ATS < BAS for PH / VN High_eff Small** — same pattern as AC:
  PH/VN already above cluster-typical Small High_eff at 2023.
  Documented WARN at `[Sanity:projection:bas_le_ats_high_share]`.
- **2024–2025 warm-up: ATS > RAS** — same artefact as AC (2 cells
  for Fridge vs 53 for AC). Resolves by 2026.
- **2-NN fill quality for BRN / KHM / LAO / MMR** — these four AMS
  inherit Indonesia / Viet Nam / Thailand fridge sales patterns
  via 2-NN on (log GDP_pc, logit urbanisation). Reasonable proxy;
  refresh when AEO-9 fridge sales survey lands per
  `Fridge/Old/StockSales_LEAP_Input/Fridge Sales Projection Full_alternate.csv`
  pending update.

### A3. Lighting — five-technology stack (LEAP-tree remap 2026-05-20)

**Why the shape changed.** The LEAP Lighting branch
(`Demand\Residential\Projections\Lighting\Electricity\<Tech>`) is a
five-technology stack that computes `Final Energy Intensity` itself from
`BulbsPerHH × Bulb Wattage × LightingHours × 365 × calibration / 1000`.
It does **not** accept a kWh/HH paste. Lighting therefore ships two
deliverables; `lighting_kwh_hh.csv` is superseded for LEAP (kept as an
internal efficacy-mix diagnostic). Authoring spec:
`.mailbox/LIGHTING_TEAM_HANDOVER_20260520.md` §2–§4.

**Paste targets** — the five Electricity tech leaves (Incandescent,
CFL, Fluorescent, Halogen, LED). The `Other` arm (Kerosene+Candles,
Solar Lighting) is **deferred** (handover §2.3, variables TBD).
`BulbsPerHH` (7) and `LightingHours` (6 h) stay at **LEAP defaults**
this pass — do NOT author them (handover open Q1/Q2). The fuel-group
`Activity Level` (electrification rate) is a LEAP formula — leave it
(handover §4.2).

#### A3a. `LEAP Input/lighting_tech_shares.csv` → per-tech `Activity Level`

**Schema** (6 columns, 5,400 rows = 10 AMS × 36 yr (2025–2060) × 3
scenarios × 5 techs):

| Column | Type | Notes |
|--------|------|-------|
| Country, Year, Scenario, Tech | keys | Tech ∈ {Incandescent, CFL, Fluorescent, Halogen, LED}; Scenario ∈ {BAS, ATS, RAS} |
| share_percent | float | **Load-bearing.** % of grid-lit households on this tech. The 5 Tech rows for a (Country, Year, Scenario) sum to 100. Paste into the tech leaf's `Activity Level`. |
| source | string | Always `projected`. |

**Scenarios** (DESIGN.md §5.12 + §2.2): BAS freezes the 2023 mix; ATS
blends toward 100 % LED by 2040 (steepness 0.3); RAS toward 100 % LED
by 2035 (steepness 0.35) via `blend_shares` (`00Guide/ref_curves.py`).
ASEAN-mean LED share: 2025 ≈ 56.8 % (all scen) → 2035 ATS 88 % / RAS
100 % → 2040+ both 100 %.

**Paste guidance:** filter rows by Scenario, then by Tech; map each Tech
to its `…\Electricity\<Tech>` leaf `Activity Level`. The team maps
Country → LEAP region name (see handover §4.3 country-mapping note).

#### A3b. `LEAP Input/lighting_bulb_wattage.csv` → per-tech `Bulb Wattage`

**Schema** (4 columns, 50 rows = 10 AMS × 5 techs):

| Column | Type | Notes |
|--------|------|-------|
| Country, Tech | keys | Tech ∈ {Incandescent, CFL, Fluorescent, Halogen, LED} |
| watts | float | **Load-bearing.** Per-tech bulb wattage. LED = per-AMS catalogue median (7.0–13.0 W vs LEAP default 7.2 W); Incandescent 60 / Halogen 42 / CFL 14 / Fluorescent 32 W (regional reference, all AMS). |
| source | string | Provenance per row (catalogue median vs DOE/ENERGY STAR/U4E reference). |

**Known caveats:**

- **Tech mix is a triangulated placeholder** —
  `Lighting/Outputs/lighting_tech_mix_2023.csv` carries
  `source_tier = triangulated-placeholder` + `refresh_needed = True`
  for all 10 AMS (U4E 2020 + IEA SEA EO 2022 + AEO-8 / ACE-2026).
  Catalogue is LED-only, so the five-tech split is sourced externally,
  not derived. Refresh = values-only update when U4E-2026 lands.
- **LED wattage is a product-catalogue median** — sits slightly above
  LEAP's installed-stock 7.2 W default (catalogue over-represents
  high-output bulbs; median used to dampen the skew). The team may
  prefer LEAP's 7.2 W; both are available.
- **Non-LED wattages are region-flat** — our catalogue holds no
  incandescent/CFL/fluorescent/halogen products, so per-AMS variation
  is not estimable; 60 W-equivalent reference constants used.

---

## B. Known gaps + caveats (cross-cutting)

1. **AC catalogue: V6 price sample-bias** (DESIGN.md §3.5) — 32 % of
   V6 rows carry USD prices; per-cell means exhibit sample-selection
   artefacts (Medium Mid<Low, Large Mid<Low, Large High<1.05×Low).
   `PRICE_FLOOR_RATIO = 1.05` enforces a price floor at evolve_price
   time; AC `_sanity.py` flags the artefacts as WARN, not FAIL.
2. **Fridge sales for BRN / KHM / LAO / MMR** — no AMS-direct
   Euromonitor coverage. 2-NN fill from observed AMS in service.
   Refresh pending AEO-9 fridge sales survey.
3. **Lighting technology mix** (LEAP-tree remap 2026-05-20) —
   triangulated placeholders pending U4E 2026; catalogue is LED-only so
   the 5-tech split is sourced externally (U4E 2020 + IEA + AEO-8 /
   ACE-2026). LED share 40 % (MMR) → 80 % (SGP). LED bulb wattage is a
   catalogue median (7.0–13.0 W) vs LEAP's 7.2 W default; non-LED
   wattages are region-flat 60 W-equivalent references.
4. **ATS efficiency-blend artefact (PH / TH / VN for AC; PH / VN for
   Fridge)** — already-high-efficiency AMS get briefly pulled DOWN
   under ATS toward their cluster-typical mix. Pre-existing
   model behaviour. Flagged by sanity as WARN.
5. **RAS warm-up window 2024–2025** — ATS briefly leads RAS in
   absolute High_eff share for ~50 AC cells and 2 Fridge cells.
   RAS catches up by 2026 and dominates from 2026 onward.

---

## C. Verification battery

Run before paste, after paste, and after any LEAP recompile:

### C.1 Pre-paste (this repo)

```bash
# Per-subsector sanity batteries — flag-only, persisted to sanity_report.txt
python Residential/AC/_sanity.py        # expect 34/38 OK + 4 documented WARN
python Residential/Fridge/_sanity.py    # expect 28/30 OK + 2 documented WARN
python Residential/Lighting/_sanity.py  # expect 60/60 OK + 0 WARN (incl. tech-mix / tech-shares / wattage)
```

### C.2 Schema parity

```bash
# Verify scenario strings are plain "RAS" (NOT "RASv1") per §2.2 convention.
# lighting_bulb_wattage.csv has no Scenario column (per-tech constant) — excluded.
python -c "import pandas as pd; \
  for p in ['Residential/LEAP Input/ac_sales_projection.csv', \
            'Residential/LEAP Input/fridge_sales_projection.csv', \
            'Residential/LEAP Input/lighting_tech_shares.csv']: \
    df = pd.read_csv(p); \
    assert sorted(df['Scenario'].unique()) == ['ATS', 'BAS', 'RAS'], \
      f'{p}: unexpected scenario set {sorted(df.Scenario.unique())}'; \
    print(f'OK: {p}')"
```

### C.3 Sum-to-100 (cell shares within each AMS-Year-Scenario)

```python
# AC + Fridge: sales_pct should sum to ~100 per (Country, Year, Scenario)
# across the 9 Size×Efficiency cells. Spot-check, not a hard invariant
# (rounding leakage acceptable to ±0.5 pp).
for path in [ac_path, fridge_path]:
    df = pd.read_csv(path)
    g = df.groupby(['Country', 'Year', 'Scenario'])['sales_pct'].sum()
    assert ((g - 100.0).abs() < 1.0).all(), f"{path}: sum-to-100 violation"

# Lighting: tech share_percent must sum to 100 per (Country, Year, Scenario)
# across the 5 techs (hard invariant; Lighting/_sanity.py tech_shares:sum_to_100).
df = pd.read_csv('Residential/LEAP Input/lighting_tech_shares.csv')
g = df.groupby(['Country', 'Year', 'Scenario'])['share_percent'].sum()
assert ((g - 100.0).abs() < 1e-3).all(), "lighting_tech_shares: sum-to-100 violation"
```

### C.4 Three-scenario monotonicity (steady-state)

For projection years 2026+:

- AC: High_eff share BAS ≤ ATS ≤ RAS per (Country, Year, Size_group).
  Steady-state PH/TH/VN ATS < BAS is documented; RAS is always ≥ ATS at 2026+.
- Fridge: same.
- Lighting: LED tech share_percent BAS ≤ ATS ≤ RAS per (Country, Year)
  (LED rises fastest under RAS). Equivalently total non-LED share falls
  BAS ≥ ATS ≥ RAS.

Embedded in each `_sanity.py`'s Level 4b / Level 7 block — re-run via §C.1.

### C.5 Anchor spot-checks

- AC Indonesia 2040 BAS: total sales ≈ 6,036 k units; penetration ≈ 52 %.
- Fridge Indonesia 2040 BAS: total sales ≈ 4,616 k units; ownership ≈ 93 %.
- Lighting Singapore 2025 BAS: LED share = 80 % (base mix, frozen).
- Lighting Myanmar 2025 BAS: LED share = 40 % (lowest-LED AMS).
- Lighting ATS 2040 / RAS 2035: LED share = 100 % (all AMS, convergence).
- Lighting bulb wattage: LED 7.0–13.0 W per AMS; Incandescent 60 /
  Halogen 42 / CFL 14 / Fluorescent 32 W (all AMS).

### C.6 Post-paste (LEAP side)

- Three scenarios compile cleanly (BAS, ATS, RAS) with no error log.
- Spot-check the four anchor cells above against LEAP-reported values.
- Baseline-run completes; aggregate Residential demand shows
  RAS < ATS < BAS gap widening from 2025 to 2035 and stable thereafter.

---

## D. Notes on scope discipline

- **Single-lever architecture (DESIGN.md §2.2)** — RAS-vs-ATS divergence
  is the efficiency-mix curve acceleration only. No ownership-cap
  revision, no service-level overlay. Keeps the BAS → ATS → RAS gap
  reading as a clean policy-acceleration story.
- **Naming convention** — `RASv1` is documentation-only;
  CSV / LEAP scenario string is plain `RAS`. v2 anticipated; the
  documentation reference will move to `RASv2` while the CSV / LEAP
  scenario string stays `RAS` (LEAP scenario compatibility).
- **No structural creates** — three subsectors write only to existing
  LEAP branches. Confirmed at Phase 3 build time; no new fuels, no
  new transformation processes added.
- **Source citation discipline** — every CSV value in the three
  LEAP-Input files traces back to a builder script + a documented
  source. Aux dimensions (refrigerant, label, etc.) live in separate
  CSVs and are NOT in the LEAP-Input scope for this handoff.
