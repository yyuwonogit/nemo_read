# Answers — round 2

**Re:** your `bioenergy_reply_20260722.zip` (cover + `OUR_RULINGS` + `CONTENT_ASKS`)
**From:** bioenergy · **Date:** 2026-07-22

Your four structural rulings are adopted, both of your errors are noted and cost us nothing
to absorb, and eight of the nine content asks are answered below. Two of them are answered
by disagreeing with you, with the evidence attached.

We also owe you one correction on our own side that you did not catch, and one live defect
in canon that we found while answering A9.

---

## Your rulings, adopted

**R2 — `InterpFSY` is a ramp.** Adopted, and verified against your three solved values
before adopting: Malaysia 30 × 1/6 = 5.000, Thailand 25 × 1/13 = 1.923, Philippines
10 × 1/2 = 5.000. All three reproduce exactly.

**Our "canon floors read ZERO" finding is withdrawn** — it was an artefact of the step
reading and should never have shipped. You were also right that our README and our own
`mandate_floor_reshape.csv` disagreed with each other. That cannot recur: both the builder
and the check suite now read `InterpFSY` from one shared module,
`Bioenergy/Analysis/canon_expr.py`, so there is no second implementation to drift.

**The ramp reading surfaces the opposite defect, and it is worth your attention.** With the
floor read as a ramp from (2024, 0), canon already obliges **Lao PDR to blend 1.67 % and
Viet Nam 1.48 % in 2025** — in countries with no blending instrument and, as far as we can
establish, no terminal blending infrastructure. Under the step reading those cells read
zero and the problem was invisible. Same class as the one we reported wrongly, opposite
direction, and only visible once you corrected us.

**R3 — total distributed pool.** Adopted. Our on-road default is overturned and the panel
is being re-based; validation gate R5 moves from BLOCKED to RESOLVED.

**R8 — `Optimize = No` in ATS and BAS.** Adopted. Our "cap RAS, leave ambition in ATS"
recommendation is formally withdrawn and struck from the findings text.

**R7 — the `Max()` guard.** Adopted, and it changed how we build. Since a ceiling authored
below a floor is silently raised rather than rejected, we now lift the ceiling ourselves
wherever a floor sits above it, so the override is visible in our file rather than happening
inside your guard. Every such lift carries a finding stating that it is **not** a physical
claim.

**Your two errors** — the linear volume→energy recipe, and the authoring guide's false claim
of automatic unit conversion — are noted with thanks for the plain retraction. Neither cost
us anything: we shipped volume % as you asked, and the 15 unit rows were re-authored once
and correctly. We are not re-issuing anything for either.

---

## The doctrine, now applied to both bounds

Your acceptance of the ceiling-semantics rule exposed that we had only ever applied it to
one side. The ceiling was rate-limited; the floor was unlimited. That is backwards, because
**the floor is the bound that forces the model** — an impossible ceiling merely permits an
impossible outcome, while an impossible floor compels one.

So the division is now explicit:

```
floor(a, f, y) = max( in-force mandate , canon RAS target )      RAS only
ceiling(a, f, y) = min( technical blend wall , prev + max demonstrated ramp )
                   lifted to meet whatever binds below it
```

| | Floor | Ceiling |
|---|---|---|
| Mandated | forced at the legislated value | ≥ the mandate |
| Canon target, no instrument | carried as a RAS aspiration | ≥ the target |
| Neither | **none** — optimiser free | the only bound |
| Physical ramp rate | **does not apply** | **applies here** |
| Monotone non-decreasing | yes | yes |

Three points behind that table:

1. **A mandate is forced as legislated, not rate-limited.** We had briefly built a floor
   that slipped a legislated arrival year on physical grounds — Malaysia's B30 moving from
   2030 to 2040. That is substituting our judgement for a government's, and we withdrew it.
   Where a mandate demands a rate no country has ever sustained we now **force it and report
   it**, so the solved result is a stated assumption rather than a surprise. Four such rows
   are in `blend_ramp_findings.csv`: Thailand bioethanol 18.46 pp/yr at 2027, Malaysia and
   Indonesia biodiesel 10.00 pp/yr at 2026, Viet Nam bioethanol 8.52 pp/yr at 2026, against
   3.0 pp/yr as the fastest rate ever sustained anywhere (Indonesia 2015–2025).

2. **A canon target with no instrument behind it is an aspiration, and belongs in RAS.**
   The Regional Aspiration Scenario is precisely the place for a target a country has not
   legislated, so those are carried at canon's own value on canon's ramp reading, and simply
   labelled differently (`ras_aspiration_target` vs `mandated_forced`) so a downstream reader
   can tell a law from an ambition.

3. **Both bounds are monotone non-decreasing.** A falling bound asserts that a fleet became
   physically incapable of something it had already done. Thailand deleting B10 in 2024 and
   the Philippines suspending B4/B5 in 2025 were **price** events, and price is the
   optimiser's business under the doctrine you have adopted. Note the scope carefully: this
   governs the **bounds**, not the evidence. The observed panel keeps Thailand's real
   non-monotonic series exactly as published — you specifically accepted it on that basis and
   smoothing it would be falsifying it.

---

## A1 — Part B: dissolved, not answered

You asked for a `resume_year` column so an `Interp()` could be constructed. There is no
longer anything to resume. `mandate_floor_reshape.csv` is retired and replaced by
`blend_floor_mandated.csv`, which is an explicit per-year anchor series with no
step/plateau/resume grammar at all.

Your two sub-questions resolve with it:

- **Which artefact governs?** The CSVs. See A4.
- **Malaysia's 2032 step above its own Part-A ceiling.** Cannot recur. Both bounds are now
  built in one pass from the same start point, and a FAIL-class gate (R11) checks our floor
  against our ceiling cell by cell.

The old construction slipped the step +2 yr and haircut the value ×0.85. Both were
forecasts of programme under-delivery, which is the same class of reasoning we had already
purged from the ceiling. You would have been right to challenge it.

---

## A2 — Indonesia FAME basis: you are right, and we have changed our basis

The 25 % divergence is **not a unit error, it is a registry difference.** Ours came from
USDA GAIN / APROBI, yours from the ACE `Biofuel Production, Feedstock, and Land Use Data in
ASEAN` series. Both describe installed capacity; they differ on plant inclusion — idle and
mothballed lines, and multi-feedstock lines counted once or twice.

**We have adopted canon's basis**, and for a structural reason rather than a view on which
registry is better sourced. The rule is `MaxCapAdd = α × installed(y−1)`, and `installed`
inside the model is `Exogenous Capacity` plus whatever the optimiser has already added. A
rate expressed as a fraction of a base the model does not hold is inconsistent with the very
quantity it constrains — it would be wrong in the model however right it was on paper.
Reading the base off `Exogenous Capacity` also settles brownfield-versus-greenfield on the
model's own terms instead of ours.

For completeness: our own Part C narrative had already cited 19.6 bn L installed for 2025,
which is ≈17.2 Mt and agrees with **you**, not with our own `Raw/refinery_capacity_2023.csv`.
The 13.05 Mt figure was the outlier from the start.

`build_rate_limit.csv` is rebuilt on that basis, now the full 7 processes × 10 regions
(70 rows). Our registry is retained as an independent cross-check and reported rather than
reconciled — the divergences are not systematic (Indonesia FAME 1.26×, Thailand FAME 1.28×,
Malaysia FAME 0.50×, ethanol side 0.18× to 1.57×), and that spread is the real content of A9.

**On shipping a pre-solved trajectory:** agreed for next cycle, and thank you for
pre-solving it this time.

---

## A4 — which artefact governs: the CSVs

Unambiguously the CSVs. `blend_ramp_workplan.md` was a working document and we should not
have shipped it as though it were a deliverable — diffing it against the tables cost you
time for no benefit. **It is out of the package from this drop onward**, along with the
enabler scorecard and the ladder narrative. Nothing ships that cannot be attached to a cell.

Of the four promised items you could not find:

| # | Item | Status |
|---|---|---|
| 1 | Thailand biodiesel finding | now present — Thailand appears in the findings table |
| 2 | R7 back-tests for TH/PH ethanol | **withdrawn as a concept.** R7 is now a ceiling-admissibility test: not "does it predict history" but "would it have forbidden history". A ceiling is not a forecast, so back-testing its predictive accuracy was the wrong question |
| 3 | Thailand 2035 conditional on an OEM declaration | **withdrawn.** An OEM warranty position is a commercial stance, not a physical limit, so it cannot condition a physical ceiling |
| 4 | Timor Leste rows | **out of scope**, per your own roster convention — disabled in the calculation. It should not have been promised |

---

## A5 — Indonesia 2026: B50, per canon

Canon carries B50 at 2026 and canon governs.

We had floated 45 on the grounds that the instrument takes effect 1 July 2026 and LEAP holds
one value per year, making the volume-weighted annual average 0.5 × 40 + 0.5 × 50. **That
reading is withdrawn** — it was our arithmetic against your number, and on a mandate the
instrument is the fact. (Our own artefacts had said 50, 45 and 38 in three different places,
which was the real defect you were pointing at. 50 is the one that survives.)

---

## A7 — the gate exists, and it found things

Implemented as **R8**, FAIL-class, evaluating the canon floor on the ramp reading. Two more
gates went in alongside it, because the same blind spot had more than one shape:

| Gate | Tests | Class |
|---|---|---|
| **R8** | ceiling ≥ canon floor, cell by cell | FAIL |
| **R9** | neither bound ever falls | FAIL |
| **R10** | neither bound rises faster than demonstrated | FAIL on the ceiling, FINDING on the floor |
| **R11** | our own floor ≤ our own ceiling | FAIL |

R10 is deliberately asymmetric: the physical rate limit governs physical capability, not
legal obligation, so a mandate that outruns it is reported rather than failed.

We have stopped quoting the pass count as feasibility assurance. Current state is **172
checks, 165 PASS, 0 FAIL**, with 4 FINDINGs that are intended and listed above.

A second gate now covers your other blind spot — `audit_structural_conformance.py` checks
seven of your standing conventions over every shipped artefact on every run: region roster,
join key present in your vocabulary, `Interp()` grammar, no literal `Unlimited`, scenario
tagging, refinery capacity units by side, and blend shares within [0, 100]. It caught two
live defects on its first run, including one of ours that had already reached a deliverable.

**On your offer of the evaluated canon floor series: yes please.** Not because we cannot
evaluate it — we now reproduce your three check values exactly — but because a second
independent evaluation is exactly what would have caught the step/ramp divergence a cycle
earlier.

---

## A9 — we do not think this finding holds, and here is the evidence

You flagged three cells where our `Maximum Capacity` sits below the existing fleet, making
the cap a dead letter under the `Max(Exogenous Capacity, …)` guard. Before re-allocating we
tested whether the comparison itself holds. We do not think it does.

**1. Canon authors `Maximum Capacity` on every one of these branches as `Add(...)`, and
canon's own `CSV_AUTHORING_GUIDE` §13.3 defines `Add(year, delta, …)` as cumulative
additions** — "adds 16 in 2025 then 7.5 in 2030 → cumulative is 16, then 23.5". That is a
build series, not a level.

**2. The magnitudes agree with that reading and not with a level.** Indonesia FAME carries
`Add(2025, 16, 2030, 7.5, …)`, summing to 65 Million GJ/Yr by 2060, against roughly
637 Million GJ/Yr of plant already standing. Read as a total cap, that instructs the model to
scrap about 90 % of the Indonesian biodiesel industry.

**3. Applied to canon, your test flags canon.** In 5 of the 10 cells that carry an existing
fleet, canon's own cumulative `Maximum Capacity` sits below canon's own `Exogenous Capacity`.

**4. On two of your three cells, our value *is* canon's value.** Philippines FAME and
Thailand Molasses: canon's `Maximum Capacity` is `Add(…, 0, …)` — zero — and so is ours. We
did not allocate anything different there.

Full working in `capacity_vs_fleet_audit.csv` (70 rows).

**So the question we would put back to you is structural, and therefore yours:** is
`Maximum Capacity` on these branches an upper bound on total capacity, or a limit on
cumulative additions? If it is the latter — which the `Add()` form, the guide and the
magnitudes all indicate — then no cap is "below the existing fleet", because the two
quantities are not commensurable, and our Part C is targeting exactly the right field.

The third cell, Philippines Molasses, is a genuine allocation difference and is discussed
under the canon defect below.

---

## A8 — sent

The refreshed 581-row `bioenergy_leap_input.csv` is in this package. All 520 canon-resolvable
rows match canon on branch, variable **and** unit; the remaining 61 are unchanged and still
waiting on the three branch creates.

---

## A3 — Brunei biomass: out of scope this cycle, by your own R1

R1 narrows this cycle to the liquid-biofuel chain: 7 feedstocks → 7 refinery processes →
Blending. Brunei solid biomass is not one of the 7, the row is held rather than authored, and
nothing in the delta depends on it. We are not spending this cycle's evidence budget on a
244× question that cannot reach the payload.

It stays open on our side and we will bring either the verbatim Tun et al. cells or a
bottom-up residue falsification when the scope reopens. The MSW routing proposal is likewise
parked, not withdrawn.

---

## One live defect in canon, found while answering A9

`Transformation\Biodiesel Production\Processes\FAME Biodiesel`, **Philippines**,
`Exogenous Capacity`, RAS:

```
Interp(2015, 204, 2016, 227, 2017, 220, 2018, 220, 2019, 242,
       2020, 188, 2021, 198, 2022, 203, 2023, 225)
```

It is **the only one of ten** biofuel `Exogenous Capacity` rows missing the
`* 10^6 * ConvFuelUnits(liter, gj, biodiesel)` multiplier that its siblings carry, and the
only one without the ACE citation. Indonesia, Malaysia and Thailand all have both.

Read as authored, the row places **225 Million GJ/Yr** of existing biodiesel plant in the
Philippines. On its siblings' basis the same series would read roughly **7.7 Million GJ/Yr**,
and your own A9 letter states the Philippine fleet at **15.60**. Three different numbers,
none of which agree.

**Why this is worse than an ordinary wrong number:** `Exogenous Capacity` is a *lower* bound.
It exports to NEMO as `ResidualCapacity`, so an inflated value does not loosen a cap — it
**forces the solver to carry biodiesel plant the Philippines does not have.** That is exactly
the failure mode your own R6 warns about, on a row authored on your side.

Structure is yours, so we are reporting rather than proposing a value. But this one looks
worth fixing before the next solve.

---

## What is still open on our side

Listed so you can see what is coming rather than discovering it:

- **The ethanol wall.** Our E20 wall was an assumption rather than a finding, and we are
  re-founding it on the best physically demonstrated non-flex case. If the evidence supports
  E25 or E30 the ceiling moves, and Thailand's currently pinned cells unpin with it.
- **The denominator re-basing.** R3 is adopted in the gates; the panel values themselves are
  still being re-based from on-road onto the total distributed pool.
- **Six countries with no observation** — Brunei, Cambodia, Lao PDR, Myanmar, Singapore, and
  Malaysia bioethanol. Your ask A6 is right that we were labelling a constructed zero as an
  observation. Being fixed with sourced values and a three-way evidence class
  (`observed` / `peak_observed` / `constructed_zero_no_programme`).

---

## One thing worth flagging before the next solve

**45 of 200 cells now have floor exactly equal to ceiling** — zero optimiser slack. Indonesia
biodiesel is pinned at 50 for all ten anchor years; Thailand bioethanol at 20 for eight. This
is the same residual you flagged on Indonesia bioethanol and marked for sign-off, except it is
now much wider.

It happens wherever a mandate reaches our wall, and it means those country-fuel pairs are not
being optimised on blend share at all — they are being told what to do. That may be the
correct modelling choice for a legally mandated blend. It should be a decision rather than a
by-product, which is why we are surfacing it rather than tuning it away.

---

## The walls, re-founded on evidence

Both walls were assumptions in the last drop. They are findings now, and the method that
produced them is the one you accepted: physical and legal limits only.

### Bioethanol — E20, held to 2060

| 2025 | 2027 | 2030 | 2035 | → 2060 |
|---|---|---|---|---|
| 15 | 15 | 17 | **20** | 20 |

The path is fleet architecture, not specification: E10 is universally compatible today, the
2030 step is the two-wheeler fleet turning over, and pool-wide E20 lands 2035 on materials
turnover plus the India precedent — E10 → E20 as a universal no-opt-out grade on a
motorcycle-majority fleet.

**We set out to prove E30 and failed to.** Two above-E20 jurisdictions exist and neither
transfers. Brazil's E30 (CNPE Res. 9/2025) was refuted by four independent adversarial
lenses: ~84.5 % of its fleet is flex and its gasoline-only vehicles have been factory-
specified for E20–E27.5 since the 1990s, so it demonstrates a purpose-built fleet absorbing
a marginal step inside its certified range. Paraguay (Decreto MIC 3.241) is the better
read-across and remains the strongest open lead. On the evidence in hand the enabler above
E20 for a non-purpose-built fleet does not exist: the two regulators that examined
two-wheelers specifically drew the motorcycle line **below** the car line, and India — best
placed to break E20, with ethanol supply already offered above its needs — has declined to.

**Where this is weakest, stated plainly:** holding 20 flat from 2035 to 2060 spans more than
one and a half two-wheeler fleet turnovers. It is a 25-year freeze. It stands because no
physical enabler above E20 has been demonstrated on an ordinary fleet, not because we know
none will arrive.

### Biodiesel — B50, and the argument is one line

**Indonesia is formally at B50 today.** A real member state, ordinary non-flex national
fleet, tropical climate, growing common-rail share. B50 is therefore not a projection and not
a specification question — it is demonstrated, and a blend one fleet has burned is physically
available to any country whose economics justify it. The wall is 40 in 2025, which is what
Indonesia actually ran, and 50 from 2026 when its instrument takes effect.

Our own research proposed dropping this wall to B30 with a hold at 20 from 2030 to 2045. We
rejected it: that would forbid, for fifteen years, something an ASEAN fleet is doing right
now. It was built on a ladder of fuel specifications, and its author conceded in dissent that
*"specifications are written by committees, not by chemistry — ASTM D7467 stops at B20
because that is the scope its subcommittee chose, not because something fails at 21 %."* A
committee scope decision is not a physical limit.

**There are now no per-country wall exceptions at all.** The generic wall *is* Indonesia's
demonstration. Differentiation is entirely in the starting point, the mandate and the shared
ramp rate:

| | 2025 | 2030 | 2040 | 2045 |
|---|---|---|---|---|
| Indonesia | 40 | 50 | 50 | 50 |
| Malaysia | 7.0 | 30 | **50** | 50 |
| Thailand | 8.2 | 23.2 | **50** | 50 |
| Six states with no programme | 0 | 15 | 45 | **50** |

### One caveat we report rather than impose

These wall levels are **grade** specifications; the model measures a **pool** share. B50
grade is a 50 % pool share only if every litre is blended, and it is not — Malaysia has ~22 %
of its diesel pool under no blending obligation, the Philippines ~34.8 % non-road, Thailand
~5 % unblended. We do **not** cap for this, because non-road blending infrastructure is
buildable and a ceiling may not encode what merely has not been built yet. But a gap between
a grade mandate and a solved pool share should read as expected, not as a defect.

---

## How good is the evidence, honestly

We commissioned a completeness critique of our own research before using it, and it is in the
package (`blend_evidence_critique_20260722.md`). Its central finding travels with the data
rather than sitting in a footnote:

**Across ten member states and two fuels there is exactly ONE clean published observation on
a stated denominator — Philippines biodiesel 2.3 % (2024).** Everything else is a forecast, a
construction or a derivation:

| Value | What it actually is |
|---|---|
| Indonesia biodiesel 34.1 (2025) | USDA Post **forecast**; realised nearer 33.4 |
| Malaysia biodiesel 9.5 | **constructed** by FAS from the mandate — the division returns exactly 7.00 or 9.50 every year, with no rounding noise |
| Viet Nam bioethanol 9.7 (2026) | **one month** of product mix at nameplate grade spec |
| Thailand 11.1 / 5.3 (2025) | **derived** from a bank research note |
| Philippines bioethanol 9.8 (2024) | denominator **contested** — 8.6 on another table in the same report |

No fuel-quality survey, no FAME or oxygenate speciation, and no regulator compliance dataset
exists for any member state. So `evidence_class = observed_published_series` means "a
national authority published this", not "someone measured it". Confidence labels are set
accordingly and several were downgraded.

The critique also caught us fitting evidence to expectation: the research had reported
Indonesia's total-pool blend as 31.5 and said in terms that it chose that reading because it
matched our own 2.6 pp calibration. Your R3 measures at the blending-module output, which is
34.8. **34.8 is what we ship**, and our 2.6 pp figure was only ever a description of
Indonesia, never a constraint it had to satisfy.

**Correction to your R3 worked example, offered for checking rather than asserted.** Our pool
research reconciles IEA against national sources to within 0.1 % on Indonesia and 0.4 pp on
Thailand, and finds gasoline is 0.98–1.00 on-road everywhere, so the denominator ruling is
material for **diesel only**. On that basis the genuine −2.6 pp case looks like **Malaysia**,
not Indonesia. Per-AMS on-road shares of the diesel pool: Brunei 0.47, Viet Nam 0.62,
Philippines 0.67, Malaysia 0.68, Thailand 0.76, Cambodia 0.79, Myanmar 0.81, Singapore 0.86,
Lao PDR 0.93.
