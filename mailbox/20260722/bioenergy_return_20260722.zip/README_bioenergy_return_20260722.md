# Bioenergy → LEAP modelling / canon team — return package

**Date:** 2026-07-22 · **Re:** your `bioenergy_reply_20260722.zip`
**Scope:** the liquid-biofuel chain, per your R1. **Scenario: RAS.** Values only — volume %,
no branch paths, variables or units.

Your four structural rulings are adopted and verified. Eight of your nine content asks are
answered; the ninth is deferred under your own scope narrowing. Two are answered by
disagreeing with you, with the working attached. We also report one live defect in canon that
you did not catch, and one place where we caught ourselves fitting evidence to expectation.

---

## What changed since the last drop

**Both walls were assumptions. They are findings now.**

| | Was | Is | Why |
|---|---|---|---|
| Bioethanol | E20 by 2032 | **E20 at 2035, held to 2060** | fleet architecture, not spec; E30 tested and rejected |
| Biodiesel | B50 by 2050 | **B50 from 2026** | Indonesia is formally at B50 today |

**The doctrine you accepted is now applied to BOTH bounds.** We had rate-limited the ceiling
and left the floor unlimited, which is backwards — an impossible ceiling merely permits an
impossible outcome, an impossible floor compels one.

```
floor   = max( in-force mandate , canon RAS target )   forced, RAS only, never rate-limited
ceiling = min( technical wall , prev + max demonstrated ramp ), lifted to meet the floor
```

Mandates are forced at their legislated value because a mandate is a legal fact, not a
physical claim. The physical ramp rate governs the ceiling alone. Both bounds are monotone
non-decreasing. Where a mandate outruns anything ever demonstrated we **force it and report
it** rather than softening it — four such rows are in the findings.

---

## Contents

| File | What it is |
|---|---|
| `blend_ceiling_ramp.csv` | **Part A** — `max_blend_share_volume_pct`, 10 regions × 2 fuels × 10 years. 200 rows |
| `blend_floor_mandated.csv` | **Part B** — the forced floor. Replaces `mandate_floor_reshape.csv`; your ask A1 dissolves with it. 200 rows |
| `build_rate_limit.csv` | **Part C** — `Maximum Capacity Addition`, re-based onto canon's own `Exogenous Capacity` per your ask A2. Now the full 7 processes × 10 regions. 70 rows |
| `blend_ramp_findings.csv` | 13 findings in four directions, including the four unprecedented-rate mandates |
| `p4_pending_branch_creates.csv` | the 51 rows waiting on your three branch creates |
| `bioenergy_leap_input.csv` | **your ask A8** — the refreshed 581-row input. All 520 canon-resolvable rows match on branch, variable AND unit |
| `blend_observed_panel.csv` | the evidence base, with a `denominator` column on every row |
| `canon_mandate_parsed.csv` | all 20 canon mandate cells parsed |
| `capacity_vs_fleet_audit.csv` | **the working behind our A9 answer**. 70 rows |
| `blend_ramp_check.csv` | validation. 183 checks, **176 PASS, 0 FAIL**, 4 intended FINDINGs |
| `structural_conformance.csv` | your standing conventions, mechanised. 20 checks, all PASS |
| `blend_evidence_critique_20260722.md` | our own commissioned critique of our own research. Read §0.3 |
| `ANSWERS_ROUND2_20260722.md` | the full answers |

Per your ask A4: **the CSVs govern.** The workplan, the enabler scorecard and the ladder
narrative are out of the package. Nothing ships that cannot be attached to a cell.

---

## Three things we would flag to you specifically

### 1. A live defect in canon — Philippines FAME `Exogenous Capacity`

```
Transformation\Biodiesel Production\Processes\FAME Biodiesel · Philippines · RAS
Interp(2015, 204, 2016, 227, ... 2023, 225)
```

It is **the only one of ten** biofuel `Exogenous Capacity` rows missing the
`* 10^6 * ConvFuelUnits(liter, gj, biodiesel)` multiplier its siblings carry, and the only
one without the ACE citation. Indonesia, Malaysia and Thailand all have both.

`Exogenous Capacity` is a *lower* bound — it exports as `ResidualCapacity` — so an inflated
value does not loosen a cap, it **forces the solver to carry plant the Philippines does not
have.** That is the failure mode your own R6 warns about, on a row authored on your side.

### 2. Your R2 ramp reading surfaces the mirror of the defect we reported wrongly

With the floor read as a ramp from (2024, 0), canon already obliges **Lao PDR to blend
1.67 % and Viet Nam 1.48 % in 2025** — states with no instrument and no terminal blending
infrastructure. Under the step reading those cells read zero and it was invisible.

### 3. 45 of 200 cells have floor exactly equal to ceiling

Zero optimiser slack. Indonesia biodiesel is pinned for all ten anchor years; Thailand
bioethanol for eight. This is the residual you flagged on Indonesia bioethanol and marked for
sign-off, now much wider. It happens wherever a mandate reaches the wall, and it means those
pairs are not being optimised on blend share at all — they are being told what to do. That
may be correct for a legally mandated blend. It should be a decision, not a by-product.

---

## Where we disagree with you

**A9 — we do not think the finding holds.** Canon writes `Maximum Capacity` on these branches
as `Add(...)`, which canon's own `CSV_AUTHORING_GUIDE` §13.3 defines as *cumulative
additions*. The magnitudes agree with that and not with a level: Indonesia FAME sums to
65 Million GJ/Yr against ~637 already standing, which read as a total cap would instruct the
model to scrap 90 % of the Indonesian industry. Applied to canon, your test flags canon in
**5 of the 10** cells that carry an existing fleet — and on two of your three cells our value
*is* canon's own value, 0.00. The question back to you is structural, and therefore yours: is
`Maximum Capacity` here a cap on total capacity, or on cumulative additions?

**Your R3 worked example.** Our pool research reconciles IEA against national sources to
within 0.1 % on Indonesia and 0.4 pp on Thailand, and finds gasoline is 0.98–1.00 on-road
everywhere — so the ruling is material for **diesel only**. On that basis the genuine −2.6 pp
case looks like **Malaysia**, not Indonesia. Offered for checking, not asserted.

---

## Where we were wrong, unprompted

**We caught ourselves fitting evidence to expectation.** Our research reported Indonesia's
total-pool blend as 31.5 and said in terms that it chose that reading *because it matched our
own 2.6 pp calibration*. Your R3 measures at the blending-module output, which gives 34.8.
**34.8 is what we ship.** Our 2.6 pp was only ever a description of Indonesia, never a
constraint Indonesia had to satisfy.

**And the evidence base is thinner than our labels implied.** Across ten states and two fuels
there is exactly **one** clean published observation on a stated denominator — Philippines
biodiesel 2.3 % (2024). Everything else is a forecast, a construction or a derivation, and
no fuel-quality survey or regulator compliance dataset exists for any member state. Details
in `ANSWERS` and in the critique. Confidence labels are set accordingly.

**We have stopped quoting the pass count as feasibility assurance**, per your §6. The suite
now contains the floor-versus-ceiling gate you asked for (R8), plus monotonicity (R9), rate
(R10) and our own floor-versus-ceiling (R11).

---

## What we need back

1. **A9** — is `Maximum Capacity` on these branches a total-capacity cap or an additions cap?
2. **The Philippines `Exogenous Capacity` row** — please check and fix.
3. **Your offer of the evaluated canon floor series — yes please.** Not because we cannot
   evaluate it, but because a second independent evaluation is exactly what would have caught
   the step/ramp divergence a cycle earlier.
4. Your four post-inject deliverables. The fuel `EnergyContent` export unblocks our last
   BLOCKED gate (R1 feedstock) and lets you confirm or rescale our six §11.2 unit conversions.
