# Commercial send-back — LEAP injection hand-off guide

**From:** ASEAN Energy Outlook 9 commercial-buildings team · **To:** LEAP injection
team · **Date:** 2026-07-21 · **Target:** `Demand\Commercial` in the live area.

This is the commercial-buildings send-back for **all six end uses** (Air
Conditioning, Cooking and Food Processing, Lighting, Other, Refrigeration, Water
Heating). **Data_Center is intentionally unchanged** (already best-available,
no public source beyond it). Built against your canonical structure handover
(`aeo9_v0.67_w_results`, exported 2026-07-04) and **verified conformant** —
`canon_conformance_report.md` runs 44/44 checks green (end uses, tech leaves,
variables, units, scenarios, regions, sourced-value match, calibration chain, the
AC Residential borrow, and the refrigeration Efficient/Existing structure).

Everything is sourced, reconciled top-down, retained from your canon, or explicitly
flagged. **Nothing is invented.**

## 1. Files in this package

| File | What it is |
|---|---|
| `end_use_intensity.csv` | **B1** — `Commercial Uncalibrated Energy Intensity` [kWh/m2] per (Country × end use). 60 rows. |
| `end_use_saturation.csv` | **B3** — parent `Activity Level` (% of floor area served) per (Country × end use). 60 rows. |
| `fuel_shares.csv` | **B7** — the shares **we author**: AC efficiency-class (Current Stock/Sales/Efficient/Best Practice) + Refrigeration (Existing/Efficient), forced BAS/ATS/RAS, 2023–2060. |
| `b7_fuel_share_disposition.csv` | **B7 map** — what to do with **every** one of the 36 fuel/tech leaves (author / retain / borrow / bug). |
| `commercial_enduse_reconciled.csv` | Provenance/audit table behind B1+B3 (level basis, saturation anchor, implied split, refresh flags). |
| `canon_conformance_report.md` | Proof the package fits your canon (44 PASS / 0 FAIL). |

Country = full ASEAN names (map to your region slots); scenarios `Baseline` /
`AMS Target` / `Regional Aspiration` map to your `Baseline Simulation` /
`AMS Target Scenario` / `Regional Aspiration Scenario`.

## 2. How to ingest — the load-bearing rules

1. **Intensity dual-emit + the cal→1 recommendation.** `uncal_intensity_bridge`
   reconciles under your **current** `Key\Cal\Commercial\Electricity` factor —
   **paste this column now**, zero other action. `uncal_intensity_kwh_m2` is the
   clean physical (cal=1) value; once you accept all six end uses, the whole-building
   total closes (Σ split×control = control), so you can migrate to it and **reset
   the Electricity cal factor to 1.0** (`cal_recommended = 1.0`).
2. **AC keeps the Residential borrow.** Paste the four AC leaf **shares** from
   `fuel_shares.csv`; **do NOT touch the AC leaf `Final Energy Intensity`** — it
   stays `= Residential AC EER ratio × Current Stock_Average FEI`. Re-point it at
   the **rebuilt** Residential AC branch when the 2-layer rebuild lands.
3. **Refrigeration ratio.** Replace the hardcoded `Efficient FEI = 0.7 × Existing`
   with **`0.60 ×`** (GIZ CRE EEI P20/median of the ASEAN RDC chilled small+medium
   tier; GEMS Refrigerated Cabinets Determination 2024, F2024L01263).
4. **B7 per-leaf disposition** (`b7_fuel_share_disposition.csv`): follow the
   `disposition` column for each of the 36 leaves —
   - `authored-by-us` (6) → paste from `fuel_shares.csv`.
   - `canon-retained` (23: Cooking/Other/Water Heating) → **keep your current
     value** (2022/EBT-anchored fuel mix — we have no better data, so we do not
     override it).
   - `residential-borrow` (7: Lighting Electricity) → **keep the borrow** from
     `Demand\Residential\…\Lighting` (same pattern as the AC EER).
   - rows with a non-empty `bug_flag` → see §4.
5. **Scenarios are forced, no optimisation.** Energy is strictly **BAS ≥ ATS ≥ RAS**
   per AMS per year, by construction (efficiency-mix acceleration is the single
   lever). No device/constraint optimisation on the commercial side.

## 3. Flagged rows (`refresh_needed = True`) — read before pasting

- **Thailand** — every TH value: your canon `Key\Commercial\Energy consumption per
  area\Retailer` for Thailand is `.350` (a decimal typo; neighbours are 300–425).
  We corrected it to **350** in our control total (106 → 197 kWh/m2). Fix at source.
- **Lao PDR AC, Brunei AC, Brunei Lighting** — the sourced value implies a
  *different* end-use split than the regional generic (Laos AC ≈ 12% of building
  energy, Brunei AC ≈ 35%, Brunei lighting ≈ 3.5%). These are **real climate /
  efficiency signals** (cool highland; efficient LED), not errors — the sourced
  value takes precedence.
- **Other ×7, Water Heating ×3** — reconciled intensity capped at 400 kWh/m2 with
  the saturation floored, because your canon saturations there (Other 5%, WaterHeat
  3%) are implausibly low placeholders. Needs real saturation data.
- **Cambodia / Lao PDR / Myanmar** — no public commercial-building energy data
  exists; these are socioeconomic-cluster gap-filled. Lowest confidence.
- **Singapore** — building control now sourced from the **BCA Building Energy
  Benchmarking Report** (Office 218 / Hotel 292 / Retail 405), which is higher than
  the canon values.

## 4. Structural fixes we ask you to make (B10)

The nine fuel-share bugs are enumerated with the exact leaf in
`b7_fuel_share_disposition.csv` (`bug_flag` column):

- **Cooking** — `Solar Heating` `Commercial Fuel Share_` omits the `/100` divisor;
  `Charcoal` (PHL) references the **Wood** historical branch (copy-paste); `Wood`
  (PHL) policy `Interp` omits `/100`.
- **Other** — `Diesel` / `Electricity` (PHL) and `Wood` (MMR) policy `Interp` omit
  `/100`.
- **Water Heating** — RAS `Solar Heating` is set to a uniform `2`, which overrides
  and **lowers** the sourced Indonesia 30.71 / Thailand 3.39 (reversed policy);
  `Heat Pump` and `Heat Pump Outside Air` carry `Commercial Fuel Share_ = 0` while
  active (may nullify their contribution).

Plus from our earlier canon review (`canon_review_20260716.md`): the **Ethanol /
Biodiesel `!Missing Branch (ID=1687/825)`** Historical regression shells (the one
VERIFIED defect in your audit), and the artifact empty-name `Data_Center\` branch.

## 5. Provenance

Sourced levels equal your canon expressions exactly (Brunei BEI 2019 for every
non-Other end use; Laos ERIA for AC + lighting; Malaysia journal + Thailand SEI for
AC; Singapore BCA for the building control; GIZ/GEMS for the refrigeration ratio).
Everything else is top-down reconciliation from the whole-building control × the
end-use split, or your canon value retained. Method: `../METHOD_PROPOSAL.md`;
per-branch review: `../canon_review_20260716.md`; depth ceiling:
`../AC_REFRIG_DEPTH_ASSESSMENT.md`.

Questions → yudiandra.y@gmail.com.
