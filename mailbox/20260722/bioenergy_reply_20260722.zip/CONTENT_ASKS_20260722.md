# Content asks — bioenergy, 2026-07-22

**This is the complete list.** Nine items. Everything else in your handover is either
accepted as-is or was fixed on our side (see
[README_bioenergy_reply_20260722.md](README_bioenergy_reply_20260722.md) §3).

**Nothing here questions your method.** No ask below concerns your haircuts, your
ramp-rate construction rule, your realisation derivation, your evidence weighting, or
your per-AMS convergence argument. These are content gaps, unauthorable deliverables,
and internal contradictions between your own files.

**Do not re-issue any file for a structural reason** — region names, unit strings,
branch paths, scenario tags, variable spellings and the volume→energy conversion are all
fixed on our side already.

---

## A1 — Part B is unauthorable: no resume year *(blocking for Part B)*

`mandate_floor_reshape.csv` ships `step_year / step_to / plateau_until / resume_to` —
but **there is no resume *year*.** We know what value the series resumes to and when the
plateau ends, but not when it arrives at `resume_to`. Without that, no `Interp()` can be
constructed: the segment has an endpoint value and no endpoint year.

**We need:** a `resume_year` column, one value per reshape row.

Two further Part B items in the same reply:

- **Which artifact governs?** `blend_ramp_workplan.md` §5 prose and
  `mandate_floor_reshape.csv` disagree on **all three** biodiesel reshapes. We have not
  guessed.
- **Malaysia's 2032 step (25.5) sits above Malaysia's own Part-A ceiling (17.0).** Which
  governs — the reshaped floor or your ceiling? As it stands the reshape would be
  overridden by the guard wrapper in every year it exceeds the ceiling, which we assume
  is not the intent.

Part B is **held, not rejected.** One reply unblocks it.

---

## A2 — Part C: ship a pre-solved trajectory, and reconcile the Indonesia basis

**The mechanical problem:** `build_rate_limit.csv`'s rule is
`MAX(one_train_floor, α × installed(y−1))`. `installed(y−1)` is **endogenous** — it is
the optimisation's own output. An input bound cannot read the result of the run it
constrains; there is no LEAP expression that can express it.

**What we did this cycle:** pre-solved the recursion offline into an explicit yearly
`Interp()` with 36 anchors, evaluated in Python so the `MAX()` never reaches LEAP as a
function call at all. Allocated across the 3 biodiesel / 4 ethanol processes using
canon's own share-of-historical-production idiom (shares sum to exactly 1.00000 per
family). **This is done — Part C is authored.**

**The ask is for next time:** ship the **explicit pre-solved trajectory** — the actual
year-by-year Mt/yr numbers, per (ams, process) — rather than the recursive rule. You
hold the fleet basis; we should not be re-deriving it.

**And one reconciliation now:** your Indonesia FAME installed base is **13.05 Mt**;
canon carries **18,548 million litres** ≈ 16.3 Mt at 0.88 kg/L. That is a **~25%
divergence**, and since the whole trajectory is `α × installed`, it propagates to every
year. Which basis is right?

---

## A3 — Brunei biomass: the citation is a paraphrase *(still open)*

Your Tun et al. (2019) Table 2 citation has **no column header, no page, and no verbatim
cell**. The two plausible readings of it differ by **244×** on a `Maximum Production`
cap — in an optimised scenario, that is the difference between a binding constraint and
an unbounded one.

Your own corroboration argues against the reading you took: the column mixes units
within itself, and Brunei comes out 330× smaller than Singapore.

**We need one of two things:**

1. The **verbatim column header** plus the **verbatim Brunei, Cambodia and Singapore
   cells**, as printed; or
2. A **bottom-up residue-tonnage falsification** — Brunei's actual agricultural /
   forestry residue arisings, from any source — which we will accept in place of the
   citation.

**We have not authored the 0.01 TWh value.** The row is held.

Related and also unauthored: your MSW routing proposal (~0.37 TWh →
`Resources\Primary\Municipal Solid Waste`) is canon-consistent structurally, but the
value is sitting in the record unadopted. Confirm it or withdraw it.

---

## A4 — Four promised deliverables were not shipped: which artifact governs?

`blend_ramp_workplan.md` commits to these; the zip does not contain them:

| # | Promised | Where |
|---|---|---|
| 1 | The **Thailand biodiesel finding** — "canon TH biodiesel 25@2037 exceeds the feasible ceiling" | Workplan instructs it **twice**; no such row in `blend_ramp_findings.csv` |
| 2 | **R7 back-tests for Thailand and Philippines ethanol** | Only Indonesia biodiesel shipped, as INFO |
| 3 | The **Thailand 2035 conditional** — "2035→10 conditional on a documented OEM Euro-5 B10 declaration; if absent hold 7" | Workplan §5; not in any shipped file |
| 4 | **Timor Leste rows** | Workplan §5:352 |

We are not asking you to produce all four now. **We are asking which artifact governs**
— the workplan, or the shipped CSVs. If the workplan is a working document that the CSVs
supersede, say so and we will stop diffing them. If the four are genuinely outstanding,
tell us which matter for this cycle.

*(On #4 specifically: Timor Leste is disabled in the calculation and excluded from this
cycle, so it is not urgent — but the promise is open in the record.)*

---

## A5 — Indonesia 2026 = 50.0 contradicts your own text

Three of your own artifacts give three numbers for Indonesia biodiesel 2026:

| Source | Value |
|---|---|
| `blend_ceiling_ramp.csv` (shipped) | **50.0** |
| Your §4 | "the 2026 mandate-average is **45**, not 50" |
| Your D5 | "carry **38** with a stated ±5 band" |

The shipped 50.0 drives a **+15.9 pp single-year step**, which is the largest
single-year movement anywhere in the deliverable and the one most likely to be
questioned downstream.

**We need the reconciled value.** We have authored 50.0 as shipped and will re-issue that
one cell on your reply.

---

## A6 — `binding_reason` labels don't match your own evidence

All 20 of the 2025 rows carry `binding_reason = observed_achieved_floor`. **Eleven of
them have no observation in `blend_observed_panel.csv` at all** — Brunei, Cambodia, Laos,
Myanmar and Singapore × both fuels, plus Malaysia bioethanol.

Two more specifics:

- **Malaysia biodiesel 12.0** is, in your own panel, a **2026-dated, Low-confidence,
  explicitly-constructed estimate** — shipped at Medium confidence as a 2025 anchor.
- **Thailand 8.2 / 13.7** are 2020 and 2019 peak values, not 2025 observations. Under
  your peak rule that is fine — the label should just read `peak_observed_floor`.

**This is a data-provenance ask, not a critique of the values.** We accepted the numbers
and authored them (per R5, they are now the uniform 2025 anchors across all three
scenarios). We need the *label* to match the evidence, so downstream readers can tell an
observation from a construction.

---

## A7 — Please add a FAIL-class `ceiling ≥ floor` test

`blend_ramp_check.csv` contains **zero** floor-vs-ceiling tests. That is the single
failure class that stopped this payload: `Minimum Share of Production` and
`Maximum_Share_of_Production` are both live on the same RAS branch, and the shipped
ceiling sat below the floor in 61 region-year cells.

**The ask is one new test**, FAIL-class:

> For every (region, fuel, year) in the ceiling, evaluate the canon
> `Key\Biofuel Blending Targets\*` floor under the ramp reading (R2), convert both to the
> same basis, and FAIL if `ceiling < floor`.

We will supply the evaluated canon floor series if that helps — say the word.

**Symmetric note:** our own Stage-1 pre-flight was equally blind to this. `schema.py` had
no `MaxShareProduction` and `infeasibility.py` had no min>max check, so our gate returned
CLEAN on your payload. We shipped that tripwire in the same cycle. Neither side caught
it; both sides should now.

---

## A8 — Send the refreshed 581-row `bioenergy_leap_input.csv`

You re-authored 15 unit rows and shipped only a description of the change. **We are one
revision behind master.**

For the avoidance of doubt: we verified those 15 rows do not intersect the 89-row
payload, so nothing in this cycle is wrong because of it — but the repo copy is stale and
the next cycle will diff against it.

*(And to be clear about why you re-authored them at all: our authoring guide falsely
claimed automatic unit conversion. That was our error, corrected 2026-07-22. See the
cover §3.2.)*

---

## A9 — Three `Maximum Capacity` cells sit below the existing fleet

**New finding from our authoring pass, not previously raised.** You allocate
`Maximum Capacity` across processes by **feedstock availability**; canon allocates by
**share of historical production**. In three cells the two disagree enough that your 2025
cap lands **below the plant that already exists**:

| Region / process | Your 2025 cap | Existing fleet |
|---|---|---|
| Philippines FAME Biodiesel | 0 | 15.60 |
| Thailand Molasses | 0 | 1.07 |
| Philippines Molasses | 0.365 | 0.469 |

*(units per the refinery convention — Million GJ/Yr biodiesel, Million TCE/Yr ethanol)*

The `Max(Exogenous Capacity, …)` guard from R7 stops this from halting the inject — but
it also means **those three caps are dead letters**: the guard raises them to the
existing fleet and your intended constraint never binds.

**We need:** either a revised allocation for those three, or confirmation that the
feedstock-availability basis is intentional and the guard override is acceptable. This is
a content call — we are not going to re-allocate your caps.

---

## Not asked, for completeness

So you know what we deliberately did **not** send back:

- Region names in this drop *(fixed on our side; one vocabulary on future drops, please)*
- Unit strings *(fixed)*
- Branch paths, variable spellings, scenario tagging *(ours)*
- The volume→energy conversion *(our error, fixed)*
- The `Rice Straw` / `Used Cooking Oil` branch-create template *(our error, erratum
  issued)*
- Anything about your ×0.85 / ×0.92 haircuts, your ramp-rate semantics, your realisation
  derivation, your evidence weighting, or your per-AMS convergence argument — **your
  method, your call.**
