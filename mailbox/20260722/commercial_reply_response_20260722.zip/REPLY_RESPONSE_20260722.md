# Commercial — response to your 2026-07-22 reply

**From:** AEO-9 commercial-buildings team · **To:** LEAP modelling / canon team
**Re:** your reply to `commercial_leap_sendback_20260721.zip`

Thanks — the structural rulings are all accepted, and the `Commercial Fuel Share_`
corpus scan is decisive. Answers to your six items below, plus the two notes.

## 1. Your rulings — acknowledged, nothing needed from us

- **Shares live on `Activity Level`.** Accepted. We have re-labelled our B10 list:
  **7 of the 9 are not live defects** (they sit on the inert `Commercial Fuel Share_`).
  We keep them recorded as cosmetic-only so nobody re-reports them. Bug 7 answered in §2.4.
- **AC borrow — you re-point it.** Understood; the `!EER` → parent-level
  `Useful Energy Intensity` ratio is the right shape. Tier mapping in §2.5.
- **Naming / `Interp()` assembly / `Remainder(100)` closure — yours.** Agreed, no resend.
- **Refrigeration ratio `0.604`.** Correct — the CSV column governs; the prose "0.60" was
  a rounding. Use `0.604` (GIZ CRE EEI P20/median, GEMS Determination 2024 F2024L01263).
- **Data_Center retraction** noted; we have removed it from our queue.

## 2. Answers

### 2.1 + 2.2 — per-building-type values → `building_type_intensity.csv` (attached)
You are right that our control does not belong on the composite. Attached are **only the
types we actually re-sourced**; every other type/AMS keeps its canon value, so the
composite recomputes itself:

| Country | Building type | kWh/m2 | Source |
|---|---|---|---|
| Thailand | Retailer | **350** | canon `.350` is a decimal typo — **confirmed 350** (§2.2) |
| Singapore | Office | **218** | BCA Building Energy Benchmarking Report, median office EUI |
| Singapore | Hotel | **292** | BCA Building Energy Benchmarking Report, median hotel EUI |
| Singapore | Retailer | **405** | BCA Building Energy Benchmarking Report, median retail EUI |

This is what drives the Singapore 282.89-vs-214 gap you spotted: once these land on
`Energy consumption per area`, the composite moves and our B1 reconciles against it.

### 2.3 — Lighting B1: **withdrawn**
Confirmed: nothing under `Lighting` consumes the end-use intensity. Rather than ask you
to re-wire the leaves, we **withdraw the 10 Lighting rows** — `end_use_intensity.csv` is
now **50 rows** (5 end uses). **Lighting saturation (B3) is unaffected and still ships**
(60 rows). Our sourced Brunei (10.51, BEI 2019) and Laos (61.56, ERIA) lighting
intensities are retained on our side as reference only; if the Lighting leaves are ever
re-parameterised onto an end-use intensity, ask us and we will re-issue.

### 2.4 — Bug 7 → `water_heating_solar_shares.csv` (attached)
Thank you for catching that it is in **Carbon Neutrality_ Net Zero as well as RAS** — we
had only flagged RAS. Attached: per-region `Water Heating\Solar Heating : Activity Level`
for **both** scenarios. The values are the canon's own EBT 2022 figures that the uniform
`2` was overriding:

- **Indonesia 30.71**, **Thailand 3.39**, all other AMS **0**.

Apply to both `Regional Aspiration Scenario` and `Carbon Neutrality_ Net Zero Scenario`.

### 2.5 — AC class → efficiency tier: **your default, accepted**
- `Best Practice` → **High_eff**
- `Efficient` → **Mid_eff**
- `Current Sales_Average` and `Current Stock_Average` → **stock-weighted parent**

This preserves three distinct levels across our four classes and matches our own
efficiency ordering (Current Stock 1.00 < Current Sales 0.90 < Efficient 0.70 <
Best Practice 0.55). We accept the minor loss that Current Sales collapses onto the
parent alongside Current Stock.

### 2.6 — `!Missing Branch (ID=1687/825)`: **drop the price term**
Use the **no-price-term** shape: a GDP-only form, no `Ln(<price>)`.

Rationale: every candidate target is zero. You confirm `Resources\Secondary\{Ethanol,
Biodiesel}:Commercial Consumer Price` are `0` in every region and scenario, and our own
scan of the 12 referenced price branches found **316 of 356 `Commercial Consumer Price`
cells (88.8%) are literal 0** — the proxy candidates (Diesel, Gasoline) are 83–100% zero
too. So same-name and proxy both just relocate the `Ln(0)`. The coefficients are still
the unfitted placeholder `1`, so no fitted elasticity is lost by dropping the term. This
removes the defect outright rather than moving it.

If/when the Resources team populates real commercial price series (our standing
escalation), we would revisit and re-introduce a price term with fitted coefficients.

## 3. Your two notes

- **Roster is 38, not 36 — corrected.** You were exactly right: we had dropped the two
  Lighting arm branches. `b7_fuel_share_disposition.csv` (attached) now carries **38**
  leaves — and the arms are correctly typed: `Lighting\Electricity` = `Remainder(100)`
  partition closer and `Lighting\Other` = `0` (inert), **not** residential borrows; only
  the five `Electricity\<tech>` leaves borrow.
- **`floor_area.csv` — outstanding, not forgotten.** It is the one §8 deliverable we have
  not sourced. Total gross floor area per AMS per year has no usable public series for
  several AMS; it sits in our queue behind the building-type shares. Until it lands, the
  model's existing `Gross Floor_Area` (GDP-per-capita growth) stands. We will send it
  separately rather than hold this package.

## 4. Package contents

`REPLY_RESPONSE_20260722.md` (this) · `building_type_intensity.csv` (§2.1/2.2) ·
`water_heating_solar_shares.csv` (§2.4) · `end_use_intensity.csv` (**revised**, Lighting
withdrawn, 50 rows) · `b7_fuel_share_disposition.csv` (**revised**, 38 leaves) ·
`canon_conformance_report.md` (re-run, 42/42 pass).

**Unchanged from the 2026-07-21 package:** `end_use_saturation.csv` (60 rows, incl.
Lighting) and `fuel_shares.csv`. No need to re-ingest those.

Questions on values → us.
