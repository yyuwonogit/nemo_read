<!-- Deliverable: the LEAP team's NEW ASK (ASK_blending_ramp_20260721.md, .inbox/bioenergy_ruling_reply_20260721.zip).
     Built 2026-07-22 from a 4-track sourced research panel + adversarial verification. -->

> **In-repo data that partially closes gap B5 (fleet / certification-wall calibration) — found 2026-07-22:**
> `Transport/Historical/Historical_Stock_ByFuel_<ISO3>_fuel_breakdown_2024.csv` gives **2024 stock by fuel x
> vehicle type for all 10 AMS** (Buses / Car / Motorcycles / Truck x Electric / Gasoline / HybridDiesel /
> Natural Gas / Hydrogen FCEV), and `Transport/Gompertz_LDV_2W_Handoff/outputs/stock_by_fuel_ras.csv`
> gives **RAS-consistent projections 2005-2060 with sales AND retirements** (2W + LDV only).
> Headline for the ethanol wall: ASEAN 2024 gasoline fleet = **282.1 m motorcycles vs 37.9 m cars — ~88 %
> two-wheelers**, so the ethanol ceiling is a 2W question. Diesel side ~32.5 m vehicles, of which
> ~12.4 m trucks+buses (where the diesel volume sits).
> **Two caveats before this anchors `W(y)`:** the RAS projection covers only 2W + LDV (no heavy-duty
> turnover), and diesel is labelled `HybridDiesel` - confirm whether that means diesel or hybrid-diesel.

# WORKPLAN — Per-AMS maximum blend-share ramp (`max_blend_share(ams, fuel, year)`)

**Status:** plan, not the number table. Everything below is written so the numbers fall out mechanically once the four blocked inputs land. All verifier corrections adopted; downgraded claims carried in their corrected form with the uncertainty stated.

Scope note carried through the whole document: **FAME-in-diesel and ethanol-in-gasoline only.** HVO is a different fuel with no blend wall and must not be squeezed under these ceilings (§10 D3).

---

## 0. CEILING SEMANTICS — the ruling that governs everything below  **[2026-07-22, BINDING]**

**The deliverable is a CEILING for an optimisation, not a forecast.** The blend share will be
chosen by the RAS optimiser: if a blend level is not the optimum, it will not appear in the
result regardless of what our table permits. Our only job is to stop the optimiser choosing
something **physically impossible**.

That has one hard consequence, and it invalidates part of the method drafted in §3.3–§3.4 and §4:

> **A ceiling may encode only physical and legal limits.** Fuel spec, in-use fleet
> compatibility, the maximum demonstrated rate of physical change, and dated legal
> instruments. It may **not** encode absence of a mandate, institutional capacity, fiscal
> capacity, market size, or a price-driven policy suspension — those are economics and
> policy, the optimiser and the cost side already see them, and baking them into a ceiling
> forbids an outcome that is merely *unlikely* rather than *impossible*.

What this deletes from the drafted method:

| Drafted mechanism | Status | Why |
|---|---|---|
| Difficulty multiplier `m` throttling the ceiling (§3.3) | **VOID as a ceiling input** | institutional pace is a forecast |
| `binding_reason = no_policy_instrument` / `announced_policy` | **VOID** | absence of a mandate is not a physical bound |
| Philippines held at 5.0 to 2030 | **VOID** | the B4/B5 suspension was a price event |
| Brunei / Singapore capped at 10 % on market structure | **VOID** | market size is economics |
| Thailand held to B7–B10 on its Euro-5 fleet | **VOID** | Indonesia runs B40 on a comparable common-rail share; Thailand's B10 deletion was palm-price + OEM warranty stance |
| `binding_reason = feedstock_affordability` / `fiscal_capacity` | **VOID** | both are cost-side |

What survives, and is what actually ships:

```
ceiling(a,f,y) = min( technical_blend_wall(a,f,y),          # fuel spec + in-use fleet
                      prev + max_demonstrated_ramp_rate )   # fleet turnover / terminal retrofit
      floored by: dated legal instrument in force
                  PEAK observed achieved blend for that country-fuel
```

The observed floor is the **peak** the country's own fleet has ever burned, not its latest
value. Once Thailand's fleet has run B8.2 nationwide, no ceiling may later declare B8.2
impossible for Thailand; it withdrew B10 on price, which is the optimiser's call.

Surviving `binding_reason` taxonomy — **4 values, all physical**:
`technical_blend_wall` · `max_physical_ramp_rate` · `legal_instrument_floor` ·
`observed_achieved_floor`.

**Intended consequence: the ceiling is broadly SIMILAR across AMS and converges on the
technical wall.** Indonesia demonstrated ~3 pp/yr sustained and an 8.3 pp single-year step on
a real fleet, so that rate is physically available to any country whose economics justify it.
Differentiation survives only where physical: Indonesia already in-market at B50, dated legal
instruments, and each country's demonstrated starting point.

The enabler scorecard, the ladder and the per-AMS gate placement below are **retained as
evidence and as a narrative of how the journey is walked** — they no longer compute the
ceiling. §7's G6 back-test is correspondingly replaced by **R7 ceiling admissibility**: the
test is not "does it predict history" but "would it have *forbidden* history".

---

## 1. Objective, and the test each number must pass

**Objective.** Produce a defensible ceiling curve `max_blend_share(ams, fuel, year)` in **volume %**, anchor years {2025, 2026, 2027, 2030, 2035, 2040, 2045, 2050, 2055, 2060}, 10 AMS × 2 fuels, each row carrying `binding_reason` (closed taxonomy, below), `confidence` (high/med/low), and `source`. It bounds `Maximum Share of Production`-class behaviour in LEAP so the RAS optimiser cannot buy a blend share that no country has ever physically delivered — the same class of defect as V1 (Myanmar 2,490 PJ on a free, uncapped route).

**A ramp is "robust" only if every cell passes all seven gates:**

| Gate | Test |
|---|---|
| **G1 Provenance** | The value traces to (a) an *achieved* blend published in a primary series, or (b) a dated legal instrument, or (c) an explicitly labelled rate-limited extrapolation from (a)/(b). No third category. |
| **G2 Rate** | No single-year step > 8 pp (biodiesel) / > the legislated grade-switch size (ethanol); no rolling-5-yr average > 3.0 pp/yr for any AMS at any time; and ≤ the country's tier-discounted rate (§3). |
| **G3 Wall** | Never above the certification wall in force that year, unless a documented enabler exists (national B100/E-spec tightening + OEM declaration + completed road test). |
| **G4 Floor** | Ceiling ≥ the *in-force* mandate for that year. If our ceiling sits below a country's own announced target, we do **not** silently raise it — we emit a FINDING row. That gap is a deliverable in itself. |
| **G5 Feedstock** | Blend % → biofuel volume → PJ → feedstock tonnes must sit inside our own Cap-1 residual for that AMS-crop-year. Currently **blocked** (§8 B1). |
| **G6 Back-test** | The rule set, run forward from 2015 on 2015-vintage information, reproduces Indonesia 2025 within ±3 pp, Thailand ethanol 2024 within ±2 pp, Philippines ethanol 2025 within ±1.5 pp. |
| **G7 Label** | Has a `binding_reason` from the closed taxonomy and a confidence label that survives into the CSV (the verifiers' repeated complaint: §7 honesty dies at the handoff). |

**Closed `binding_reason` taxonomy (7 values, no free text):**
`technical_blend_wall` (fleet certification / OEM warranty / national fuel spec) · `blending_distribution_infrastructure` · `feedstock_volume` · `feedstock_affordability` (price-gap fundability — **new class, added because the Philippines B4/B5 suspension is a price event our volumetric 564 PJ coconut cap cannot see**) · `fiscal_capacity` (price-gap fund exhaustion) · `announced_policy` (instrument exists and binds above achieved) · `no_policy_instrument`.

Two disciplines that override everything: **MANDATE ≠ ACHIEVED** (every row states which it is), and **a technical wall is hard and price-inelastic; an infrastructure or policy ceiling is soft and may relax if the model is allowed to build.** Misfiling the second as the first is what makes a RAS result wrong in the direction nobody notices.

---

## 2. The Indonesia benchmark

### 2.1 Observed mandate-vs-achieved (achieved = biodiesel ÷ on-road diesel pool, vol %, USDA FAS GAIN Jakarta Table 8; 2015 from ID2024-0018 Table 9)

| Year | Mandate in force | Achieved | Realisation |
|---|---|---|---|
| 2015 | B15 (23 Mar; CPO Fund created) | **2.7** | 18.0 % |
| 2016 | B20 (PSO) | **10.5** | 52.5 % |
| 2017 | B20 (PSO only in practice) | **8.2 ▼** | 41.0 % |
| 2018 | B20 nationwide from 1 Sep | **11.9** | 59.5 % |
| 2019 | B20 | **17.1** | 85.5 % |
| 2020 | B30 | **25.4** | 84.7 % |
| 2021 | B30 | **25.1 ▼** | 83.7 % |
| 2022 | B30 | **25.7** | 85.7 % |
| 2023 | B35 (Feb regional → Aug nationwide) | **28.9** | 82.6 % |
| 2024 | B35 | **32.2** | 92.0 % |
| 2025 | B40 (effective **March**, not Jan) | **34.1 (f)** | 85.3 % |
| 2026 | B40 H1 → **B50 from 1 Jul**, all SPBU 1 Oct | not observed | mandate-average is **45**, not 50 |

**Realisation band (corrected): 82.6–92.0 %, mean 85.6 %** — not the 85–92 % originally claimed; three of seven years fall below 85 %. Pattern: **step years 0.83–0.85, steady-state years up to 0.92.** Pre-2019: 18 % (2015), then 41–60 % (2016–18).

### 2.2 Rate arithmetic — and the base-year artefact

| Window | pp/yr | Comment |
|---|---|---|
| 2015→2025 | 3.14 | **Base-year artefact** — 2015 is a launch stub |
| 2016→2025 | 2.62 | |
| 2017→2025 | 3.24 | starts from a regression trough |
| 2019→2025 | 2.83 | |
| **2020→2025 (mature, post-B30)** | **1.74** | the honest mature-programme rate |
| 3-yr burst 2017→2020 | 5.73 | never repeated |
| 2-yr burst 2018→2020 | 6.75 | never repeated |

**Adopted benchmark values:**
- **Max sustained (best-endowed country, from a sub-B10 base): 2.5 pp/yr**, absolute ceiling 3.0–3.2 pp/yr over any rolling 5-yr window.
- **Mature-programme sustained (above ~B30): 1.7–2.3 pp/yr.**
- **Max single-year step ever achieved: +8.3 pp** (2019 17.1 → 2020 25.4, the B30 rollout). Runner-up +7.8 pp (2015→2016). On paper the largest step was +10 pp; 8.3 pp of it landed. **Hard single-year cap = 8 pp.**
- The 3.75 pp/yr figure appearing in one track is deleted — it dates B20 to its achieved date and B50 to its mandate date, an inconsistent basis.

### 2.3 Where it paused, and why (this is the shape evidence)

- **2017: outright regression, −2.3 pp**, with B20 nominally in force — non-PSO diesel was not enforced until Pres. Reg. 66/2018. *Ceilings are not monotonic.*
- **Dec 2018 – Jun 2020: CPO levy collection halted for ~18 months** on falling CPO prices; zero new BPDPKS revenue. Blend rose only on accumulated balance. → `fiscal_capacity`.
- **2020–22: three-year plateau at ~25 %** with the mandate frozen at B30; 2021 subsidy $3.2 bn against $4.5 bn levy; 2022 cooking-oil crisis, DMO and the April export ban diverted feedstock to food.
- **2023: B35 regional Feb → nationwide Aug.** **2025: B40 effective March, not January.**
- **2026: B50 near-miss.** Dec 2025/Jan 2026 the government signalled holding B40 all year (flat quota 15.646 mn kL), citing technical, fiscal and market factors and the crude–CPO spread; reversed and launched B50 on 1 Jul with a three-month transition. B50 needs ~4.0 bn L of capacity above the 19.6 bn L installed in 2025 (GAIN, verbatim).
- **Industry objections persist**: Aprobi on capacity beyond B40; the auto association on water content at ≥B30, shorter filter intervals, ~5 % higher consumption.

**Shape rule that falls out:** discrete 5–10 pp steps separated by 1–3 flat years, each gated by a ~6–12 month road-test campaign, with occasional reversals. **A smooth interpolation overstates mid-period blend by ~3–5 pp.**

### 2.4 Enabling conditions — and which are Indonesia-specific

| Enabler | Transferable? | Why |
|---|---|---|
| **Dedicated off-budget price-gap fund** (CPO export levy → BPDPKS since 2015; levy 10 % May 2025 → 12.5 % Mar 2026 specifically to fund the step) | **NO — Indonesia-specific** | No other AMS has a self-financing levy on an export commodity large enough to fund a domestic fuel subsidy. And it is *self-limiting*: B50 diverts CPO from export, so levy revenue falls as the subsidy need rises. |
| **Single dominant state offtaker** (27 appointed blenders, Pertamina ~81 % of allocation; Pertamina+AKR ~70 % of distribution) | **NO — Indonesia-specific** | TH/PH/MY have fragmented private retail. VN is the only partial analogue (Petrolimex+PVOIL). |
| **Enforced allocation with administrative sanctions** | **NO** | Mandates elsewhere are specification-based, unenforced, or suspendable by advisory (Philippines, Jul 2025). |
| **Domestic feedstock dominance** (~46 Mt/yr CPO; B50 incremental ≈ **+4.7 Mt, ~10 % of the crop** — corrected from 5.3 Mt/12 %) | **Partly** — only Malaysia has comparable palm headroom | PH depends on coconut, whose price spike is exactly what killed B4/B5. SG has none. |
| **OEM pre-modification of the national fleet** (~90 % Japanese-brand; makers modified injection/ignition systems in trucks *already supplied*) | **NO — Indonesia-specific** | No other AMS has that buyer power. Elsewhere fleets sit at the B7 warranty tier. |
| **National fuel-standard authority + road-test programme** (B50 road test used B100 with *tightened* water, monoglyceride and oxidation-stability limits, explicitly different from in-market B40; B50 decree carries 24 quality parameters) | **YES — the one genuinely transferable enabler** | This is the real gate above B20, and it is a national standards capability, not a fleet property. Promote it in the taxonomy. |
| **~20-year runway with testing before each step** (2008→2026) | **YES but slow** | No other AMS has started. |

**Therefore: we cannot copy Indonesia's rate.** Four of the six enablers are structurally unavailable elsewhere. Note also that the fleet was *not* the constraint — Indonesia reached B50 on a fleet averaging ~11.5 years old — so the binding reasons above B30 were fuel spec, blending logistics and fiscal support, all of which are country-institutional.

### 2.5 The counter-anchor inside the same country

Indonesia's **bioethanol blend has been 0.0 % every year 2015–2025** (GAIN Table 7). 2025f fuel ethanol: 3 ML against a 37,466 ML gasoline pool = **0.008 %**. E5 sold at ~177 stations (2025) out of >7,800; 812 kL of bioethanol utilised. **Fuel-grade** ethanol capacity ≈ **26,000 kL/yr** against ~1.65 mn kL/yr needed for national E5 — a **~60× shortfall**. Mandatory E5 (7 provinces only) starts 1 Jul 2026.

Same country, same fund, same offtaker, same political will: **~3 pp/yr on biodiesel, ~0 pp/yr on ethanol.** Ethanol needs its own constraint stack; Indonesia's biodiesel benchmark does not transfer across the fuel boundary. **Canon `Indonesia bioethanol InterpFSY(2025,20; 2050,50)` is falsified by observation and is the single largest defect in the current mandate canon.**

### 2.6 The ethanol benchmark — do NOT anchor regionally on Indonesia's zero

Verifier correction adopted: Indonesia is the ASEAN outlier, not the rule.

- **Thailand achieved:** 12.1, 12.0, 13.0, 13.2, **13.7**, 12.7, 12.5, 12.6, 11.2, 11.3 % — above E10 for a decade. 2024 road ethanol 3.43 MLPD (below the 2018 rate of ~4.1 MLPD) → **2024 achieved ≈ 11–12 %**, derived. Do not carry 13.8 % (2018) forward.
- **Philippines achieved:** 8.6 → 10.1 % (2025f), E10 essentially fully realised, 54 % of supply imported.
- **Indonesia:** 0.0 %.
- **Observed ASEAN ethanol ramp where it happened: 0.5–1.3 pp/yr.**
- **E20 is not a physical wall.** India took E10→E20 in ~3 years (2022→2025), on a motorcycle-majority fleet, over public objection, with OEM E20-material compatibility only from Apr 2023. Brazil moved mandatory E27→**E30 on 1 Aug 2025** across all Gasoline C including non-flex stock. Above-E20 is an **OEM-declaration, two-wheeler-stock and supply** question — policy and economics, not physics. Thailand's E85 exit (0.3 % of the E10 grade; PTT OR out 1 Feb 2026) is a *grade-rationalisation decision by one country*, not a regional ceiling.

---

## 3. The method — a constraint stack under a rate limit

### 3.1 Level cap (what is possible at all in year *y*)

```
level_cap(a,f,y) = MIN( W(a,f,y),      # technical/certification wall
                        I(a,f,y),      # infrastructure-feasible share
                        F(a,f,y),      # feedstock-implied share
                        P(a,f,y) )     # policy ceiling
```

- **W — technical wall.** Not a constant; it rises with certified-stock share.
  `W(y) = W0 + (W_target − W0) × S(y)`, where `S(y)` is the share of in-use stock certified to `W_target`, modelled with `ref_curves.logistic_transition(years, T_c, T_c+25, steepness=0.25)` where `T_c` = the model year from which all new sales are certified. Calibration from ASEAN fleet ages (~11.5 IDN / 11.7 PHL / 11.9 VNM, survival tail 25–30 yr; PH LTFRB recognises trucks to 26 yr): **~50 % of stock by T_c+11, ~90 % by T_c+20, ~100 % by T_c+25 → an effective 0.8–1.2 pp/yr from fleet turnover alone.** Delete the "double Japan/Korea" comparator — it was wrong (Japan in-use ≈ 9 yr); the 1 pp/yr result stands on the ASEAN age and tail alone. Fleet-age figures themselves are unverified (§8 B5).
  Baseline `W0`: **B7** (EN 590 hard FAME max; Euro 5/6 common-rail + DPF warranted only to B7 — the reason Thailand deleted B10 on 1 May 2024), **B20** for a mixed in-use fleet under ASTM D7467 with service-interval changes, **B30–B50 only with the four-part enabler set** (tightened B100 spec + OEM road test + shortened filter intervals as a warranty condition + controlled blending). Above B50: no fleet-scale evidence anywhere — extrapolation only, flagged low confidence. Ethanol: **E10** as the universal warranty line, **E20** on an OEM model-year cut-off plus either grade segregation or grade replacement, **>E20** requires an explicit OEM declaration (possible — India, Brazil — not free).
  Cold flow/CFPP is **not** binding in tropical ASEAN; do not use it as a reason. Correspondingly, drop the "push FAME down to 7 % in an HVO-rich pool" recommendation for ASEAN — the precipitation mechanism is a cold-temperature one; retain it only for highland Lao / northern Viet Nam if an HVO pathway is ever opened there.
- **I — infrastructure-feasible share.** Terminal in-line blending coverage: `I = Σ(terminals capable of grade g × their throughput) / national pool`. Malaysia is the cleanest live example — B15 rolled out 1 Jun 2026 with **B12 supplied in areas whose terminals could not make B15**, across 34 blending depots, "in line with the upgrading of blending facilities". This is the pacing item at ~1 pp/yr for Malaysia and it is *soft* — it relaxes if the model is allowed to build.
- **F — feedstock-implied share.** Invert the blend: `F = min over crops( Cap1_residual_t(a,crop,y) × LHV / (pool_PJ(a,y) × conversion) )`. Two hard preconditions: the **FFB/CPO basis defect (V2/T1.1)** must be settled first — the identity `production_PJ = crop_equivalent_t × 36.54` proves a crude-palm-oil LHV was applied to fresh-fruit-bunch tonnage (crop-equiv ÷ commodity = **4.762** palm, **15.873** coconut, both exact) — and ethanol feedstock must be kept strictly separate from biodiesel feedstock (cassava/sugarcane headroom is ethanol-directed; never net it against a biodiesel blend).
- **P — policy ceiling.** Only used where an instrument exists *and* binds above the achieved value. Announced targets without a delivery instrument do not raise the ceiling; they generate a §7 R4 finding.

### 3.2 Rate limit (how fast it may move)

```
max_blend(a,f,y) = MIN( level_cap(a,f,y),
                        max_blend(a,f,y−1) + r(a,f) × D(a),
                        max_blend(a,f,y−1) + step_cap(a,f,y) )
```

with, on top, a **realisation haircut** applied to any value that is set by a mandate: `× 0.85` in the step year and the year after, `× 0.92` from the second full year of steady state. (Indonesia's own numbers: step years 0.83–0.85, steady-state up to 0.92. There is no year at 1.00.)

- `r(biodiesel)` = **2.5 pp/yr** below B30, **2.0 pp/yr** at or above B30 (mature-programme evidence 1.7–2.3).
- `r(ethanol)` = **1.0 pp/yr** (observed 0.5–1.3 where it happened).
- `step_cap` = **8 pp** for biodiesel (Indonesia's record), **1 × r** otherwise — *except* the **legislated grade-switch exception**: where a dated legal instrument replaces the base grade nationwide, allow a single step to the mandated level × 0.85, then hold ≥2 years. This is required to represent Viet Nam's E10 (1 Jun 2026, Circular 50/2025/TT-BCT + Decision 46/2025/QD-TTg) and Thailand's E20-as-base-grade (2027), and it is why "+1 pp/yr" is the wrong shape for ethanol — the real shape is **flat-then-step**.
- **Rolling-5-yr average ≤ 3.0 pp/yr for every AMS, always.** This is the guard that survives the step exception.
- **Ceilings may fall.** Thailand deleted B10 (1 May 2024) and cut the standard B7→B5 (21 Nov 2024, temporary, on CPO price); the Philippines suspended B4/B5 (Jul 2025). Thailand's achieved biodiesel series is non-monotonic — 5.7, 5.6, 6.0, 6.5, 7.8, **8.2**, 7.3, **5.3**, 6.4, 6.8. A monotone-only ceiling overstates the region.

### 3.3 Replication lag — enablers are SPEED, not gates  **[SUPERSEDES the earlier discount model, 2026-07-22]**

> **[DEMOTED TO EVIDENCE, 2026-07-22 — see §0]** The ladder below is the correct account of
> *how* Indonesia walked 0 → B50, and it stays in the package as the narrative and as the
> calibration check that caught the mandate/achieved basis error. It **no longer computes the
> shipped ceiling**: institutional pace is a forecast, and a ceiling may only encode physical
> and legal limits. `m`, gate placement and the `no_policy_instrument` reason are void as
> ceiling inputs.

**Framing correction (user ruling).** The earlier version treated Indonesia's enablers as *preconditions* and assigned `D = 0.00` to countries lacking them — which freezes half the region at zero blend for 35 years. That is wrong. **Indonesia proves the path is walkable.** A country missing an enabler does not stay at zero; it **builds the enabler first and arrives later**. Difficulty sets the *lag and the speed*, never a permanent zero.

**The horizon makes this decisive:** Indonesia went **0 → B50 in 18 years** (2008 first mandate → 2026 B50). Our window 2025→2060 is **35 years — 1.9× that journey.** So every AMS has room to complete an Indonesia-class transition inside the horizon, even starting cold and moving at half Indonesia's pace.

#### The replicable ladder (Indonesia's observed gates)

| Gate | What must exist | ID year | Δ | ID achieved after |
|---|---|---|---|---|
| **A** | A legal blending mandate at all | 2008 | — | ~0 |
| **B** | A price-gap funding mechanism (levy→fund) | 2015 | +7 yr | 2.7 |
| **C** | Enforcement beyond the subsidised segment → nationwide | 2018 | +3 yr | 11.9 |
| **D** | Fuel-spec authority + road-test programme → B30 | 2020 | +2 yr | 25.4 |
| **E** | Mature spec-gated stepping B35→B40→B50 | 2026 | +6 yr | ~45–50 |

**Total A→E = 18 years, 0 → B50.** Gate B is the pivotal one (achieved was ~0 before it) and Gate D is the one that is genuinely transferable capability rather than endowment.

#### The rule

```
1. Place each AMS at the gate it has ALREADY reached (evidence-based, not aspirational).
2. Remaining gates take Indonesia's duration x m(a), the difficulty multiplier.
3. Between gates the blend follows Indonesia's achieved shape (step + plateau), rate-limited
   by r and haircut by realisation, exactly as in 3.2.
```

`m(a)` from the same six-enabler scorecard — now read as **speed**, not permission:

| Missing enablers | `m` | Meaning | A→E duration |
|---|---|---|---|
| 0–1 | **1.0** | can move at Indonesia's pace | 18 yr |
| 2 | **1.3** | | 23 yr |
| 3 | **1.6** | | 29 yr |
| 4+ | **2.0** | must build institutions first | 36 yr |

A country entering at Gate A in 2025 with `m = 2.0` reaches B50-equivalent ≈ **2061** — i.e. essentially the full ladder inside our horizon, arriving at the very end. Countries already at Gate C–D (Malaysia, Thailand, Philippines) finish **much earlier**, because they have already spent those years.

**What difficulty does NOT do:** it does not hold a country at 0 for 35 years. A `binding_reason` of `no_policy_instrument` is valid **only until the country reaches Gate A in our timeline** — after that the reason must become a real constraint (feedstock, spec, infrastructure) or the ceiling must move.

**Discipline retained:** Viet Nam remains the falsification case — it had the offtaker lever, mandated E5 nationwide from 1 Jan 2018, and realised only **~1–2 %** because consumers bought unblended RON95. That is why the ladder is gated on *enforcement actually landing* (Gate C), not merely on a mandate existing (Gate A). Enablers are still scored and cited; they now set pace rather than permission.

Also delete the claim "countries without the lever have never delivered faster than ~1 pp/yr" — Malaysia moved B10→B15 (5 pp) in one year, Viet Nam E5→E10 (5 pp). The correct form is: **sustained multi-year averages run 1–3 pp/yr; individual steps run 2–10 pp.** That is exactly what the stack encodes.

---

### 3.4 The ethanol ladder — same logic, different exemplars

> **[DEMOTED TO EVIDENCE, 2026-07-22 — see §0.]** What survives into the ceiling is the
> single physical conclusion: **E20 is an OEM-declaration question, not physics** (India ran
> E10→E20 in 3 years on a 2W-majority fleet; Brazil mandates E30 on non-flex stock). So the
> ethanol wall is 10 → 15 → **20 by 2032 for every AMS**, and the 2W share sets no cap.

Indonesia is the wrong anchor for ethanol (0.0 % for 11 straight years). The replicable ethanol record is **Thailand + Philippines regionally, India + Brazil globally** — and it shows E20 is reachable, and above-E20 is a decision rather than physics.

| Gate | What must exist | Exemplar | Observed duration |
|---|---|---|---|
| **A** | Blending mandate (E5/E10) | PH 2007, VN 2018, TH 2000s | — |
| **B** | Supply route — domestic distillery capacity **or** a standing import channel | PH imports ~54 % of supply; ID is stuck here (**26,000 kL/yr vs ~1.65 mn kL/yr needed ≈ 60× short**) | the usual blocker |
| **C** | E10 realised nationwide (grade actually sold, enforcement lands) | PH ~10.1 %, TH ~11–12 % sustained a decade | PH ≈ 6 yr from mandate |
| **D** | **E20 as base grade** — OEM model-year cut-off + grade rationalisation | TH E20 base grade 2027; **India E10→E20 in ~3 yr (2022→2025)** on a motorcycle-majority fleet | 3–10 yr |
| **E** | Above E20 | **Brazil E27→E30 mandatory Aug 2025** across non-flex stock | proves it is an OEM-declaration question |

**Ethanol arithmetic:** A→D observed at **3 years (India, forced)** to **~10–15 years (Thailand, organic)**. In a 35-year window every AMS can reach **E20**; E20→E30 is available late-horizon on an explicit OEM-declaration assumption (D8).

**The 2W caveat is a pace factor, not a wall.** ASEAN's gasoline fleet is ~88 % motorcycles (282 m vs 38 m cars) — but India ran E10→E20 in three years on exactly that fleet composition. So motorcycles slow the OEM cut-off; they do not cap the region at E10.

---

## 4. Per-AMS treatment table

> **[SUPERSEDED IN PART, 2026-07-22]** The `Tier / D` column below encodes the old
> gates-not-speed model and its `D = 0.00` rows ("hold 0 through 2060") are **void**.
> Read the `Start`, `Bind` and `Special handling` columns — which remain valid evidence —
> against the gate placement here. Every AMS completes or substantially completes the
> ladder within 2025–2060; the differences are entry gate and pace.

**Gate placement at 2025 and indicative arrival (biodiesel → B50-equivalent; ethanol → E20):**

| AMS | Biodiesel: gate now | `m` | ~B50-equiv | Ethanol: gate now | `m` | ~E20 |
|---|---|---|---|---|---|---|
| **Indonesia** | **E** (B50, 2026) | 1.0 | **done 2026** | **A** (E5 pilot, 0.0 achieved; supply 60× short) | 1.6 | ~2045 |
| **Malaysia** | **C/D** (B12–15, retrofit-paced; has feedstock + directed offtaker) | 1.0–1.3 | ~2040 | **0/A** (no programme) | 2.0 | ~2055 |
| **Thailand** | **D**, held at B7 by the Euro-5 OEM spec | 1.3 | ~2045 | **C→D** (E20 base grade 2027) | 1.0 | **~2027** |
| **Philippines** | **B/C** (B3; suspended on coconut price) | 1.6 | ~2050 | **C** (E10 realised) | 1.3 | ~2035 |
| **Viet Nam** | **A−** (no diesel instrument) | 1.6 | ~2055 | **A→C** (E10 mandatory 1 Jun 2026; E15 proposed 2031) | 1.3 | ~2035 |
| **Lao PDR** | **0/A** | 2.0 | ~2060 | **0/A** | 2.0 | ~2055 |
| **Cambodia** | **0/A** | 2.0 | ~2060 | **0/A** | 2.0 | ~2055 |
| **Myanmar** | **0/A** | 2.0 | ~2060 | **0/A** | 2.0 | ~2055 |
| **Brunei** | market-structure case, not difficulty | — | low, by scale | — | — | low |
| **Singapore** | market-structure case — road blend stays low because its biofuel is **aviation + marine**, not because it "can't" | — | low road | — | — | low road |

Brunei and Singapore are the only genuine exceptions, and the reason is **market structure, not incapacity** — a ~450k-person market cannot amortise blending assets, and Singapore's biofuel volume is real but belongs in aviation/marine branches (D6). Do not file either as "no feedstock".



`Start` = best available **achieved** value (mandate values marked *M*). `Bind` = expected binding constraint through 2035.

### Biodiesel (FAME)

| AMS | Start (achieved) | Bind | Tier / D | Special handling |
|---|---|---|---|---|
| **Indonesia** | 34.1 (2025); 2026 **≈38** quota-scaled (17.6 mn kL vs 15.6, ~2 % pool growth) — *range 37–43, see §10 D5* | `technical_blend_wall` (B50 spec) then `fiscal_capacity` (levy is self-limiting: B50 diverts CPO from the export base that funds it) | **T1 / 1.00** | Only AMS allowed >B30. 2026 mandate-average is **45**, not 50 (six months each at B40/B50). B50 is 3 weeks old, <3.5 t cohort had not completed 50,000 km as of Apr 2026 — cap at 50 through 2035, treat 55/60 as low-confidence extrapolation, do **not** justify them with fleet turnover (§2.4: fleet was never the constraint here). |
| **Malaysia** | 2026 annual-avg **≈11–12** (B15 Peninsular from 1 Jun 2026, B12 interim where terminals lag; B20 only Sarawak ex-Bintulu, Labuan, Langkawi; industry still B7) | `blending_distribution_infrastructure` (34 depots, retrofit-paced, explicitly stated by government) | **T2 / 0.60** → ~1.5 pp/yr | Single-endpoint mandate — see §5. NETR B30-by-2030 is a **heavy/commercial-vehicle segment target**, not a national volume-weighted blend. No published volume-weighted national figure exists (§8 B4). |
| **Thailand** | **6.8** (2024); B7 is the only mainstream grade (6.6–7.0 % v/v) | `technical_blend_wall` — B7 is the **Euro 5 / OEM-endorsed limit**, the strongest ASEAN evidence for a genuine hard wall. Filing this as policy softness inverts the reason. | **T3 / 0.35** | Direction of travel is **down**: B10 deleted 1 May 2024; B7→B5 21 Nov 2024 (temporary, CPO price); Oct 2025 roadmap consolidates on **E20 + B7** and redirects effort to SAF (1 % 2026 → 8 % 2036). Must permit non-monotonic ceiling. Single-endpoint mandate — §5. |
| **Philippines** | **3.3** (2025f); **B3 in force** since 1 Oct 2024 | `feedstock_affordability` — coconut oil ~$1,100/t (early 2024) → peak **~$2,771/t** (World Bank; not "$3,000"). Our 564 PJ volumetric coconut cap **cannot see this**. | **T4 / 0.15** | Canon 2024:3 is **correct and must be retained**; only 2025:4 and 2026:5 are unsupported (DOE Advisory **2025-07-001**, 17 Jul 2025, suspended both). B5 is live-but-unscheduled — NSCC (Mar 2026) and DA (Jun 2026) both endorse it. Do not zero it out. |
| **Viet Nam** | **0** — B5/B10 encouraged, never mandatory | `no_policy_instrument`, then `blending_distribution_infrastructure` | **T5 → T2 / 0.00 → 0.60** | Canon `Interp(2023,0; 2050,20)` has no instrument behind it. National effort is directed at gasoline, not diesel. Hold 0 to 2030. |
| **Lao PDR** | **0–2** | `no_policy_instrument` + `blending_distribution_infrastructure` (no refining, road fuel imported as *finished* product; export-grade gasoil out of Thai/Singapore refineries is generally supplied **B0**, blended at destination) | **T5 / 0.00** | Do **not** use "import-pool matched" as a reason — it presents a commercial choice as a wall. Canon `InterpFSY(2030,10)` is a slipped copy of the 2011 RE Strategy's **already-lapsed and unmet 2025** target. §5. |
| **Cambodia** | **0** | `no_policy_instrument` | **T5 / 0.00** | 258 PJ cassava headroom is being developed for **export** (Idemitsu MoU), not domestic blending — the supply-cap workstream must net it out, not count it. |
| **Myanmar** | **0** | `no_policy_instrument` (+ non-financeable infrastructure) | **T5 / 0.00** | Hold 0 through 2035. This is also the country the V1 free-route exploit landed on — the ceiling here is a live guard, not a formality. |
| **Brunei** | **0** | `no_policy_instrument`; feedstock 0.1 PJ | **T5 / 0.00** | **Correct the record:** Brunei is *not* 100 % import-dependent — Hengyi Pulau Muara Besar (~175 kbpd) produces its own diesel. The reason is no mandate + zero feedstock + a ~450k-person market that cannot amortise blending assets. Treat as a rounding error; carry 0 rows for completeness, do not model. |
| **Singapore** | **0** road diesel | `no_policy_instrument` + cost — **NOT `feedstock_volume`** | **T5 / 0.00** | The hardest special case. Zero domestic feedstock is true but irrelevant: Singapore hosts **Neste's 2.6 Mt/yr renewable-fuels plant** on its own territory and is a refining/trading/bunkering hub. Labelling the reason "feedstock" tells the modelling team it is hard-linked to our supply caps — it is not. Its entire biofuel policy is **aviation** (levy from 1 Apr 2026; 1 % uplift on departing flights from 1 Oct 2026; 3–5 % by 2030, conditional) and **marine** (MPA permits ≤B30 bunkers). Road blend ceiling 0 throughout; Singapore's large bio *throughput* belongs in aviation/marine branches, never in a road blend share. §10 D6. |

### Ethanol

| AMS | Start (achieved) | Bind | Tier / D | Special handling |
|---|---|---|---|---|
| **Indonesia** | **0.0** (2015–2025) | `feedstock_volume` — 26,000 kL/yr fuel-grade capacity vs ~1.65 mn kL/yr for national E5 (**~60×**). Not a fleet wall. | **T4 / 0.15** | Override canon `InterpFSY(2025,20; 2050,50)` outright. Mandatory E5 from 1 Jul 2026 in **7 provinces only** (Jakarta, W/C/E Java, Yogyakarta, Bali, Lampung) → treat as intent, not achievement. Also burdened by IDR 20,000/L excise applied as industrial grade, and priced 27–60 % above subsidised RON 90. |
| **Thailand** | **11.3** (2024, GAIN); derived ~11–12 | `technical_blend_wall` (E20 OEM cut-off, MY2008+) — **feedstock is not binding**: 6.92 MLPD capacity vs 3.43 MLPD road demand, >50 % idle | **T2 / 0.60** | E20 becomes the base grade with gasohol 91/95 and E85 discontinued by 2027 → ceiling steps to 20 in 2027 with the 0.85 haircut. Canon `InterpFSY(2050,20)` is a **floor set too low** — it implies ~14 % at 2030 against a legislated E20 base grade. Flag. |
| **Philippines** | **10.1** (2025f) | `technical_blend_wall` (E20 voluntary only, DC2024-05-0014 of 7 May 2024, with an explicit E20-Compatible Vehicle Advisory) + import dependence (~450 ML imported 2025) | **T3 / 0.35** | E10 mandatory since 2013 (11 years to the E20 circular, not 8). E20 has no mandatory date. Ethanol feedstock ≠ the 564 PJ coconut cap, which is a *biodiesel* feedstock. |
| **Viet Nam** | **~1–2** achieved under a mandatory E5 since 1 Jan 2018 (E5 share of sales ~42 % → ~20 %) | `announced_policy` step then `blending_distribution_infrastructure` | **T2 / 0.60** | Legislated grade switch: **E10 mandatory nationwide 1 Jun 2026**; ~1,000 PVOIL and ~5,500 Petrolimex stations converted by 20 May 2026. But **E5 RON92 is retained as the escape valve to 31 Dec 2030**, so achieved will sit below 10 for years. Ceiling on an achieved basis: 2026 ≈ 5, 2030 = 10. MOIT proposes **E15 from 1 Jan 2031** — carry it as a dated instrument. |
| **Malaysia** | **0** | `no_policy_instrument` | **T5 / 0.00** | No mandate, no programme, no fuel-ethanol industry. Hold 0 through 2060 unless an instrument appears — a non-zero late-horizon row with reason "no programme, no industry" is self-negating. |
| **Lao / Cambodia / Myanmar** | **0** | `no_policy_instrument` + `blending_distribution_infrastructure` | **T5 / 0.00** | Cassava/sugarcane headroom (141/258/204 PJ) is real but export-directed or undeveloped; the blocker is absence of terminals and a retail grade. Floor of zero through at least 2030. Scope the "motorcycles bind the ceiling" argument to TH/VN/ID/PH where fleet data exists — we have none for these three. |
| **Brunei / Singapore** | **0** | `no_policy_instrument` | **T5 / 0.00** | 0 throughout. Never proposed. |

Note: canon also carries a **Timor Leste** and a **Base Template** region at 0 — keep them at 0 and out of scope, but emit the rows so the CSV shape matches canon.

---

## 5. Part B — re-shaping the single-endpoint mandates

**The general rule.** A canon expression of the form `InterpFSY(T, X)` with one anchor is a *destination without a path*: LEAP linearly interpolates from the last known value, which manufactures a smooth ramp that no observed programme has ever followed. Replace each with a **four-element shape**, derived mechanically:

1. **t₀ = the achieved value now** (not the mandate).
2. **Step to `X × 0.85` at `T + 2`** — the mandate date slipped by the observed median slip (Indonesia: B35 +6 months, B40 +2 months, B50 +6 months + a 3-month transition; Malaysia B20 slipped ~6 years) and haircut by the observed step-year realisation.
3. **Plateau ≥2 years** at that value (every observed ASEAN step is followed by 1–3 flat years).
4. **Resume the rate-limited climb** at `r × D` toward `X × 0.92`, subject to the level cap.

### Malaysia — `InterpFSY(2030, 30)`
From B12 (2026) to 30 in 2030 is **~4.5 pp/yr sustained** — roughly 2× Indonesia's *mature* rate and ~1.8× its best decadal rate, demanded of a Tier-2 country whose own government names terminal retrofit as the pacing item, and whose B20 has failed to go nationwide for six years running. Not defensible. Compounding error: NETR's B30 is heavy/commercial-vehicle only, and heavy vehicles are a minority of diesel *volume* even in a freight-heavy fleet.

**Proposed shape (national volume-weighted, achieved basis):** 2025 **10** · 2026 **12** · 2027 **15** · 2028 **15** (plateau) · 2029 **17** · 2030 **18** · 2035 **22** · 2040 **25** · 2050 **30** · 2060 **30**. Carry B30-by-2030 in the `binding_reason` as a **heavy-duty segment target**, not a national ceiling. Rate never exceeds 3 pp in a step, averages 1.5 pp/yr — consistent with the retrofit-paced I-constraint. Revisit once the HDV share of diesel volume is sourced (§8 B4).

### Thailand — `InterpFSY(2037, 25)`
From 6.8 (2024) to 25 in 2037 is only 1.4 pp/yr — the rate is not the problem. The problem is that it **crosses the B7 Euro-5 OEM wall with no instrument**, in a country whose government deleted B10, cut the standard to B5, cut the AEDP 2037 biodiesel target to **900 ML from 1,570 ML**, and whose Oct 2025 roadmap makes B7 permanent while sending surplus biomass value to SAF. This is a ceiling below a mandate, i.e. a §7 R4 finding.

**Proposed shape:** 2025 **7** · 2030 **7** · 2035 **10** *(conditional on a documented OEM Euro-5 B10 declaration; if absent, hold 7)* · 2040 **12** · 2045 **15** · 2050 **18** · 2060 **20**. Additionally carry the **observed dip** (2023 = 5.3, 2025 standard cut to B5) so the table demonstrates the reversibility it prescribes. **Emit FINDING: canon TH biodiesel 25@2037 exceeds the feasible ceiling by ~7–15 pp for the whole period.**

### Lao PDR — `InterpFSY(2030, 10)` on both fuels
No legal instrument exists. The number is a slipped copy of the 2011 Renewable Energy Development Strategy's 10 %-by-**2025** target (with a nominally mandatory B10 phase 2016–2025) which lapsed unmet. No domestic refining, no blending terminals, road fuel imported as finished product.

**Proposed shape:** biodiesel 2025 **0** · 2030 **0** · 2035 **3** · 2040 **5** · 2050 **7** · 2060 **10**; ethanol 2025–2035 **0** · 2045 **5** · 2060 **10**. Optional mechanical alternative if the user prefers a rule to a judgement — the **inherited-spec rule**: `ceiling(LAO/KHM, y) = 0.5 × achieved(supplier, y−2)`, supplier = Thailand for Lao and Cambodia. It is transparent and auditable; it also yields ~3 % at 2035, so the two approaches agree. **Emit FINDING: canon LAO 10@2030 has no instrument; recommend the team stop defending it as policy.**

Same treatment, same paragraph, for **Viet Nam biodiesel `Interp(2023,0; 2050,20)`** — the shape is smooth from zero with no instrument at either end. Propose 0 to 2030, then infrastructure-limited 5 (2035) / 7 (2040) / 10 (2050) / 12 (2060), all `blending_distribution_infrastructure`, low confidence.

---

## 6. Part C — annual build-rate limit (`Maximum Capacity Addition`)

**Verdict: yes, defensible — but on a weaker evidence base than the blend ceiling, and it must be presented that way.**

Why we want it independently of the blend ceiling: the blend ceiling bounds the *share*; it does not stop the optimiser from commissioning an implausible amount of capacity in a single model year. V1 (Myanmar `Optimized New Capacity = 2,490 PJ/yr` at 2040, ~5× the country's entire biomass consumption, all 11 other regions at 0) is exactly that failure, and it happened because Myanmar carries `Exogenous Capacity = 0` while ID/MY/TH/PH hold installed plants, so all new build lands there by construction. A finite `Maximum Capacity Addition` is the structural fix; the 100 PJ lite-panel `Maximum Production` cap already applied (F7) is a blunt stand-in.

**Three defensible bases, used in combination:**

1. **Observed national record.** Indonesia is the only country with a long capacity series: **19.6 bn L nameplate installed (2025)**, with GAIN stating verbatim that "additional capacity of 4.0 billion liters is required to meet B50". That single data point already gives an order of magnitude — ~4 bn L (~3.5 Mt) as a one-step national ask in the largest programme on earth, and the industry association's public position is that capacity is *insufficient* beyond B40. Pull the full GAIN installed-capacity series (§8 B2) to get max observed annual addition.
2. **Percent-of-installed-base.** `MaxCapAdd(a,f,y) = α × installed(a,f,y−1)`. **[REVISED 2026-07-22 per §0]** α = **0.20/yr for every AMS**, not tiered by institutional readiness. Indonesia added FAME capacity at ~20 %/yr of installed base through the B30 ramp using ordinary EPC contractors and ordinary equipment, so that rate is a physical availability statement that holds anywhere; a country that never built was not physically incapable, it was uneconomic, and economics sit on the cost side. Self-scaling, and it still refuses to let a country with no industry build a national industry in one year — because the base is small, not because we ranked its institutions.
3. **One-train floor, to avoid infeasibility.** A fractional rate is undefined at a zero base, so a country with no installed capacity must still be able to start: floor at **one world-scale train per year** — ~**0.15 Mt/yr** for FAME, ~**0.5 Mt/yr** for HVO. Plus a **lead-time gate**, which is the one remaining differentiation and it is purely physical: an AMS with an installed base can debottleneck or add a train on an existing permit from **2026**; an AMS with none faces greenfield EPC lead time (FID → design → construction → commissioning, ~3 yr) and so commissions from **2028**. Brownfield/greenfield is read from `Bioenergy/Raw/refinery_capacity_2023.csv`, not from a readiness score.

```
MaxCapAdd(a,f,y) = 0                                            if y < first_feasible_year(a,f)
                 = MAX( one_train(f), 0.20 × installed(a,f,y−1) )   otherwise
```

Emitted by `Bioenergy/Analysis/build_rate_limit.py` → `build_rate_limit.csv` (20 rows).

**Evidence quality: thin.** We have nameplate *levels* (Indonesia 19.6 bn L; Neste Singapore 2.6 Mt/yr incl. up to 1 Mt/yr SAF; Pertamina Cilacap 3,000→6,000 bpd with Phase 2 targeted 2026; Plaju 20 kbpd targeted 2027; Thailand 28 ethanol plants / 6.92 MLPD; Indonesia fuel-grade ethanol ~26,000 kL/yr) but **no clean per-country annual-addition series**. α = 0.20 is a judgement, not an observation. Recommend adopting the structure now (it is the guard against V1-class exploits) and calibrating α once the GAIN capacity series is pulled — that is half a day of work, §9 S1b.

---

## 7. Robustness and validation — the tests to run before shipping

All seven implemented in one script, `Bioenergy/Analysis/check_blend_ramp.py`, emitting a pass/fail CSV plus a findings table. Nothing ships until every cell is PASS or an explicit, signed-off FINDING.

| # | Test | Fails when | Status |
|---|---|---|---|
| **R1** | **Feedstock cross-check.** For each AMS-fuel-year: blend % × pool volume → biofuel volume → PJ → feedstock tonnes (via OER and LHV) ≤ Cap-1 residual for that crop-year. Report the implied PJ *next to the cap*, in the CSV, per row — the verifier's specific complaint is that §8.6 asserted consistency without showing arithmetic anywhere. | implied feedstock > cap | **BLOCKED on F0/V2.** Must be run on **both** bases (raw FFB and oil-equivalent) and the ratio reported. A blend share implying more feedstock than the cap is invalid — but so is a cap overstated ~4.76× by the OER double-count. Until F0 lands, R1 is a two-sided uncertainty, not a one-sided check. Also cross-check Indonesia's B50 incremental ~4.7 Mt CPO (~10 % of a 46 Mt crop) against our 4,750 PJ palm headroom — this reconciliation has never been done. |
| **R2** | **Rate check vs Indonesia.** Single-year step ≤ 8 pp (T1) / ≤ legislated grade switch; rolling-5-yr mean ≤ 3.0 pp/yr everywhere; year-on-year ≤ `r × D`. | any window breaches | Ready to build. Note the rule must not forbid Indonesia's own observed behaviour — that was the flaw in the original "3 pp/yr for any AMS" formulation, which would have outlawed the B30 rollout it was derived from. |
| **R3** | **Wall check.** Ceiling ≤ certified wall unless an enabler row (spec + OEM declaration + road test) exists for that AMS-year. | above wall without enabler | Ready. |
| **R4** | **Floor-vs-ceiling consistency.** `ceiling(a,f,y) ≥ canon_mandate(a,f,y)` and `≥` any in-force legal floor. Where the ceiling is lower, do not raise it — emit a FINDING. | — | **Expected findings, all of them real:** MY biodiesel 30@2030 (canon) vs feasible ~18; TH biodiesel 25@2037 vs feasible ~10–12; LAO 10@2030 both fuels vs no instrument; VNM biodiesel 20@2050 vs no instrument; PH biodiesel 4@2025 / 5@2026 vs suspended at 3; ID ethanol 20@2025 vs observed 0.0. **And the reverse — canon floors set too low, which is equally fatal since a ceiling below a legislated floor is an infeasible model:** VNM ethanol (canon implies ~5 % at 2030 vs legislated E10 from 1 Jun 2026), TH ethanol (canon implies ~14 % at 2030 vs E20 base grade from 2027). |
| **R5** | **Denominator and unit check.** Is the blend % over **on-road** diesel or **total distributed** diesel? GAIN's on-road denominator gives Indonesia 2025 = **34.1**; the total pool (41,700 ML) gives **31.5** — a **2.6 pp definitional swing sitting directly on our numbers**, never stated in any of the four tracks. Also verify vol% → energy% (FAME ~33.0 vs diesel ~35.9 MJ/L → energy share ≈ 0.92 × volume; ethanol ~21.3 vs gasoline ~32.2 → ≈ 0.66 ×) and the LEAP unit on the target variable, given the module's history of exactly this class of bug (V14: refinery `Maximum Capacity` held ~39× too tight; Brunei 8,773 GJ read as TWh — a 3.6-million-fold slip). | undeclared or mismatched | Must be closed in S0, before any number is written. |
| **R6** | **Reversal / history check.** Ceiling never below an observed achieved value for a historical year; non-monotonic ceilings permitted and present where observed (TH 2023 dip, PH 2025–26 hold). | monotone-only table | Ready. |
| **R7** | **Back-test.** Run the rule set forward from 2015 Indonesia on 2015-vintage information → must land 2025 within ±3 pp of 34.1. Same for Thailand ethanol (2015→2024) and Philippines ethanol (2013→2025). | outside tolerance | This is the artefact that makes the method defensible to an external team. If it fails, the tier discounts are wrong, not the data. |

Every row also gets a `confidence` column. Low-confidence cells, declared up front: anything above B50 (no fleet evidence globally), all Lao/Cambodia/Myanmar/Brunei ladders (inference from absence, not from any instrument), every post-2040 value, and Malaysia's national volume-weighted average (no published figure exists).

---

## 8. Data we still need, and where it comes from

| # | Gap | Source | Effort | Blocking? |
|---|---|---|---|---|
| **B1** | **FFB/CPO basis (V2/T1.1)** — until settled, R1 cannot run and every tonnage/land figure stays embargoed | internal: T1.1 + LEAP-team confirmation T2.3 | — | **YES — blocks R1 only** |
| **B2** | Full **achieved blend-rate series** for TH / PH / ID / VN / MY, plus **installed capacity series** for Part C | USDA FAS GAIN Biofuels Annual, per country — free PDF download, tables already identified (ID2025-0029 T7/T8, ID2024-0018 T9, TH2024-0032, RP2025-0025 Appendix B, MY2024-0010) | 0.5 d | No — start now |
| **B3** | **Diesel and gasoline pool volumes** per AMS, on-road vs total split | IEA / ASEAN Centre for Energy / national statistics; GAIN gives ID (on-road 38,449 ML vs total 41,700 ML; gasoline 37,466 ML) | 1 d | Needed for R1 and R5 |
| **B4** | **Malaysia volume-weighted national blend**; HDV share of diesel volume | MPOB / MPIC; not published — will need construction from regional B-grades × regional diesel volumes | 0.5 d | Needed to finalise §5 Malaysia |
| **B5** | **Vehicle stock by fuel and age distribution** per AMS. The 11.5 / 11.7 / 11.9 yr figures are attributed to "Statista/ICCT" with no page reference and are **unverified**. | **Our own Transport sector** — `Transport/Historical/` observed panels, per-country stock/mileage json, `Transport/Sales/` — plus ICCT Viet Nam two-wheelers (Feb 2025) | 1 d | Needed for `W(y)` calibration |
| **B6** | **Blending-terminal counts and grade capability** per AMS (MY 34 depots, RM42m Sarawak phase 1; ID 29 terminals at B50 launch; others unknown) | national oil-company disclosures, OPIS, trade press | 1 d | Needed for `I(y)`; low confidence expected |
| **B7** | **Fuel-grade ethanol capacity** per AMS (ID ~26,000 kL/yr; TH 6.92 MLPD / 28 plants — note USGC gives 1.8 bn L across 21 plants, a source discrepancy to resolve; PH ~450 ML imported) | GAIN + DEDE + USGC | 0.5 d | Needed for ethanol `F(y)` |
| **B8** | **Coconut and palm price series** for the `feedstock_affordability` constraint | World Bank Pink Sheet (free, monthly) | 0.25 d | Needed for the PH ceiling |
| **B9** | Confirmation of the **LEAP target variable name, unit and denominator** | LEAP team (fold into the T2.0 re-zipped handover) | — | Needed for R5 |

Two items to *stop* citing: the "Jan–Nov 2025 distribution was 78 % of allocation" figure (unsourceable, and it contradicts the 92 % realisation used two sentences earlier in the same track), and "UCO/POME/PFAD are exported, not blended" in the present tense (Indonesia began curbing waste-stream feedstock exports in January 2025 and the levy now covers them).

---

## 9. Work sequence

| Step | Work | Effort | Start now? |
|---|---|---|---|
| **S0** | **Definitions freeze** — one short doc fixing: volume % of *which* pool; vol↔energy conversion; FAME-only scope; HVO handled separately; anchor-year grid standardised to {2025, 2026, 2027, 2030, 2035, 2040, 2045, 2050, 2055, 2060} for **all ten AMS** (the current drafts have per-country grids and a stray Thailand 2037 row, which LEAP would interpolate inconsistently). | 0.5 d | **Yes — do first** |
| **S1** | Build `Analysis/blend_observed_panel.csv` — the achieved series for ID/TH/PH/VN/MY from GAIN, with mandate alongside and a `realisation` column. This is the evidence base for everything. | 0.5 d | **Yes** |
| **S1b** | Extract the installed-capacity series → calibrate α for Part C. | 0.5 d | **Yes** |
| **S2** | `Analysis/enabling_conditions_scorecard.csv` — 10 AMS × 6 enablers, each cited, → tier and `D`. | 0.5 d | **Yes** |
| **S3** | `W(y)` certification-wall curves via `ref_curves.logistic_transition`, calibrated on Transport-sector fleet data (B5). | 1 d | After B5 |
| **S4** | `I(y)` infrastructure-feasible share from terminal data (B6). | 0.5 d | After B6 |
| **S5** | `F(y)` feedstock-implied share against Cap-1. | 1 d | **Blocked on B1** |
| **S6** | `P(y)` policy ceiling — parse canon `InterpFSY`/`Interp` expressions from `current_expressions_keys_slice_4scenarios.csv`, tag each as instrument-backed or not. | 0.5 d | **Yes** |
| **S7** | `LEAP Input/build_max_blend_share.py` — the constraint stack, per `00Guide/ref_build.py`; emits the ceiling rows into `bioenergy_leap_input.csv` under a new `blend_ceiling` domain, validated by `validate_against_canon.py` including its unit audit. | 1 d | Stub now, finish after S3–S6 |
| **S8** | `Analysis/check_blend_ramp.py` — R1–R7. | 0.5 d | After S7 |
| **S9** | Back-test (R7) and tune. | 0.5 d | After S8 |
| **S10** | Findings memo (every R4 breach, both directions) + living docs: `DESIGN.md` (date, pipeline table, gaps), `data_sources.md` (row per new file), `LEAP Input/LEAP_action_items.md` (new batch), `NEXT_STAGE.md` re-tidy per the standing rule. | 0.5 d | Last |

**Total ≈ 7.5 person-days**, of which **~3 days (S0, S1, S1b, S2, S6, S7 stub) can start immediately** with no external dependency.

---

## 10. Open decisions for the user

- **D1 — Denominator.** On-road diesel or total distributed diesel? **2.6 pp swing on Indonesia alone**, and it propagates to every country. Needs a LEAP-team answer (fold into the T2.0 re-zip) or our own declared convention.
- **D2 — Does the ceiling override a country's stated target?** The canon mandate curves came from country consultation workshops (Indonesia's is explicitly tagged "1st 1o1 Country Consultation Workshop for RE LTRM"). Six of them exceed what we judge feasible. Do we (a) hard-cap and publish the finding, (b) cap RAS only and leave ATS/AMS-Target at the country's number, or (c) publish the finding and let the LEAP team decide? Recommendation: **(b) + publish**, consistent with the repo's policy-exclusion pattern — the feasibility ceiling belongs in the optimiser, the country's ambition belongs in the target scenario, and the gap between them is the analytical result.
- **D3 — HVO.** Do we open a separate renewable-diesel branch? HVO (EN 15940) is a paraffinic drop-in with no FAME blend wall — but the verifier correction stands: **EN 590's density floor of 820 kg/m³ practically caps HVO at ~30–50 % of an EN 590 pool; 100 % is only achievable as a declared EN 15940 retail grade** with its own OEM list and dispensing. A hard 50 % "biodiesel in diesel" cap will systematically misprice the HVO pathway for Singapore and Indonesia. This is a structural create (LEAP-team owned).
- **D4 — May ceilings fall?** Realism requires yes (Thailand, Philippines). Confirm the canon `Interp` form and the RAS solver tolerate a decreasing ceiling.
- **D5 — Indonesia 2026 anchor: 38 or 43?** Quota-scaling (17.6/15.6 mn kL against ~2 % pool growth) gives **≈37–39**; half-year weighting (H1 B40, Q3 transition, Q4 B50) gives **≈43**. Both are defensible; they differ by 5 pp on the region's single largest number. Recommendation: carry **38** with a stated ±5 band, revise when GAIN ID2026 publishes.
- **D6 — Singapore and Brunei.** Confirm road blend = 0 throughout, with Singapore's biofuel volume carried in aviation and marine branches instead. Otherwise the model will read a refining/trading hub's throughput as a road blend, or read "zero feedstock" as "zero achievable" — two opposite errors from the same mislabel.
- **D7 — Adopt Part C now or wait?** The structure guards a live exploit class; the α calibration is thin. Recommendation: adopt the structure now, flag α as provisional, calibrate in S1b.
- **D8 — Ethanol ceiling above E20.** India (E20 nationwide 2025) and Brazil (E30 mandatory Aug 2025, non-flex baseline) prove E20 is not physics. Do we allow any AMS above E20 late-horizon on an explicit OEM-declaration assumption, or hold 20 as a hard cap through 2060 and note the conservatism? Recommendation: hold 20, note it, and expose it as a scenario lever rather than a wall — a reversible national decision must not be encoded as immovable.