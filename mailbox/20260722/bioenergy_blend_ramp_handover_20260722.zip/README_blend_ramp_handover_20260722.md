# Bioenergy → LEAP modelling team — blend ceiling + answers

**Date:** 2026-07-22 · **Re:** your `bioenergy_ruling_reply_20260721.zip`
**Scenarios: BAS / ATS / RAS.** Values only — no branch paths, variables or units.
Blend shares are **volume %**; we have not converted to energy % (you apply
`×38.997` / `×26.744`).

Your three corrections are accepted and verified on our side. Details in `ANSWERS`.

## Read this first — what the table IS

**It is a CEILING for the optimiser, not a forecast.** RAS picks the blend share; if a level
is not optimal it will not appear in the result no matter what we permit. So the ceiling
encodes **physical and legal limits only**:

```
ceiling(a,f,y) = min( technical blend wall,            # fuel spec + in-use fleet
                      prev + max demonstrated ramp )   # fleet turnover / terminal retrofit
      floored by: dated legal instrument in force
                  PEAK observed achieved blend for that country-fuel
```

It deliberately does **not** encode absence of a mandate, institutional capacity, fiscal
capacity, market size, or a price-driven policy suspension. Those are economics or policy —
you and the cost side already see them, and a ceiling built on them would forbid outcomes
that are merely unlikely rather than impossible.

**Intended consequence: the ceiling is broadly similar across AMS and converges on the
technical wall.** Indonesia demonstrated ~3 pp/yr sustained and an 8.3 pp single-year step on
a real in-use fleet, so that rate is physically available to any country whose economics
justify it. Differentiation survives only where physical:

- Indonesia already in-market at B50
- dated legal instruments (Malaysia B15 2026, Viet Nam E10 2026, Thailand E20 2027, …)
- each country's **peak demonstrated** blend — Thailand's fleet has burned B8.2 and E13.7, so
  no ceiling of ours may declare those impossible for Thailand. It withdrew B10 on palm
  price; that is your optimiser's decision to re-make, not ours to pre-empt.

Notably, **Thailand carries no fleet-spec exception.** Its B10 deletion (1 May 2024) is
usually read as a Euro-5 common-rail limit, but Indonesia runs B40 nationwide on a comparable
common-rail share — so the spec is not the binding physical constraint, and we removed it.

`binding_reason` is a closed 4-value taxonomy, all physical:
`technical_blend_wall` (145) · `max_physical_ramp_rate` (27) ·
`observed_achieved_floor` (22) · `legal_instrument_floor` (6).

**Where the ceiling lands** (volume %, selected years):

| | 2025 | 2030 | 2035 | 2040 | 2050 | 2060 |
|---|---|---|---|---|---|---|
| Biodiesel, most AMS | 0.0 | 12.0 | 20.0 | 30.0 | 50.0 | 50.0 |
| Biodiesel, Indonesia | 34.1 | 50.0 | 50.0 | 50.0 | 50.0 | 50.0 |
| Biodiesel, Malaysia | 12.0 | 15.0 | 20.0 | 30.0 | 50.0 | 50.0 |
| Biodiesel, Thailand | 8.2 | 12.0 | 20.0 | 30.0 | 50.0 | 50.0 |
| Bioethanol, most AMS | 0.0 | 15.0 | 20.0 | 20.0 | 20.0 | 20.0 |
| Bioethanol, Thailand | 13.7 | 20.0 | 20.0 | 20.0 | 20.0 | 20.0 |
| Bioethanol, Philippines | 10.1 | 15.0 | 20.0 | 20.0 | 20.0 | 20.0 |

Walls: biodiesel B7 (EN590) → B20 (ASTM D7467, mixed in-use fleet) → B50 (Indonesia
demonstrated, tightened B100 spec), rising with fleet turnover. Ethanol E10 (universal
warranty line) → E20 by 2032 (OEM model-year cut-off; India ran E10→E20 in 3 years on a
motorcycle-majority fleet, Brazil mandates E30 on non-flex stock — above E10 is an
OEM-declaration question, not physics).

## Contents

| File | What it is |
|---|---|
| `blend_ceiling_ramp.csv` | **THE DELIVERABLE (your part A)** — `max_blend_share_volume_pct` per AMS × fuel × year, 2025→2060, with `binding_reason`, `confidence`, `source`. 200 rows. |
| `mandate_floor_reshape.csv` | **Part B** — the single-endpoint mandates re-shaped into an observed four-element path. This is a **floor**, so it is deliberately conservative: a floor set above what a programme realises would make the model infeasible. |
| `build_rate_limit.csv` | **Part C** — the `Maximum Capacity Addition` rule + per-AMS parameters. **α = 0.20/yr for every AMS**, not tiered by readiness: Indonesia expanded FAME at ~20 %/yr of installed base with ordinary EPC contractors, so the rate is physically available anywhere. The only differentiation is brownfield (first addition 2026) vs greenfield (2028, EPC lead time), read from installed capacity. |
| `blend_ramp_findings.csv` | 21 findings, **both directions** — 15 where canon sits above the physical ceiling, and **6 where canon sits BELOW a dated legal instrument** (see the warning below). |
| `p4_pending_branch_creates.csv` | **The 51 unshipped rows** on the three branches you are creating. Ready to inject. |
| `canon_mandate_parsed.csv` | All 20 canon mandate cells parsed — includes four your ASK table omitted. |
| `blend_observed_panel.csv` | The evidence base: MANDATE vs ACHIEVED kept separate, with `realisation`. |
| `enabling_conditions_scorecard.csv` | 10 AMS × 6 enablers. **Context only** — it no longer computes the ceiling (see above). |
| `blend_ramp_check.csv` | Validation. **49 PASS, 2 BLOCKED, 1 INFO, 0 FAIL.** |
| `ANSWERS_20260722.md` | Count reconciliation, Brunei basis, v0.71 provenance, the unit pre-conversions, + 2 questions for you. |

## How Indonesia's record is used, since you asked

Indonesia went **0 → B50 in 18 years** (2008 first mandate → 2026), on a real fleet, with a
levy-funded price gap and a spec-and-road-test programme behind each step. We treat that as
**proof of physical walkability**, not as a set of preconditions — which is why a country
missing those institutions is not pinned at zero. The full gate-by-gate account (A mandate →
B price-gap fund → C nationwide enforcement → D spec/road-test → E mature stepping, with the
observed achieved level after each) is in `blend_ramp_workplan.md` §2–§3. It is now
**narrative and calibration evidence**, not a ceiling input; encoding institutional pace into
a ceiling would be forecasting, and that is your optimiser's job.

What we did keep from that record, because it is physical: **max sustained 3.0 pp/yr,
max single-year step 8.3 pp**, and the fact that observed realisation is 0.83–0.92 and never
1.00. Ceilings are also allowed to **fall** — but in this build none do, because the peak
demonstrated floor holds them up.

## ⚠ One finding worth acting on before the next solve — `InterpFSY` floors read ZERO

`InterpFSY(T, X)` with a single late anchor returns **0 for every year before T**. So the
canon mandate floor is currently **zero** for blends that are already legally in force:

| Branch | Canon floor | Legally in force | Gap |
|---|---|---|---|
| **Thailand bioethanol** | 0.0 (2027) | **E20 base grade, 2027** | **20 pp** |
| **Malaysia biodiesel** | 0.0 (2026) | **B15 Peninsular, 1 Jun 2026** | **15 pp** |
| Philippines bioethanol | 0.0 (2025) | E10 mandatory since 2012 | 10 pp |
| Viet Nam bioethanol | 2.2 (2026) | E10 mandatory 1 Jun 2026 | 7.8 pp |
| Indonesia biodiesel | 40.4 (2026) | B50 from 1 Jul 2026 | 9.6 pp |

The optimiser is therefore free to blend **below a country's legal obligation** in those
years. This is the mirror image of the ceiling problem you asked us to fix, and it is
arguably the more urgent of the two. All six are in `blend_ramp_findings.csv` under
`direction = "canon BELOW dated legal instrument"`. **We recommend raising those floors to
the instrument rather than reshaping them** — a reshape would lower a realised mandate.

## Unit pass-through — we now pre-convert everything, per your ruling

Your ruling that the adapter is a **pass-through** invalidated 15 rows in the main input that
had been authored in a source unit on the assumption that
`nemo_read.unit_conversions._REGISTRY` would convert them at injection time. They would have
landed raw and silently wrong. We now apply your own `CSV_AUTHORING_GUIDE` §11.2 factors
ourselves and author natively in the LEAP unit:

| Rows | Variable | Was | Now | Factor |
|---|---|---|---|---|
| 10 | `Import Cost` (Corn) | `USD/t grain` | `2020 USD/Tonnes of Coal Equivalent` | 2.0074 |
| 1 | `Fuel Cost` (Palm Oil) | `USD/t FFB` | `U.S. Dollar/Gigajoule` | 0.1667 |
| 1 | `Fuel Cost` (Coconut Oil) | `USD/t nuts-in-shell` | `U.S. Dollar/Gigajoule` | 0.0741 |
| 1 | `Fuel Cost` (Sugarcane) | `USD/t cane` | `U.S. Dollar/Gigajoule` | 0.1333 |
| 1 | `Fuel Cost` (Cassava) | `USD/t fresh root` | `U.S. Dollar/Gigajoule` | 0.2857 |
| 1 | `Fuel Cost` (Corn) | `USD/t grain` | `U.S. Dollar/Tonnes of Coal Equivalent` | 2.0074 |

The four per-GJ crop factors are your ★★ entries (regional proxy LHV, ~±25 %) — the **value**
carries that uncertainty, the **unit** no longer does, and each row's `note` states the
authored basis, the factor and the LHV so you can rescale in one line if your fuel
`EnergyContent` differs. **The full 581-row input now matches canon on branch, variable and
unit for all 520 rows that resolve** — the remaining 61 are the ones blocked on branch
creation, unchanged.

## Two things we could not close, both on shared inputs

- **R1 feedstock cross-check — blocked.** Needs the FFB/CPO energy basis (your item 2) and
  per-AMS diesel/gasoline pool volumes. Until then a blend share cannot be checked against
  our own supply caps in either direction.
- **R5 denominator — blocked.** On-road vs total distributed diesel is a **2.6 pp swing on
  Indonesia alone**. See `ANSWERS` §6.

## What we need back

1. **The authoring contract** — `ANSWERS` §5. Does "values only" mean you publish a template
   we fill, or does the existing 11-column CSV continue for already-published paths?
2. **The blend denominator** — `ANSWERS` §6.
3. Your four post-inject deliverables (demand export, fuel `EnergyContent` incl. Corn, the
   Bagasse/Biomass deficit check, fresh RAS run + input set). The `EnergyContent` export lets
   you confirm or rescale the six conversions in the table above and unblocks R1.
